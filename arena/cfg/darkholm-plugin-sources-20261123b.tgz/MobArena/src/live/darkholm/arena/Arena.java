package live.darkholm.arena;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Darkholm Mob Arena. Lobby with class stations and a ready pad; a countdown sends every ready player into the
 * colosseum together; endless waves with a boss every 5; Factions cash and crate keys scaled on waves survived.
 */
public final class Arena extends JavaPlugin implements Listener {
    static final String TAG = "dh_arena_mob";
    static final String BOSS_TAG = "dh_arena_boss";
    static final List<String> CLASSES = List.of("ranger", "soldier", "healer", "tank", "berserker");
    static final Map<String, String> CLASS_NAMES = new HashMap<>(Map.of("ranger", "§aRanger", "soldier", "§cSoldier",
            "healer", "§dSupport / Healer", "tank", "§9Tank", "berserker", "§6Berserker"));
    static Arena I;
    /** Message from config (messages.<key>), & colours, {name} fill-ins as name, value pairs. */
    String T(String key, String def, Object... kv) {
        String t = ConfigSync.c(getConfig().getString("messages." + key, def));
        for (int i = 0; i + 1 < kv.length; i += 2) t = t.replace("{" + kv[i] + "}", String.valueOf(kv[i + 1]));
        return t;
    }
    List<String> TL(String key, List<String> def) {
        List<String> src = getConfig().isList(key) ? getConfig().getStringList(key) : def, out = new ArrayList<>();
        for (String x : src) out.add(ConfigSync.c(x));
        return out;
    }
    String waves(int n) { return n + (n == 1 ? T("word-wave", " wave") : T("word-waves", " waves")); }

    private final Random rng = new Random();
    private final Map<UUID, String> chosen = new HashMap<>();
    private final Set<UUID> ready = new HashSet<>();
    private File dataFile;
    private YamlConfiguration data;

    // countdown
    private int countdown = -1;
    private BossBar lobbyBar;
    // run state
    private boolean running;
    private final Set<UUID> fighters = new HashSet<>();   // in the run, alive
    private final Map<UUID, Integer> fallen = new LinkedHashMap<>(); // in the run, dead: waves survived
    private final Map<UUID, String> runClass = new HashMap<>();
    private int wave;            // current wave number
    private int toSpawn;         // mobs of this wave not yet spawned
    private boolean waveLive;    // mobs out
    private boolean glowing;
    private BossBar bossBar;
    private LivingEntity boss;
    private BukkitTask tickTask;
    private UUID tauntBy;
    private long tauntUntil;

    // ---------- setup ----------
    @Override public void onEnable() {
        I = this;
        ConfigSync.sync(this, "rewards.key-pool", "scaling", "boss", "lobby-classes");
        for (String c : CLASSES) CLASS_NAMES.put(c, ConfigSync.c(getConfig().getString("classes." + c + ".name", CLASS_NAMES.get(c).replace('§', '&'))));
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        Bukkit.getPluginManager().registerEvents(this, this);
        lobbyBar = Bukkit.createBossBar(T("bossbar-title", "Mob Arena"), BarColor.YELLOW, BarStyle.SOLID);
        bossBar = Bukkit.createBossBar("Boss", BarColor.RED, BarStyle.SEGMENTED_10);
        Bukkit.getScheduler().runTaskTimer(this, this::second, 20L, 20L);
        tickTask = Bukkit.getScheduler().runTaskTimer(this, this::tick, 10L, 10L);
        // clean up arena mobs left by a crash
        World w = world();
        if (w != null) for (Entity e : w.getEntities()) if (e.getScoreboardTags().contains(TAG)) e.remove();
        getLogger().info("Darkholm Mob Arena ready in world " + getConfig().getString("world"));
    }

    @Override public void onDisable() {
        if (running) endRun(T("reason-closed", "The arena was closed."));
        lobbyBar.removeAll();
        bossBar.removeAll();
        saveData();
    }

    World world() { return Bukkit.getWorld(getConfig().getString("world", "darkholm_arena")); }

    Location loc(String path) {
        String s = getConfig().getString(path);
        if (s == null || world() == null) return null;
        String[] a = s.split(",");
        Location l = new Location(world(), Double.parseDouble(a[0]), Double.parseDouble(a[1]), Double.parseDouble(a[2]));
        if (a.length >= 5) { l.setYaw(Float.parseFloat(a[3])); l.setPitch(Float.parseFloat(a[4])); }
        return l;
    }

    static String str(Location l, boolean look) {
        String s = Math.round(l.getX() * 10) / 10.0 + "," + Math.round(l.getY() * 10) / 10.0 + "," + Math.round(l.getZ() * 10) / 10.0;
        return look ? s + "," + Math.round(l.getYaw()) + "," + Math.round(l.getPitch()) : s;
    }

    static String blockKey(Block b) { return b.getX() + "," + b.getY() + "," + b.getZ(); }

    boolean inWorld(Player p) { World w = world(); return w != null && p.getWorld().equals(w); }

    boolean inLobby(Player p) { return inWorld(p) && !fighters.contains(p.getUniqueId()) && !fallen.containsKey(p.getUniqueId()); }

    void saveData() { try { data.save(dataFile); } catch (IOException e) { getLogger().warning(e.getMessage()); } }

    static void title(Player p, String a, String b) {
        p.showTitle(Title.title(Component.text(a), Component.text(b),
                Title.Times.times(java.time.Duration.ofMillis(250), java.time.Duration.ofMillis(2200), java.time.Duration.ofMillis(500))));
    }

    static void bar(Player p, String s) { p.sendActionBar(Component.text(s)); }

    void msgRun(String s) { for (UUID id : runPlayers()) { Player p = Bukkit.getPlayer(id); if (p != null) p.sendMessage(s); } }

    List<UUID> runPlayers() { List<UUID> l = new ArrayList<>(fighters); l.addAll(fallen.keySet()); return l; }

    // ---------- lobby ----------
    long cooldownLeft(Player p) {
        if (p.hasPermission("darkholm.arena.bypasscooldown")) return 0;
        long cd = getConfig().getLong("join-cooldown-minutes", 120) * 60000L;
        long last = data.getLong("cooldown." + p.getUniqueId(), 0L);
        return Math.max(0, last + cd - System.currentTimeMillis());
    }

    static String dur(long ms) {
        long m = (ms + 59999) / 60000, h = m / 60; m %= 60;
        return h > 0 ? h + "h " + m + "m" : m + "m";
    }

    void toLobby(Player p) {
        long left = cooldownLeft(p);
        if (left > 0) { p.sendMessage("\u00a76\u2694 \u00a7cThe arena gates are closed to thee for another \u00a7e" + dur(left) + "\u00a7c."); return; }
        Location l = loc("lobby");
        if (l == null) { p.sendMessage(T("lobby-not-set", "&cThe arena lobby isn't set up yet.")); return; }
        p.teleport(l);
    }

    void prepLobby(Player p) {
        p.setGameMode(GameMode.ADVENTURE);
        p.getInventory().clear();
        p.setHealth(attr(p, Attribute.MAX_HEALTH));
        p.setFoodLevel(20);
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        p.sendMessage(T("welcome", "&6⚔ &eWelcome to the Mob Arena. &7Left-click a class station to preview its kit, right-click to choose it, then right-click the &6ready bell&7 in the middle."));
    }

    void pickClass(Player p, String c) {
        chosen.put(p.getUniqueId(), c);
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_CHAIN, 1f, 1f);
        p.sendMessage(T("class-chosen", "&6⚔ &7Class chosen: {class}&7. Right-click the ready bell when you're set.", "class", CLASS_NAMES.get(c)));
    }

    static final class PreviewHolder implements InventoryHolder {
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    void openPreview(Player p, String c) {
        PreviewHolder h = new PreviewHolder();
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Kit: " + CLASS_NAMES.get(c).substring(2)));
        h.inv = inv;
        int i = 0;
        for (ItemStack it : kit(c)) if (i < 18) inv.setItem(i++, it);
        ItemStack info = named(new ItemStack(Material.BOOK), "§e" + CLASS_NAMES.get(c).substring(2), classInfo(c));
        inv.setItem(22, info);
        p.openInventory(inv);
    }

    @EventHandler public void onPreviewClick(InventoryClickEvent e) {
        if (e.getInventory().getHolder() instanceof PreviewHolder) e.setCancelled(true);
    }

    void setReady(Player p) {
        UUID id = p.getUniqueId();
        if (ready.contains(id)) return;
        if (!chosen.containsKey(id)) { bar(p, T("pick-class-first", "&cPick a class first: right-click a class station.")); return; }
        ready.add(id);
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.6f);
        p.sendMessage(T("ready", "&6⚔ &aYou're ready as {class}&a. &7Use &e/ma unready &7to step out.", "class", CLASS_NAMES.get(chosen.get(id))));
        if (countdown < 0) countdown = getConfig().getInt("countdown-seconds", 300);
        if (running) p.sendMessage(T("run-in-progress", "&7A run is in progress. You'll go in with the next group."));
    }

    void unready(Player p) {
        if (ready.remove(p.getUniqueId())) p.sendMessage(T("unready", "&7You're no longer ready."));
        if (ready.isEmpty()) countdown = -1;
    }

    List<Player> lobbyPlayers() {
        List<Player> l = new ArrayList<>();
        World w = world();
        if (w == null) return l;
        for (Player p : w.getPlayers()) if (inLobby(p)) l.add(p);
        return l;
    }

    /** Once a second: countdown, lobby bar, pending rewards. */
    void second() {
        List<Player> lobby = lobbyPlayers();
        ready.removeIf(id -> { Player p = Bukkit.getPlayer(id); return p == null || !inLobby(p); });
        lobbyBar.removeAll();
        if (ready.isEmpty()) countdown = -1;
        if (!running && countdown >= 0) {
            boolean all = !lobby.isEmpty();
            for (Player p : lobby) if (!ready.contains(p.getUniqueId())) { all = false; break; }
            int fast = getConfig().getInt("all-ready-seconds", 10);
            if (all && countdown > fast) countdown = fast;
            if (countdown == 0) { startRun(); }
            else {
                if (countdown <= 5 || countdown == 10 || countdown == 30 || countdown == 60)
                    for (Player p : lobby) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
                countdown--;
            }
        }
        if (!lobby.isEmpty()) {
            String t;
            if (running) t = T("bar-running", "&cRun in progress &7- wave &e{wave} &7- {fighting} fighting", "wave", wave, "fighting", fighters.size()) + (ready.isEmpty() ? "" : T("bar-running-ready", " &8| &a{ready} ready for next", "ready", ready.size()));
            else if (countdown >= 0) t = T("bar-countdown", "&eThe gates open in &6{time} &8| &a{ready}/{lobby} ready", "time", (countdown + 1) / 60 + ":" + String.format("%02d", (countdown + 1) % 60), "ready", ready.size(), "lobby", lobby.size());
            else t = T("bar-idle", "&7Choose a class, then right-click the &6ready bell");
            lobbyBar.setTitle(t);
            lobbyBar.setProgress(countdown >= 0 && !running ? Math.max(0, Math.min(1, (countdown + 1) / (double) getConfig().getInt("countdown-seconds", 300))) : 1);
            for (Player p : lobby) lobbyBar.addPlayer(p);
        }
        for (Player p : Bukkit.getOnlinePlayers()) payPending(p);
    }

    // ---------- run ----------
    void startRun() {
        countdown = -1;
        Location spawn = loc("arena.spawn");
        if (spawn == null) { getLogger().warning("arena.spawn not set"); return; }
        fighters.clear(); fallen.clear(); runClass.clear();
        for (UUID id : new ArrayList<>(ready)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !inLobby(p) || !chosen.containsKey(id)) continue;
            fighters.add(id);
            runClass.put(id, chosen.get(id));
        }
        ready.clear();
        if (fighters.isEmpty()) return;
        running = true;
        wave = 0;
        long now = System.currentTimeMillis();
        for (UUID id : fighters) data.set("cooldown." + id, now);
        saveData();
        for (UUID id : fighters) {
            Player p = Bukkit.getPlayer(id);
            p.teleport(spawn);
            p.setGameMode(GameMode.ADVENTURE);
            equip(p, runClass.get(id));
            title(p, T("start-title", "&6⚔ The gates open"), T(fighters.size() == 1 ? "start-sub-one" : "start-sub", fighters.size() == 1 ? "&71 warrior enters the arena" : "&7{count} warriors enter the arena", "count", fighters.size()));
        }
        Bukkit.getScheduler().runTaskLater(this, this::nextWave, 100L);
    }

    /** Early-wave easing: starts at base on wave 1 and rises evenly to 1.0 after the last easy wave. */
    double ease(String key, double def) {
        int easy = getConfig().getInt("early.waves", 10);
        if (wave > easy) return 1.0;
        double base = getConfig().getDouble("early." + key, def);
        return base + (1.0 - base) * (wave - 1) / (double) easy;
    }

    void nextWave() {
        if (!running) return;
        wave++;
        boolean bossWave = wave % getConfig().getInt("boss-every", 5) == 0;
        int n = fighters.size();
        toSpawn = bossWave ? 2 + wave / 5 + (n - 1) : 3 + wave * 2 + (n - 1) * (1 + wave / 2);
        if (!bossWave) toSpawn = Math.max(2, (int) Math.ceil(toSpawn * ease("count-mult", 0.7)));
        waveLive = true;
        glowing = false;
        for (UUID id : runPlayers()) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            title(p, bossWave ? T("boss-wave-title", "&4☠ Boss wave {wave}", "wave", wave) : T("wave-title", "&6Wave {wave}", "wave", wave), bossWave ? T("boss-wave-sub", "&cA champion enters the arena") : T("wave-sub", "&7{count} foes approach", "count", toSpawn));
            p.playSound(p.getLocation(), bossWave ? Sound.ENTITY_WITHER_SPAWN : Sound.EVENT_RAID_HORN, 0.8f, 1f);
        }
        if (bossWave) spawnBoss();
    }

    void waveCleared() {
        waveLive = false;
        bossBar.removeAll();
        boss = null;
        for (UUID id : fighters) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            double max = attr(p, Attribute.MAX_HEALTH);
            p.setHealth(Math.min(max, p.getHealth() + max * getConfig().getDouble("heal-between-waves", 0.25)));
            p.setFoodLevel(20);
            refill(p, runClass.get(id));
            boolean bossWave = wave % getConfig().getInt("boss-every", 5) == 0;
            title(p, T("cleared-title", "&aWave {wave} cleared", "wave", wave), bossWave ? T("cleared-boss-sub", "&6+1 {key} key earned", "key", keyName(wave)) : T("cleared-sub", "&7+25% health. The next wave comes in {seconds}s", "seconds", getConfig().getInt("break-seconds", 10)));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1f);
        }
        Bukkit.getScheduler().runTaskLater(this, this::nextWave, 20L * getConfig().getInt("break-seconds", 10));
    }

    /** Twice a second: spawning, targeting, glow, counters, boss bar, spectator leash. */
    void tick() {
        if (!running) return;
        World w = world();
        List<LivingEntity> mobs = new ArrayList<>();
        for (LivingEntity e : w.getLivingEntities()) if (e.getScoreboardTags().contains(TAG) && !e.isDead()) mobs.add(e);
        int cap = getConfig().getInt("mob-cap", 40);
        int per = 3;
        while (waveLive && toSpawn > 0 && mobs.size() < cap && per-- > 0) {
            LivingEntity m = spawnMob();
            if (m != null) mobs.add(m);
            toSpawn--;
        }
        List<Player> alive = new ArrayList<>();
        for (UUID id : fighters) { Player p = Bukkit.getPlayer(id); if (p != null) alive.add(p); }
        if (alive.isEmpty()) { endRun(null); return; }
        Player tauntP = tauntBy != null && System.currentTimeMillis() < tauntUntil ? Bukkit.getPlayer(tauntBy) : null;
        for (LivingEntity e : mobs) {
            if (!(e instanceof Mob m)) continue;
            Player best = tauntP != null && tauntP.getLocation().distanceSquared(e.getLocation()) < 196 ? tauntP : null;
            if (best == null) {
                if (m.getTarget() instanceof Player tp && fighters.contains(tp.getUniqueId())) continue;
                double d = Double.MAX_VALUE;
                for (Player p : alive) { double dd = p.getLocation().distanceSquared(e.getLocation()); if (dd < d) { d = dd; best = p; } }
            }
            if (best != null) m.setTarget(best);
        }
        Location ctr = loc("arena.center");
        double rad = getConfig().getDouble("arena.radius", 20);
        for (LivingEntity e : mobs) if (ctr != null && e.getLocation().distanceSquared(ctr) > (rad + 3) * (rad + 3)) e.teleport(spawnSpot());
        int left = mobs.size() + toSpawn;
        if (waveLive && left <= 5 && toSpawn == 0 && !glowing) {
            glowing = true;
            for (LivingEntity e : mobs) e.setGlowing(true);
        }
        if (waveLive && left == 0) { waveCleared(); return; }
        Location c = loc("arena.center");
        double r = getConfig().getDouble("arena.radius", 20);
        for (UUID id : runPlayers()) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (waveLive) bar(p, T("bar-wave", "&6Wave {wave} &8| &cFoes left: {left} &8| &a{standing} standing", "wave", wave, "left", left, "standing", fighters.size()));
            if (fallen.containsKey(id) && c != null && p.getWorld().equals(c.getWorld()) && outOfBowl(p.getLocation(), c)) p.teleport(spectate());
        }
        if (boss != null && !boss.isDead()) {
            bossBar.setProgress(Math.max(0, Math.min(1, boss.getHealth() / attr(boss, Attribute.MAX_HEALTH))));
            for (UUID id : runPlayers()) { Player p = Bukkit.getPlayer(id); if (p != null && !bossBar.getPlayers().contains(p)) bossBar.addPlayer(p); }
            bossTick(alive);
        } else bossBar.removeAll();
    }

    /** Spectators stay inside the colosseum: within its outer wall and between the floor and just above the rim. */
    boolean outOfBowl(Location l, Location c) {
        if (!l.getWorld().equals(c.getWorld())) return true;
        double rr = getConfig().getDouble("arena.spectate-radius", 29);
        double dx = l.getX() - c.getX(), dz = l.getZ() - c.getZ();
        return dx * dx + dz * dz > rr * rr || l.getY() < c.getY() || l.getY() > c.getY() + getConfig().getDouble("arena.spectate-height", 16);
    }

    @EventHandler public void onSpectateTeleport(org.bukkit.event.player.PlayerTeleportEvent e) {
        // no hopping to other players or worlds from the spectator menu
        if (e.getCause() == org.bukkit.event.player.PlayerTeleportEvent.TeleportCause.SPECTATE && fallen.containsKey(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    Location spectate() { Location s = loc("arena.spectate"); return s != null ? s : loc("arena.spawn"); }

    /** A random safe spot on the arena floor: solid block below, two blocks of air, no lava, magma or cactus. */
    Location spawnSpot() {
        Location c = loc("arena.center");
        double r = getConfig().getDouble("arena.radius", 20), rin = getConfig().getDouble("arena.spawn-min-radius", 8);
        for (int t = 0; t < 30; t++) {
            double a = rng.nextDouble() * Math.PI * 2, d = rin + rng.nextDouble() * (r - 2 - rin);
            int x = (int) Math.floor(c.getX() + Math.cos(a) * d), z = (int) Math.floor(c.getZ() + Math.sin(a) * d);
            for (int y = c.getBlockY() + 4; y >= c.getBlockY() - 4; y--) {
                Block b = c.getWorld().getBlockAt(x, y, z);
                Material m = b.getType();
                if (!m.isSolid() || m == Material.MAGMA_BLOCK || m == Material.CACTUS) continue;
                if (!b.getRelative(0, 1, 0).isPassable() || !b.getRelative(0, 2, 0).isPassable()) break;
                if (b.getRelative(0, 1, 0).isLiquid()) break;
                return b.getLocation().add(0.5, 1, 0.5);
            }
        }
        return c.clone().add(0, 1, 0);
    }

    EntityType pickType() {
        List<EntityType> pool = new ArrayList<>(List.of(EntityType.ZOMBIE, EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER));
        if (wave >= 3) pool.addAll(List.of(EntityType.HUSK, EntityType.STRAY, EntityType.CAVE_SPIDER));
        if (wave >= 6) pool.addAll(List.of(EntityType.CREEPER, EntityType.WITCH, EntityType.ZOMBIE_VILLAGER));
        if (wave >= 9) pool.addAll(List.of(EntityType.VINDICATOR, EntityType.PILLAGER, EntityType.BOGGED));
        if (wave >= 13) pool.addAll(List.of(EntityType.WITHER_SKELETON, EntityType.BLAZE, EntityType.PIGLIN_BRUTE));
        if (wave >= 18) pool.addAll(List.of(EntityType.RAVAGER, EntityType.EVOKER, EntityType.VINDICATOR));
        return pool.get(rng.nextInt(pool.size()));
    }

    LivingEntity spawnMob() { return spawnMob(pickType(), spawnSpot()); }

    LivingEntity spawnMob(EntityType type, Location at) {
        Entity e = at.getWorld().spawnEntity(at, type, CreatureSpawnEvent.SpawnReason.CUSTOM);
        if (!(e instanceof LivingEntity le)) { e.remove(); return null; }
        le.addScoreboardTag(TAG);
        le.setRemoveWhenFarAway(false);
        le.setPersistent(false);
        if (le instanceof org.bukkit.entity.Ageable ag) ag.setAdult();
        if (le instanceof org.bukkit.entity.PiglinAbstract pa) pa.setImmuneToZombification(true);
        double hp = (1 + getConfig().getDouble("scaling.health-per-wave", 0.08) * (wave - 1)) * ease("health-mult", 0.8);
        scale(le, Attribute.MAX_HEALTH, hp);
        le.setHealth(attr(le, Attribute.MAX_HEALTH));
        scale(le, Attribute.ATTACK_DAMAGE, (1 + getConfig().getDouble("scaling.damage-per-wave", 0.04) * (wave - 1)) * ease("damage-mult", 0.65));
        if (le.getEquipment() != null) le.getEquipment().setHelmetDropChance(0);
        return le;
    }

    static void scale(LivingEntity e, Attribute a, double mult) {
        AttributeInstance ai = e.getAttribute(a);
        if (ai != null) ai.setBaseValue(ai.getBaseValue() * mult);
    }

    static double attr(LivingEntity e, Attribute a) { AttributeInstance ai = e.getAttribute(a); return ai == null ? 20 : ai.getValue(); }

    // ---------- bosses ----------
    static final String[][] BOSSES = {
            {"ZOMBIE", "§4Gravewarden"}, {"WITHER_SKELETON", "§4The Bone Tyrant"}, {"VINDICATOR", "§4The Executioner"},
            {"RAVAGER", "§4Ravager Warlord"}, {"EVOKER", "§5The Hollow Magus"}, {"PIGLIN_BRUTE", "§6Brute of the Pit"}};
    private long nextAbility;

    void spawnBoss() {
        int tier = wave / getConfig().getInt("boss-every", 5);
        String[] b = BOSSES[(tier - 1) % BOSSES.length].clone();
        b[1] = ConfigSync.c(getConfig().getString("boss-names." + b[0].toLowerCase(Locale.ROOT), b[1].replace('§', '&')));
        Location c = loc("arena.center");
        LivingEntity e = spawnMob(EntityType.valueOf(b[0]), c.clone().add(0, 1, 0));
        if (e == null) return;
        e.addScoreboardTag(BOSS_TAG);
        double hp = getConfig().getDouble("boss.base-health", 120) * (1 + 0.5 * (fighters.size() - 1)) * (1 + 0.25 * (tier - 1)) * ease("boss-health-mult", 0.75);
        AttributeInstance mh = e.getAttribute(Attribute.MAX_HEALTH);
        if (mh != null) { mh.setBaseValue(hp); e.setHealth(hp); }
        AttributeInstance sc = e.getAttribute(Attribute.SCALE);
        if (sc != null && !b[0].equals("RAVAGER")) sc.setBaseValue(1.5);
        AttributeInstance kb = e.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
        if (kb != null) kb.setBaseValue(0.8);
        e.customName(Component.text(b[1]));
        e.getPersistentDataContainer().set(new org.bukkit.NamespacedKey("darkholmarena", "name"), org.bukkit.persistence.PersistentDataType.STRING, b[1].substring(2));
        e.setCustomNameVisible(true);
        boss = e;
        bossBar.setTitle(b[1] + " §7(wave " + wave + ")");
        bossBar.setProgress(1);
        nextAbility = System.currentTimeMillis() + 6000;
    }

    void bossTick(List<Player> alive) {
        if (System.currentTimeMillis() < nextAbility || alive.isEmpty()) return;
        nextAbility = System.currentTimeMillis() + 6000 + rng.nextInt(4000);
        Location bl = boss.getLocation();
        switch (rng.nextInt(5)) {
            case 0 -> { // knock-up
                for (Player p : alive) if (p.getLocation().distanceSquared(bl) < 100) p.setVelocity(p.getVelocity().add(new Vector(0, 1.1, 0)));
                announce(T("boss-slam", "&c{boss} slams the ground!", "boss", plain(boss)));
                bl.getWorld().playSound(bl, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.5f, 0.6f);
            }
            case 1 -> { // arrow barrage
                announce(T("boss-barrage", "&c{boss} looses a barrage!", "boss", plain(boss)));
                for (int i = 0; i < 10; i++) {
                    final int k = i;
                    Bukkit.getScheduler().runTaskLater(this, () -> {
                        if (boss == null || boss.isDead()) return;
                        Player t = alive.get(rng.nextInt(alive.size()));
                        if (!t.isOnline()) return;
                        Location from = boss.getEyeLocation();
                        Vector dir = t.getEyeLocation().toVector().subtract(from.toVector()).normalize();
                        Arrow a = boss.getWorld().spawnArrow(from.add(dir), dir, 1.8f, 6f);
                        a.setShooter(boss);
                        a.setPickupStatus(org.bukkit.entity.AbstractArrow.PickupStatus.DISALLOWED);
                        a.addScoreboardTag(TAG);
                    }, k * 3L);
                }
            }
            case 2 -> { // minions
                announce(T("boss-minions", "&c{boss} calls its minions!", "boss", plain(boss)));
                for (int i = 0; i < 2 + fighters.size(); i++) {
                    Location at = bl.clone().add(rng.nextInt(7) - 3, 0, rng.nextInt(7) - 3);
                    LivingEntity m = spawnMob(EntityType.ZOMBIE, safeNear(at));
                    if (m != null) m.setGlowing(true);
                }
            }
            case 3 -> { // rain of potions
                announce(T("boss-rain", "&c{boss} calls down a poisoned rain!", "boss", plain(boss)));
                for (Player p : alive) for (int i = 0; i < 3; i++) {
                    Location at = p.getLocation().add(rng.nextInt(7) - 3, 9, rng.nextInt(7) - 3);
                    ThrownPotion tp = p.getWorld().spawn(at, ThrownPotion.class, pot -> {
                        ItemStack it = new ItemStack(Material.SPLASH_POTION);
                        PotionMeta pm = (PotionMeta) it.getItemMeta();
                        pm.setBasePotionType(rng.nextBoolean() ? PotionType.POISON : PotionType.SLOWNESS);
                        it.setItemMeta(pm);
                        pot.setItem(it);
                    });
                    tp.setShooter(boss);
                    tp.setVelocity(new Vector(0, -0.6, 0));
                }
            }
            default -> { // shuffle a hotbar
                Player p = alive.get(rng.nextInt(alive.size()));
                List<ItemStack> hb = new ArrayList<>();
                for (int i = 0; i < 9; i++) hb.add(p.getInventory().getItem(i));
                Collections.shuffle(hb, rng);
                for (int i = 0; i < 9; i++) p.getInventory().setItem(i, hb.get(i));
                title(p, T("boss-scramble-title", "&5Your mind reels"), T("boss-scramble-sub", "&7{boss} scrambled your hotbar", "boss", plain(boss)));
                p.playSound(p.getLocation(), Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1f, 1f);
            }
        }
    }

    Location safeNear(Location at) {
        for (int dy = 3; dy >= -3; dy--) {
            Block b = at.getWorld().getBlockAt(at.getBlockX(), at.getBlockY() + dy, at.getBlockZ());
            if (b.getType().isSolid() && b.getRelative(0, 1, 0).isPassable() && b.getRelative(0, 2, 0).isPassable()) return b.getLocation().add(0.5, 1, 0.5);
        }
        return spawnSpot();
    }

    static String plain(LivingEntity e) {
        String n = e.getPersistentDataContainer().get(new org.bukkit.NamespacedKey("darkholmarena", "name"), org.bukkit.persistence.PersistentDataType.STRING);
        return n != null ? n : e.getName();
    }

    void announce(String s) { for (UUID id : runPlayers()) { Player p = Bukkit.getPlayer(id); if (p != null) bar(p, s); } }

    // ---------- deaths and the end ----------
    int survivedNow() { return Math.max(0, waveLive ? wave - 1 : wave); }

    void fall(Player p, String why) {
        UUID id = p.getUniqueId();
        if (!fighters.remove(id)) return;
        int survived = survivedNow();
        fallen.put(id, survived);
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(spectate());
        p.getInventory().clear();
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        resetHealth(p);
        title(p, T("fallen-title", "&cYou have fallen"), T("fallen-sub", "&7You survived {waves}", "waves", waves(survived)));
        msgRun(T("fallen-broadcast", "&6⚔ &c{player} &7has fallen{why} &7on wave &e{wave}&7.", "player", p.getName(), "why", why == null ? "" : " " + why, "wave", wave));
    }

    /** Sends a player to the leave warp directly (no Essentials warmup or cooldown). */
    void sendOut(Player p) {
        String name = getConfig().getString("leave-warp", "hub");
        try {
            File f = new File(getDataFolder().getParentFile(), "Essentials/warps/" + name.toLowerCase(Locale.ROOT) + ".yml");
            if (f.exists()) {
                YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
                World w = null;
                String wid = y.getString("world");
                if (wid != null) try { w = Bukkit.getWorld(UUID.fromString(wid)); } catch (IllegalArgumentException ignored) {}
                if (w == null && y.getString("world-name") != null) w = Bukkit.getWorld(y.getString("world-name"));
                if (w != null) {
                    p.teleport(new Location(w, y.getDouble("x"), y.getDouble("y"), y.getDouble("z"), (float) y.getDouble("yaw"), (float) y.getDouble("pitch")));
                    return;
                }
            }
        } catch (Exception ex) { getLogger().warning("Leave warp failed: " + ex.getMessage()); }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "warp " + name + " " + p.getName());
    }

    void endRun(String reason) {
        if (!running) return;
        int survivors = survivedNow();
        running = false;
        waveLive = false;
        bossBar.removeAll();
        boss = null;
        World w = world();
        for (Entity e : w.getEntities()) if (e.getScoreboardTags().contains(TAG)) e.remove();
        for (UUID id : new ArrayList<>(fighters)) fallen.put(id, survivors);
        fighters.clear();
        int best = 0;
        String bestName = "";
        for (Map.Entry<UUID, Integer> en : fallen.entrySet()) {
            UUID id = en.getKey();
            int s = en.getValue();
            Player p = Bukkit.getPlayer(id);
            String name = p != null ? p.getName() : data.getString("players." + id + ".name", "?");
            reward(id, name, s);
            if (s > best) { best = s; bestName = name; }
            if (p != null) {
                p.getInventory().clear();
                for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
                resetHealth(p);
                if (inWorld(p)) {
                    if (p.getGameMode() == GameMode.SPECTATOR) p.setGameMode(GameMode.SURVIVAL);
                    if (getConfig().getBoolean("end-to-hub", true)) sendOut(p);
                    else { toLobby(p); prepLobby(p); }
                }
                if (reason != null) p.sendMessage(T("run-ended", "&6⚔ &7{reason}", "reason", reason));
            }
        }
        int record = data.getInt("record.wave", 0);
        if (best > record && best > 0) {
            data.set("record.wave", best);
            data.set("record.names", String.join(", ", names(fallen.keySet())));
            if (getConfig().getBoolean("announce-records", true)) Bukkit.broadcast(Component.text(T("record", "&6⚔ &eNew Mob Arena record! &6{players} &esurvived &6{waves} &ewaves.", "players", String.join(", ", names(fallen.keySet())), "waves", best)));
        }
        fallen.clear();
        runClass.clear();
        saveData();
        if (!ready.isEmpty()) countdown = getConfig().getInt("countdown-seconds", 300);
    }

    List<String> names(Set<UUID> ids) {
        List<String> l = new ArrayList<>();
        for (UUID id : ids) { Player p = Bukkit.getPlayer(id); l.add(p != null ? p.getName() : data.getString("players." + id + ".name", "?")); }
        return l;
    }

    String keyName(int waveNo) {
        return waveNo > getConfig().getInt("rewards.emerald-after-wave", 20) ? "Emerald" : "random";
    }

    void reward(UUID id, String name, int survived) {
        String base = "players." + id;
        data.set(base + ".name", name);
        data.set(base + ".runs", data.getInt(base + ".runs") + 1);
        if (survived > data.getInt(base + ".best")) data.set(base + ".best", survived);
        double cash = survived * getConfig().getDouble("rewards.cash-per-wave", 100);
        int every = getConfig().getInt("boss-every", 5);
        int emeraldAfter = getConfig().getInt("rewards.emerald-after-wave", 20);
        List<String> pool = getConfig().getStringList("rewards.key-pool");
        if (pool.isEmpty()) pool = List.of("bronze", "silver", "gold");
        List<String> keys = new ArrayList<>(data.getStringList(base + ".pending-keys"));
        List<String> got = new ArrayList<>();
        for (int w = every; w <= survived; w += every) {
            String k = w > emeraldAfter ? getConfig().getString("rewards.emerald-key", "emerald") : pool.get(rng.nextInt(pool.size()));
            keys.add(k);
            got.add(k);
        }
        data.set(base + ".pending-keys", keys);
        data.set(base + ".pending-cash", data.getDouble(base + ".pending-cash") + cash);
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            StringBuilder sb = new StringBuilder(T("run-over", "&6⚔ &eArena run over. &7You survived &e{waves}&7.", "waves", waves(survived)));
            if (cash > 0) sb.append("\n").append(T("run-over-cash", "&7  Reward: &a${cash} &7Factions cash, paid to your Factions purse.", "cash", String.format("%,.0f", cash)));
            if (!got.isEmpty()) sb.append("\n").append(T("run-over-keys", "&7  Keys: &6{keys}", "keys", String.join(", ", got)));
            p.sendMessage(sb.toString());
        }
    }

    /** In the hub, DarkholmHubInventory loads the purse of the player's last realm. Pay there only when that realm is Factions. */
    boolean hubHoldsFactionsPurse(Player p) {
        if (!p.getWorld().getName().equalsIgnoreCase(getConfig().getString("rewards.hub-world", "hub"))) return false;
        File f = new File(getDataFolder().getParentFile(), "DarkholmHubInventory/last-groups.yml");
        String last = f.isFile() ? org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(f).getString(p.getUniqueId().toString(), "default") : "default";
        return last.equalsIgnoreCase(getConfig().getString("rewards.hub-cash-group", "default"));
    }

    /** Keys go out anywhere; cash only lands while the player stands in a Factions world (each realm keeps its own purse). */
    void payPending(Player p) {
        String base = "players." + p.getUniqueId();
        if (!data.contains(base)) return;
        List<String> keys = data.getStringList(base + ".pending-keys");
        if (!keys.isEmpty()) {
            Map<String, Integer> n = new HashMap<>();
            for (String k : keys) n.merge(k, 1, Integer::sum);
            for (Map.Entry<String, Integer> e : n.entrySet())
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "cratekey give " + p.getName() + " " + e.getKey() + " " + e.getValue());
            data.set(base + ".pending-keys", null);
            saveData();
        }
        double cash = data.getDouble(base + ".pending-cash");
        if (cash > 0 && (getConfig().getStringList("rewards.cash-worlds").contains(p.getWorld().getName().toLowerCase(Locale.ROOT)) || hubHoldsFactionsPurse(p))) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "eco give " + p.getName() + " " + String.format(Locale.ROOT, "%.0f", cash));
            p.sendMessage(T("winnings-paid", "&6⚔ &aMob Arena winnings paid: ${cash}", "cash", String.format("%,.0f", cash)));
            data.set(base + ".pending-cash", null);
            saveData();
        }
    }

    // ---------- kits ----------
    static ItemStack named(ItemStack it, String name, List<String> lore) {
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text(name).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        if (lore != null) { List<Component> l = new ArrayList<>(); for (String s : lore) l.add(Component.text(s).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)); m.lore(l); }
        m.setUnbreakable(true);
        it.setItemMeta(m);
        return it;
    }

    static ItemStack ench(Material mat, Object... e) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        for (int i = 0; i + 1 < e.length; i += 2) m.addEnchant((org.bukkit.enchantments.Enchantment) e[i], (Integer) e[i + 1], true);
        m.setUnbreakable(true);
        it.setItemMeta(m);
        return it;
    }

    static ItemStack leather(Material mat, int rgb) {
        ItemStack it = new ItemStack(mat);
        LeatherArmorMeta m = (LeatherArmorMeta) it.getItemMeta();
        m.setColor(org.bukkit.Color.fromRGB(rgb));
        m.setUnbreakable(true);
        it.setItemMeta(m);
        return it;
    }

    static ItemStack drink(int n, PotionType t) {
        ItemStack it = new ItemStack(Material.POTION, n);
        PotionMeta m = (PotionMeta) it.getItemMeta();
        m.setBasePotionType(t);
        it.setItemMeta(m);
        return it;
    }

    static ItemStack potion(int n, PotionType t) {
        ItemStack it = new ItemStack(Material.SPLASH_POTION, n);
        PotionMeta m = (PotionMeta) it.getItemMeta();
        m.setBasePotionType(t);
        it.setItemMeta(m);
        return it;
    }

    static List<String> classInfo(String c) {
        return switch (c) {
            case "ranger" -> I.TL("classes.ranger.info", List.of("&7Strike from range.", "&7Infinity bow and Speed."));
            case "soldier" -> I.TL("classes.soldier.info", List.of("&7Sword and shield,", "&7full iron armour."));
            case "healer" -> I.TL("classes.healer.info", List.of("&7Right-click the &dMending Staff &7to heal", "&7everyone near you (15s cooldown).", "&7Healing potions refill each wave."));
            case "tank" -> I.TL("classes.tank.info", List.of("&7Extra hearts and a diamond chest.", "&7Blow the &9War Horn &7to pull every", "&7nearby foe onto you (20s cooldown)."));
            default -> I.TL("classes.berserker.info", List.of("&7Strength I, and each kill heals you.", "&7Right-click &6Blood Rage &7for Strength II", "&7and Speed II for 8s (30s cooldown)."));
        };
    }

    static final org.bukkit.enchantments.Enchantment SHARP = org.bukkit.enchantments.Enchantment.SHARPNESS;

    List<ItemStack> kit(String c) {
        List<ItemStack> k = new ArrayList<>();
        switch (c) {
            case "ranger" -> {
                k.add(ench(Material.BOW, org.bukkit.enchantments.Enchantment.POWER, 2, org.bukkit.enchantments.Enchantment.INFINITY, 1, org.bukkit.enchantments.Enchantment.PUNCH, 1));
                k.add(ench(Material.STONE_SWORD));
                k.add(new ItemStack(Material.ARROW));
                k.add(new ItemStack(Material.COOKED_BEEF, 8));
                k.add(new ItemStack(Material.CHAINMAIL_HELMET));
                k.add(leather(Material.LEATHER_CHESTPLATE, 0x3B5323));
                k.add(leather(Material.LEATHER_LEGGINGS, 0x3B5323));
                k.add(leather(Material.LEATHER_BOOTS, 0x4A3728));
            }
            case "soldier" -> {
                k.add(ench(Material.IRON_SWORD, SHARP, 1));
                k.add(ench(Material.SHIELD));
                k.add(new ItemStack(Material.COOKED_BEEF, 8));
                k.add(new ItemStack(Material.IRON_HELMET));
                k.add(new ItemStack(Material.IRON_CHESTPLATE));
                k.add(new ItemStack(Material.IRON_LEGGINGS));
                k.add(new ItemStack(Material.IRON_BOOTS));
            }
            case "healer" -> {
                k.add(ench(Material.STONE_SWORD));
                k.add(named(new ItemStack(Material.BLAZE_ROD), T("item-staff-name", "&dMending Staff"), TL("messages.item-staff-lore", List.of("&7Right-click: heal everyone within 8 blocks."))));
                k.add(potion(4, PotionType.HEALING));
                k.add(potion(2, PotionType.REGENERATION));
                k.add(new ItemStack(Material.GOLDEN_APPLE, 2));
                k.add(new ItemStack(Material.COOKED_BEEF, 8));
                k.add(new ItemStack(Material.GOLDEN_HELMET));
                k.add(leather(Material.LEATHER_CHESTPLATE, 0xE8E1D0));
                k.add(new ItemStack(Material.CHAINMAIL_LEGGINGS));
                k.add(leather(Material.LEATHER_BOOTS, 0xE8E1D0));
            }
            case "tank" -> {
                k.add(ench(Material.IRON_AXE));
                k.add(ench(Material.SHIELD));
                k.add(named(new ItemStack(Material.GOAT_HORN), T("item-horn-name", "&9War Horn"), TL("messages.item-horn-lore", List.of("&7Right-click: every foe within 14 blocks", "&7turns on you for 6 seconds."))));
                k.add(new ItemStack(Material.COOKED_BEEF, 8));
                k.add(new ItemStack(Material.IRON_HELMET));
                k.add(new ItemStack(Material.DIAMOND_CHESTPLATE));
                k.add(new ItemStack(Material.IRON_LEGGINGS));
                k.add(new ItemStack(Material.IRON_BOOTS));
            }
            default -> {
                k.add(ench(Material.IRON_AXE, SHARP, 2));
                k.add(named(new ItemStack(Material.BLAZE_POWDER), T("item-rage-name", "&6Blood Rage"), TL("messages.item-rage-lore", List.of("&7Right-click: Strength II and Speed II for 8s."))));
                k.add(new ItemStack(Material.COOKED_BEEF, 8));
                k.add(leather(Material.LEATHER_HELMET, 0x6B2A1A));
                k.add(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
                k.add(leather(Material.LEATHER_LEGGINGS, 0x6B2A1A));
                k.add(leather(Material.LEATHER_BOOTS, 0x4A3728));
            }
        }
        k.add(k.size() > 1 ? 2 : k.size(), drink(getConfig().getInt("starter-healing-potions", 3), PotionType.HEALING));
        for (ItemStack it : k) {
            ItemMeta m = it.getItemMeta();
            if (m != null && it.getType().getMaxDurability() > 0) { m.setUnbreakable(true); it.setItemMeta(m); }
        }
        return k;
    }

    void equip(Player p, String c) {
        p.getInventory().clear();
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        resetHealth(p);
        for (ItemStack it : kit(c)) {
            String n = it.getType().name();
            if (n.endsWith("_HELMET")) p.getInventory().setHelmet(it);
            else if (n.endsWith("_CHESTPLATE")) p.getInventory().setChestplate(it);
            else if (n.endsWith("_LEGGINGS")) p.getInventory().setLeggings(it);
            else if (n.endsWith("_BOOTS")) p.getInventory().setBoots(it);
            else if (it.getType() == Material.SHIELD) p.getInventory().setItemInOffHand(it);
            else p.getInventory().addItem(it);
        }
        int inf = PotionEffect.INFINITE_DURATION;
        switch (c) {
            case "ranger" -> p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, inf, 0, false, false));
            case "tank" -> {
                AttributeInstance mh = p.getAttribute(Attribute.MAX_HEALTH);
                if (mh != null) mh.setBaseValue(28);
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, inf, 0, false, false));
            }
            case "berserker" -> p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, inf, 0, false, false));
            default -> { }
        }
        p.setHealth(attr(p, Attribute.MAX_HEALTH));
        p.setFoodLevel(20);
        p.setSaturation(10);
    }

    void refill(Player p, String c) {
        if (c.equals("healer")) {
            top(p, Material.SPLASH_POTION, potion(4, PotionType.HEALING), 4);
        }
        top(p, Material.COOKED_BEEF, new ItemStack(Material.COOKED_BEEF, 8), 8);
    }

    static void top(Player p, Material m, ItemStack proto, int want) {
        int have = 0;
        for (ItemStack it : p.getInventory().getContents()) if (it != null && it.getType() == m) have += it.getAmount();
        if (have < want) { ItemStack add = proto.clone(); add.setAmount(want - have); p.getInventory().addItem(add); }
    }

    static void resetHealth(Player p) {
        AttributeInstance mh = p.getAttribute(Attribute.MAX_HEALTH);
        if (mh != null) mh.setBaseValue(20);
        p.setHealth(Math.min(20, attr(p, Attribute.MAX_HEALTH)));
        p.setFireTicks(0);
    }

    boolean cooldown(Player p, String key, int seconds) {
        long now = System.currentTimeMillis();
        String k = p.getUniqueId() + ":" + key;
        Long u = cdMap.get(k);
        if (u != null && u > now) { bar(p, T("ability-cooldown", "&7Ready in &e{seconds}s", "seconds", (u - now) / 1000 + 1)); return false; }
        cdMap.put(k, now + seconds * 1000L);
        return true;
    }
    private final Map<String, Long> cdMap = new HashMap<>();

    // ---------- events ----------
    @EventHandler public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (!inWorld(p) || e.getHand() != EquipmentSlot.HAND) return;
        boolean lc = e.getAction() == Action.LEFT_CLICK_BLOCK, rc = e.getAction() == Action.RIGHT_CLICK_BLOCK;
        if (inLobby(p) && (lc || rc) && e.getClickedBlock() != null) {
            String k = blockKey(e.getClickedBlock());
            ConfigurationSection cs = getConfig().getConfigurationSection("lobby-classes");
            if (cs != null) for (String c : cs.getKeys(false)) {
                if (k.equals(cs.getString(c))) { e.setCancelled(true); if (lc) openPreview(p, c); else pickClass(p, c); return; }
            }
            if (lc) return;
            if (k.equals(getConfig().getString("ready-block")) && p.getGameMode() != GameMode.SPECTATOR) { e.setCancelled(true); p.playSound(p.getLocation(), Sound.BLOCK_BELL_USE, 1f, 1f); setReady(p); return; }
        }
        if (!fighters.contains(p.getUniqueId())) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null) return;
        if (it.getType() == Material.BLAZE_ROD && "healer".equals(runClass.get(p.getUniqueId()))) {
            e.setCancelled(true);
            if (!cooldown(p, "staff", 15)) return;
            int n = 0;
            for (UUID id : fighters) {
                Player o = Bukkit.getPlayer(id);
                if (o == null || o.getLocation().distanceSquared(p.getLocation()) > 64) continue;
                o.setHealth(Math.min(attr(o, Attribute.MAX_HEALTH), o.getHealth() + 8));
                o.getWorld().spawnParticle(org.bukkit.Particle.HEART, o.getLocation().add(0, 2, 0), 5, 0.4, 0.3, 0.4);
                n++;
            }
            p.playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.6f);
            bar(p, T(n == 1 ? "staff-healed-one" : "staff-healed", n == 1 ? "&dMending Staff healed 1 ally" : "&dMending Staff healed {count} allies", "count", n));
        } else if (it.getType() == Material.GOAT_HORN && "tank".equals(runClass.get(p.getUniqueId()))) {
            e.setCancelled(true);
            if (!cooldown(p, "horn", 20)) return;
            tauntBy = p.getUniqueId();
            tauntUntil = System.currentTimeMillis() + 6000;
            for (Entity en : p.getNearbyEntities(14, 6, 14)) if (en instanceof Mob m && en.getScoreboardTags().contains(TAG)) m.setTarget(p);
            p.getWorld().playSound(p.getLocation(), Sound.ITEM_GOAT_HORN_SOUND_0, 2f, 0.9f);
            msgRun(T("war-horn", "&9{player} blows the War Horn!", "player", p.getName()));
        } else if (it.getType() == Material.BLAZE_POWDER && "berserker".equals(runClass.get(p.getUniqueId()))) {
            e.setCancelled(true);
            if (!cooldown(p, "rage", 30)) return;
            p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 160, 1));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 1));
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 1.2f);
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (fighters.contains(p.getUniqueId())) p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, PotionEffect.INFINITE_DURATION, 0, false, false));
            }, 162L);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p) || !inWorld(p)) return;
        if (!fighters.contains(p.getUniqueId())) { e.setCancelled(true); return; }   // lobby and spectators take no damage
        if (e instanceof EntityDamageByEntityEvent ed) {
            Entity d = ed.getDamager();
            if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
            if (d instanceof Player) { e.setCancelled(true); return; }                 // no friendly fire
        }
        if (e.getFinalDamage() >= p.getHealth()) {
            e.setCancelled(true);
            fall(p, null);
        }
    }

    @EventHandler public void onMobDamage(EntityDamageByEntityEvent e) {
        // arena mobs don't hurt each other with stray arrows
        if (e.getEntity().getScoreboardTags().contains(TAG)) {
            Entity d = e.getDamager();
            if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
            if (d.getScoreboardTags().contains(TAG) && d != e.getEntity()) e.setCancelled(true);
        }
    }

    @EventHandler public void onDeath(EntityDeathEvent e) {
        if (!e.getEntity().getScoreboardTags().contains(TAG)) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        Player k = e.getEntity().getKiller();
        if (k != null && fighters.contains(k.getUniqueId()) && "berserker".equals(runClass.get(k.getUniqueId())))
            k.setHealth(Math.min(attr(k, Attribute.MAX_HEALTH), k.getHealth() + 3));
        if (e.getEntity().getScoreboardTags().contains(BOSS_TAG)) {
            msgRun(T("boss-slain", "&6⚔ &e{boss} &7has been slain!", "boss", plain(e.getEntity())));
            boss = null;
        }
    }

    @EventHandler public void onTarget(EntityTargetEvent e) {
        if (e.getEntity().getScoreboardTags().contains(TAG) && e.getTarget() != null && e.getTarget().getScoreboardTags().contains(TAG)) e.setCancelled(true);
    }

    @EventHandler public void onCombust(org.bukkit.event.entity.EntityCombustEvent e) {
        // arena undead don't burn in daylight (the arena world shares the overworld clock)
        if (e.getEntity().getScoreboardTags().contains(TAG) && !(e instanceof org.bukkit.event.entity.EntityCombustByEntityEvent)
                && !(e instanceof org.bukkit.event.entity.EntityCombustByBlockEvent)) e.setCancelled(true);
    }

    @EventHandler public void onExplode(EntityExplodeEvent e) { if (e.getEntity().getWorld().equals(world())) e.blockList().clear(); }

    @EventHandler public void onSpawn(CreatureSpawnEvent e) {
        if (e.getEntity().getWorld().equals(world()) && e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM
                && e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.SPAWNER_EGG && e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.COMMAND) {
            if (running && (e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPELL || e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.DEFAULT)) {
                e.getEntity().addScoreboardTag(TAG);   // evoker vexes and fangs count as arena foes
                return;
            }
            e.setCancelled(true);
        }
    }

    @EventHandler public void onFood(FoodLevelChangeEvent e) { if (e.getEntity() instanceof Player p && inLobby(p)) e.setCancelled(true); }

    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (inWorld(e.getPlayer()) && !e.getPlayer().hasPermission("darkholm.arena.admin")) e.setCancelled(true); }

    @EventHandler public void onBreak(BlockBreakEvent e) { if (inWorld(e.getPlayer()) && !e.getPlayer().hasPermission("darkholm.arena.admin")) e.setCancelled(true); }

    @EventHandler public void onPlace(BlockPlaceEvent e) { if (inWorld(e.getPlayer()) && !e.getPlayer().hasPermission("darkholm.arena.admin")) e.setCancelled(true); }

    @EventHandler public void onWorld(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        World w = world();
        if (w == null) return;
        if (e.getFrom().equals(w)) {
            if (fighters.contains(p.getUniqueId())) fall(p, T("why-fled", "and fled"));
            ready.remove(p.getUniqueId());
            chosen.remove(p.getUniqueId());
            resetHealth(p);
            if (p.getGameMode() == GameMode.SPECTATOR) p.setGameMode(GameMode.SURVIVAL);
        }
        if (p.getWorld().equals(w)) Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.getWorld().equals(w)) return;
            if (inLobby(p)) prepLobby(p);
            else if (fallen.containsKey(p.getUniqueId())) p.setGameMode(GameMode.SPECTATOR);
            else if (!fighters.contains(p.getUniqueId())) p.setGameMode(GameMode.ADVENTURE);
        }, 5L);
        // Inventory plugins can restore a saved game mode a little later; enforce it again.
        if (p.getWorld().equals(w)) Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.getWorld().equals(w)) return;
            if (fallen.containsKey(p.getUniqueId())) p.setGameMode(GameMode.SPECTATOR);
            else if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SURVIVAL) p.setGameMode(GameMode.ADVENTURE);
        }, 40L);
        Bukkit.getScheduler().runTaskLater(this, () -> payPending(p), 40L);
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (fighters.contains(p.getUniqueId())) fall(p, T("why-left", "and left"));
        ready.remove(p.getUniqueId());
        chosen.remove(p.getUniqueId());
        if (inWorld(p)) {
            p.getInventory().clear();
            resetHealth(p);
            if (p.getGameMode() == GameMode.SPECTATOR) p.setGameMode(GameMode.ADVENTURE);
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (inWorld(p)) { toLobby(p); prepLobby(p); }
            payPending(p);
        }, 30L);
    }

    // ---------- commands ----------
    @Override public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "join";
        Player p = s instanceof Player pp ? pp : null;
        boolean admin = s.hasPermission("darkholm.arena.admin");
        switch (sub) {
            case "join" -> { if (p == null) return true; if (fighters.contains(p.getUniqueId())) return true; toLobby(p); }
            case "leave" -> {
                if (p == null) return true;
                if (fighters.contains(p.getUniqueId())) fall(p, T("why-fled", "and fled"));
                if (p.getGameMode() == GameMode.SPECTATOR) p.setGameMode(GameMode.SURVIVAL);
                sendOut(p);
            }
            case "unready" -> { if (p != null) unready(p); }
            case "class" -> {
                if (p == null || a.length < 2 || !inLobby(p)) { s.sendMessage("§7/ma class <" + String.join("|", CLASSES) + "> §8(in the lobby)"); return true; }
                String c = a[1].toLowerCase(Locale.ROOT);
                if (c.equals("support")) c = "healer";
                if (!CLASSES.contains(c)) { s.sendMessage("§cClasses: " + String.join(", ", CLASSES)); return true; }
                pickClass(p, c);
            }
            case "top" -> {
                ConfigurationSection ps = data.getConfigurationSection("players");
                List<String[]> rows = new ArrayList<>();
                if (ps != null) for (String id : ps.getKeys(false)) rows.add(new String[]{ps.getString(id + ".name", "?"), String.valueOf(ps.getInt(id + ".best"))});
                rows.sort((x, y) -> Integer.parseInt(y[1]) - Integer.parseInt(x[1]));
                s.sendMessage(T("top-header", "&6⚔ Mob Arena: most waves survived"));
                for (int i = 0; i < Math.min(10, rows.size()); i++) s.sendMessage(T("top-line", "&e{place}. &f{player} &7- &6{waves}", "place", i + 1, "player", rows.get(i)[0], "waves", rows.get(i)[1]));
            }
            case "stats" -> {
                if (p == null) return true;
                String b = "players." + p.getUniqueId();
                s.sendMessage(T("stats", "&6⚔ &7Your best: &e{best} waves &7over &e{runs} runs&7. Server record: &6{record} &7({names})", "best", data.getInt(b + ".best"), "runs", data.getInt(b + ".runs"), "record", data.getInt("record.wave"), "names", data.getString("record.names", "-")));
            }
            case "setlobby", "setspawn", "setspectate", "setcenter", "setready", "setclass" -> {
                if (!admin || p == null) { s.sendMessage("§cAdmins only, in game."); return true; }
                switch (sub) {
                    case "setlobby" -> getConfig().set("lobby", str(p.getLocation(), true));
                    case "setspawn" -> getConfig().set("arena.spawn", str(p.getLocation(), true));
                    case "setspectate" -> getConfig().set("arena.spectate", str(p.getLocation(), true));
                    case "setcenter" -> {
                        getConfig().set("arena.center", p.getLocation().getBlockX() + 0.5 + "," + (p.getLocation().getBlockY() - 1) + "," + (p.getLocation().getBlockZ() + 0.5));
                        if (a.length > 1) getConfig().set("arena.radius", Double.parseDouble(a[1]));
                    }
                    case "setready" -> { Block b = p.getTargetBlockExact(6); if (b == null) return true; getConfig().set("ready-block", blockKey(b)); }
                    default -> {
                        Block b = p.getTargetBlockExact(6);
                        if (b == null || a.length < 2 || !CLASSES.contains(a[1])) { s.sendMessage("§7/ma setclass <class> while looking at its station block"); return true; }
                        getConfig().set("lobby-classes." + a[1], blockKey(b));
                    }
                }
                saveConfig();
                s.sendMessage("§aSaved " + sub + ".");
            }
            case "start" -> { if (admin && !running && !ready.isEmpty()) countdown = 0; }
            case "stop" -> { if (admin) endRun(T("reason-admin", "An admin ended the run.")); }
            case "reload" -> { if (admin) { ConfigSync.sync(this, "rewards.key-pool", "scaling", "boss", "lobby-classes"); s.sendMessage("§aArena config reloaded."); } }
            default -> s.sendMessage(T("help", "&6⚔ Mob Arena &7- /ma join, /ma leave, /ma class <name>, /ma unready, /ma top, /ma stats"));
        }
        return true;
    }
}
