package live.darkholm.menus;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

final class RealmTag extends PlaceholderExpansion {
    private final DarkholmMenus pl;
    RealmTag(DarkholmMenus pl) { this.pl = pl; }
    @Override public String getIdentifier() { return "darkholm"; }
    @Override public String getAuthor() { return "Astidonius_"; }
    @Override public String getVersion() { return pl.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public String onRequest(OfflinePlayer p, String q) {
        if (q.equals("realmtag")) return pl.realmTag(p).replace('&', '§');
        if (q.equals("title")) return pl.title(p).replace('&', '§');
        return null;
    }
}
