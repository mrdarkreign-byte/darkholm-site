package live.darkholm.menus;

import java.util.LinkedHashMap;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * /keys shows a player's crate key balances (ExcellentCrates virtual keys, via PlaceholderAPI).
 * Physical ExcellentCrates key items found in a player's inventory or ender chest are removed and
 * credited to their virtual balance (config keys.convert: physical id -> virtual id).
 */
final class KeyTools implements Listener {
    private static final NamespacedKey KEY_ID = new NamespacedKey("excellentcrates", "key.id");
    private final DarkholmMenus plugin;

    KeyTools(DarkholmMenus plugin) {
        this.plugin = plugin;
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) convert(p, p.getInventory());
        }, 100L, 40L);
    }

    private static final java.util.regex.Pattern HEX = java.util.regex.Pattern.compile("&#([0-9A-Fa-f]{6})");

    private static String c(String s) {
        java.util.regex.Matcher m = HEX.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            StringBuilder r = new StringBuilder("§x");
            for (char ch : m.group(1).toCharArray()) r.append('§').append(ch);
            m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(r.toString()));
        }
        m.appendTail(sb);
        return ChatColor.translateAlternateColorCodes('&', sb.toString());
    }

    boolean show(Player p) {
        ConfigurationSection list = plugin.getConfig().getConfigurationSection("keys.list");
        if (list == null) return true;
        p.sendMessage(c(plugin.getConfig().getString("keys.header", "&6&lYour Crate Keys")));
        int total = 0;
        for (String id : list.getKeys(false)) {
            String raw = me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(p, "%excellentcrates_key_balance_" + id + "%");
            int n;
            try { n = Integer.parseInt(raw.trim()); } catch (NumberFormatException ex) { n = 0; }
            total += n;
            p.sendMessage(c(plugin.getConfig().getString("keys.line", "&8» %name%&7: %color%%amount%")
                .replace("%name%", list.getString(id, id))
                .replace("%color%", n > 0 ? "&a" : "&8")
                .replace("%amount%", String.valueOf(n))));
        }
        if (total > 0) p.sendMessage(c(plugin.getConfig().getString("keys.footer", "&7Open crates in the Great Hall at Darkholm castle.")));
        return true;
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            convert(p, p.getInventory());
            convert(p, p.getEnderChest());
        }, 40L);
    }

    private void convert(Player p, Inventory inv) {
        ConfigurationSection map = plugin.getConfig().getConfigurationSection("keys.convert");
        if (map == null || !plugin.getConfig().getBoolean("keys.convert-enabled", true)) return;
        Map<String, Integer> found = new LinkedHashMap<>();
        ItemStack[] items = inv.getContents();
        for (int i = 0; i < items.length; i++) {
            ItemStack it = items[i];
            if (it == null || !it.hasItemMeta()) continue;
            ItemMeta meta = it.getItemMeta();
            String id = meta.getPersistentDataContainer().get(KEY_ID, PersistentDataType.STRING);
            if (id == null) continue;
            String target = map.getString(id);
            if (target == null || target.isEmpty()) continue;
            found.merge(target, it.getAmount(), Integer::sum);
            inv.setItem(i, null);
        }
        if (found.isEmpty()) return;
        ConfigurationSection names = plugin.getConfig().getConfigurationSection("keys.list");
        found.forEach((id, n) -> {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "cratekey give " + p.getName() + " " + id + " " + n);
            String name = names != null ? names.getString(id, id) : id;
            p.sendMessage(c(plugin.getConfig().getString("keys.converted", "&7Your &f%name% &7x%amount% was added to your key balance. Check it with &e/keys&7.")
                .replace("%name%", name).replace("%amount%", String.valueOf(n))));
            plugin.getLogger().info("Converted " + n + " physical " + id + " key(s) for " + p.getName());
        });
    }
}
