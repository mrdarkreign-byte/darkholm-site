package live.darkholm.menus;

import java.io.File;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Opens a zMenu screen when a player types a bare command (e.g. "/f" or "/ob") with no arguments.
 * Commands with arguments ("/f claim one") pass through to the original plugin untouched.
 * Also provides %darkholm_realmtag%: the kingdom name in Kingdoms worlds, the faction name elsewhere.
 */
public final class DarkholmMenus extends JavaPlugin implements Listener {
    private final Map<String, String> menus = new HashMap<>();
    private final Set<String> kingdomWorlds = new HashSet<>();
    private final Set<String> hubWorlds = new HashSet<>();
    private final Set<String> factionWorlds = new HashSet<>();
    /** Last world each player stood in outside the hub. */
    private final Map<UUID, String> lastRealm = new ConcurrentHashMap<>();
    private File lastFile;
    private boolean dirty;

    @Override public void onEnable() {
        ConfigSync.sync(this, "bare-commands", "playtime-ranks.tiers", "keys.list", "keys.convert", "notices");
        load();
        lastFile = new File(getDataFolder(), "last-realm.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(lastFile);
        for (String k : y.getKeys(false)) try { lastRealm.put(UUID.fromString(k), y.getString(k)); } catch (IllegalArgumentException ignored) { }
        getServer().getScheduler().runTaskTimer(this, this::saveLast, 1200L, 1200L);
        getServer().getPluginManager().registerEvents(this, this);
        realmCommands = new RealmCommands(this, factionWorlds, kingdomWorlds);
        getCommand("darkholmmenus").setExecutor((s, c, l, a) -> { ConfigSync.sync(this, "bare-commands", "playtime-ranks.tiers", "keys.list", "keys.convert", "notices"); load(); realmCommands.load(); s.sendMessage(ConfigSync.c(getConfig().getString("messages.reloaded", "&aDarkholmMenus reloaded: {count} bare commands.")).replace("{count}", String.valueOf(menus.size()))); return true; });
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) new RealmTag(this).register();
        founders = new Founders(this);
        playtime = new PlaytimeRanks(this);
        getServer().getPluginManager().registerEvents(new Crier(this), this);
        getServer().getPluginManager().registerEvents(new Notices(this), this);
        KeyTools keys = new KeyTools(this);
        getServer().getPluginManager().registerEvents(keys, this);
        getCommand("keys").setExecutor((s, c, l, a) -> {
            if (s instanceof org.bukkit.entity.Player p) return keys.show(p);
            s.sendMessage(ConfigSync.c(getConfig().getString("messages.players-only", "Players only."))); return true;
        });
        getServer().getPluginManager().registerEvents(new BackpackToChest(this), this);
        NightVision nv = new NightVision(this);
        getCommand("nv").setExecutor((s, c, l, a) -> {
            if (s instanceof org.bukkit.entity.Player p) return nv.toggle(p);
            s.sendMessage(ConfigSync.c(getConfig().getString("messages.players-only", "Players only."))); return true;
        });
    }
    private Founders founders;
    private PlaytimeRanks playtime;
    private RealmCommands realmCommands;

    @Override public void onDisable() { dirty = true; saveLast(); if (founders != null) founders.save(); if (playtime != null) playtime.save(); }

    private void saveLast() {
        if (!dirty) return;
        YamlConfiguration y = new YamlConfiguration();
        lastRealm.forEach((k, v) -> y.set(k.toString(), v));
        try { y.save(lastFile); dirty = false; } catch (Exception ex) { getLogger().warning("Could not save last-realm.yml: " + ex.getMessage()); }
    }

    private void remember(Player p) {
        String w = p.getWorld().getName().toLowerCase(Locale.ROOT);
        if (hubWorlds.contains(w)) return;
        if (!w.equals(lastRealm.put(p.getUniqueId(), w))) dirty = true;
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { remember(e.getPlayer()); founders.join(e.getPlayer()); playtime.join(e.getPlayer()); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { remember(e.getPlayer()); }

    private void load() {
        menus.clear(); kingdomWorlds.clear(); hubWorlds.clear(); factionWorlds.clear();
        for (String w : getConfig().getStringList("faction-worlds")) factionWorlds.add(w.toLowerCase(Locale.ROOT));
        for (String w : getConfig().getStringList("hub-worlds")) hubWorlds.add(w.toLowerCase(Locale.ROOT));
        var sec = getConfig().getConfigurationSection("bare-commands");
        if (sec != null) for (String k : sec.getKeys(false)) menus.put(k.toLowerCase(Locale.ROOT), sec.getString(k));
        for (String w : getConfig().getStringList("kingdom-worlds")) kingdomWorlds.add(w.toLowerCase(Locale.ROOT));
        getLogger().info("Bare commands opening menus: " + menus.keySet());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String m = e.getMessage().trim();
        if (realmCommands != null && realmCommands.check(e.getPlayer(), m)) { e.setCancelled(true); return; }
        if (m.length() < 2 || m.indexOf(' ') >= 0) return;
        String menu = menus.get(m.substring(1).toLowerCase(Locale.ROOT));
        if (menu == null) return;
        Player p = e.getPlayer();
        String perm = getConfig().getString("menu-permissions." + menu, "");
        if (!perm.isEmpty() && !p.hasPermission(perm)) return;
        e.setCancelled(true);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "zm open " + menu + " " + p.getName());
    }

    String realmTag(OfflinePlayer op) {
        if (op == null) return "";
        Player p = op.getPlayer();
        String world = p != null ? p.getWorld().getName().toLowerCase(Locale.ROOT) : lastRealm.get(op.getUniqueId());
        if (world != null && hubWorlds.contains(world)) world = lastRealm.get(op.getUniqueId());
        if (world == null) return "";
        boolean kingdoms = kingdomWorlds.contains(world);
        if (!kingdoms && !factionWorlds.contains(world)) return "";
        String raw = me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(op, kingdoms ? getConfig().getString("kingdom-placeholder", "%kingdoms_kingdom_name%") : getConfig().getString("faction-placeholder", "%factions_faction_name%"));
        return spaced(raw, kingdoms ? getConfig().getString("kingdom-color", "&b") : "");
    }

    String title(OfflinePlayer op) {
        if (op == null) return "";
        return spaced(me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(op, getConfig().getString("title-placeholder", "%darkholmpass_title%")), "");
    }

    private static String spaced(String raw, String color) {
        if (raw == null) return "";
        raw = raw.trim();
        if (raw.isEmpty() || raw.startsWith("%")) return "";
        return color + raw + " ";
    }
}
