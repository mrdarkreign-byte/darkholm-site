package live.darkholm.menus;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.PluginIdentifiableCommand;
import org.bukkit.entity.Player;

/**
 * Keeps each realm's commands in its own worlds: no Factions commands in Kingdoms worlds, and no Kingdoms commands
 * in Factions worlds. A command counts as Factions/Kingdoms when its label is listed, or when the plugin that owns it
 * (or its namespace, e.g. "factions:f") is listed, so every alias is caught.
 */
final class RealmCommands {
    private final DarkholmMenus plugin;
    private final Set<String> factionWorlds, kingdomWorlds;
    private final Set<String> factionPlugins = new HashSet<>(), kingdomPlugins = new HashSet<>();
    private final Set<String> factionLabels = new HashSet<>(), kingdomLabels = new HashSet<>();
    private boolean enabled;
    private String bypass, msgFactions, msgKingdoms;

    RealmCommands(DarkholmMenus plugin, Set<String> factionWorlds, Set<String> kingdomWorlds) {
        this.plugin = plugin; this.factionWorlds = factionWorlds; this.kingdomWorlds = kingdomWorlds;
        load();
    }

    void load() {
        var c = plugin.getConfig();
        enabled = c.getBoolean("realm-commands.enabled", true);
        bypass = c.getString("realm-commands.bypass-permission", "darkholm.realmcommands.bypass");
        fill(factionPlugins, c.getStringList("realm-commands.factions-plugins"), List.of("Factions", "FactionsChat"));
        fill(kingdomPlugins, c.getStringList("realm-commands.kingdoms-plugins"), List.of("Kingdoms", "KingdomsX"));
        fill(factionLabels, c.getStringList("realm-commands.factions-labels"), List.of("f", "faction", "factions"));
        fill(kingdomLabels, c.getStringList("realm-commands.kingdoms-labels"), List.of("k", "kingdom", "kingdoms"));
        msgFactions = color(c.getString("realm-commands.factions-in-kingdoms",
                "&cFactions commands only work in the Factions realm. Here in Kingdoms, use &e/k&c."));
        msgKingdoms = color(c.getString("realm-commands.kingdoms-in-factions",
                "&cKingdoms commands only work in the Kingdoms realm. Here in Factions, use &e/f&c."));
    }

    private static void fill(Set<String> into, List<String> list, List<String> defaults) {
        into.clear();
        for (String s : (list == null || list.isEmpty()) ? defaults : list) into.add(s.toLowerCase(Locale.ROOT));
    }

    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    /** True when the command was blocked (the caller cancels the event). */
    boolean check(Player p, String message) {
        if (!enabled || message.length() < 2 || p.hasPermission(bypass)) return false;
        String world = p.getWorld().getName().toLowerCase(Locale.ROOT);
        boolean inKingdoms = kingdomWorlds.contains(world), inFactions = factionWorlds.contains(world);
        if (!inKingdoms && !inFactions) return false;

        String label = message.substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        if (label.isEmpty()) return false;
        String base = label, namespace = null;
        int colon = label.indexOf(':');
        if (colon >= 0) { namespace = label.substring(0, colon); base = label.substring(colon + 1); }

        String owner = null;
        try {
            Command cmd = Bukkit.getCommandMap().getCommand(label);
            if (cmd instanceof PluginIdentifiableCommand pic) owner = pic.getPlugin().getName().toLowerCase(Locale.ROOT);
        } catch (Throwable ignored) { }

        boolean isFactions = factionLabels.contains(base) || (owner != null && factionPlugins.contains(owner))
                || (namespace != null && factionPlugins.contains(namespace));
        boolean isKingdoms = kingdomLabels.contains(base) || (owner != null && kingdomPlugins.contains(owner))
                || (namespace != null && kingdomPlugins.contains(namespace));

        if (inKingdoms && isFactions && !isKingdoms) { p.sendMessage(msgFactions); return true; }
        if (inFactions && isKingdoms && !isFactions) { p.sendMessage(msgKingdoms); return true; }
        return false;
    }
}
