package live.darkholm.menus;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** /nv toggles permanent night vision (permission darkholm.nightvision). Kept through death, milk, worlds and relogs. */
final class NightVision {
    static final String PERM = "darkholm.nightvision";
    private final DarkholmMenus plugin;
    private final File file;
    private final Set<UUID> on = new HashSet<>();

    NightVision(DarkholmMenus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "nightvision.yml");
        for (String s : YamlConfiguration.loadConfiguration(file).getStringList("enabled"))
            try { on.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) { }
        // Re-apply every 2 s: covers respawn, milk, world changes and inventory plugins clearing effects.
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!on.contains(p.getUniqueId())) continue;
                if (!p.hasPermission(PERM)) { remove(p); continue; }
                PotionEffect cur = p.getPotionEffect(PotionEffectType.NIGHT_VISION);
                if (cur == null || !cur.isInfinite()) apply(p);
            }
        }, 40L, 40L);
    }

    private static void apply(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, true, false, true));
    }

    private static void remove(Player p) {
        PotionEffect cur = p.getPotionEffect(PotionEffectType.NIGHT_VISION);
        if (cur != null && cur.isInfinite()) p.removePotionEffect(PotionEffectType.NIGHT_VISION);
    }

    boolean toggle(Player p) {
        String msg;
        if (on.remove(p.getUniqueId())) {
            remove(p);
            msg = plugin.getConfig().getString("nightvision.off", "&7Night vision &cdisabled&7.");
        } else {
            on.add(p.getUniqueId());
            apply(p);
            msg = plugin.getConfig().getString("nightvision.on", "&7Night vision &aenabled&7. Type &e/nv &7again to turn it off.");
        }
        p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
        save();
        return true;
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("enabled", on.stream().map(UUID::toString).toList());
        try { y.save(file); } catch (IOException ex) { plugin.getLogger().warning("Could not save nightvision.yml: " + ex.getMessage()); }
    }
}
