package live.darkholm.menus;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/** The first N players to join Darkholm get a rank and a thank-you message (on their next join if offline). */
final class Founders {
    private final DarkholmMenus plugin;
    private final File file;
    private final List<String> order = new ArrayList<>();     // uuids in join order
    private final List<String> rewarded = new ArrayList<>();  // uuids already given the rank + message

    Founders(DarkholmMenus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "founders.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        order.addAll(y.getStringList("order"));
        rewarded.addAll(y.getStringList("rewarded"));
        if (!y.getBoolean("seeded")) {
            // Everyone who has already played counts, oldest first.
            OfflinePlayer[] all = Bukkit.getOfflinePlayers();
            Arrays.sort(all, Comparator.comparingLong(OfflinePlayer::getFirstPlayed));
            for (OfflinePlayer op : all) {
                if (op.getFirstPlayed() <= 0) continue;
                String id = op.getUniqueId().toString();
                if (order.size() < limit() && !order.contains(id)) order.add(id);
            }
            plugin.getLogger().info("Founders: seeded " + order.size() + " existing players.");
            save();
        }
        for (Player p : Bukkit.getOnlinePlayers()) join(p);
    }

    int limit() { return plugin.getConfig().getInt("founders.limit", 100); }

    int minSeconds() { return Math.max(5, plugin.getConfig().getInt("founders.min-seconds", 60)); }

    void join(Player p) {
        if (!plugin.getConfig().getBoolean("founders.enabled", true)) return;
        String id = p.getUniqueId().toString();
        if (rewarded.contains(id)) return;
        if (!order.contains(id) && order.size() >= limit()) return;
        String group = plugin.getConfig().getString("founders.group", "squire");
        // A founder slot and the free rank are only given once the player's total time played reaches min-seconds.
        final org.bukkit.scheduler.BukkitTask[] task = new org.bukkit.scheduler.BukkitTask[1];
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || rewarded.contains(id)) { task[0].cancel(); return; }
            if (p.getStatistic(org.bukkit.Statistic.PLAY_ONE_MINUTE) / 20L < minSeconds()) return;
            task[0].cancel();
            if (!order.contains(id)) {
                if (order.size() >= limit()) return;
                order.add(id);
            }
            rewarded.add(id);
            save();
            int n = order.indexOf(id) + 1;
            String has = existingRank(p, group);
            if (has == null) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + p.getUniqueId() + " parent add " + group);
            for (String line : plugin.getConfig().getStringList(has == null ? "founders.message" : "founders.message-ranked"))
                p.sendMessage(ChatColor.translateAlternateColorCodes('&', line.replace("%player%", p.getName()).replace("%number%", String.valueOf(n)).replace("%limit%", String.valueOf(limit()))));
            plugin.getLogger().info("Founders: " + p.getName() + " is founder #" + n + (has == null ? ", given " + group + "." : ", already ranked (" + has + "), rank left alone."));
        }, 100L, 600L);
    }

    /** A LuckPerms group the player already inherits other than default (and the reward group), or null. */
    private static String existingRank(Player p, String reward) {
        for (var a : p.getEffectivePermissions()) {
            String perm = a.getPermission().toLowerCase(java.util.Locale.ROOT);
            if (!a.getValue() || !perm.startsWith("group.")) continue;
            String g = perm.substring(6);
            if (!g.equals("default") && !g.equals(reward.toLowerCase(java.util.Locale.ROOT))) return g;
        }
        return null;
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("seeded", true);
        y.set("order", order);
        y.set("rewarded", rewarded);
        try { y.save(file); } catch (Exception ex) { plugin.getLogger().warning("Could not save founders.yml: " + ex.getMessage()); }
    }
}
