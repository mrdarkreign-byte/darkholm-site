package live.darkholm.menus;

import java.util.List;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import at.pcgamingfreaks.Minepacks.Bukkit.API.Backpack;
import at.pcgamingfreaks.Minepacks.Bukkit.API.MinepacksPlugin;

/**
 * Moves a dying player's Minepacks backpack into the death drops before DeathChest collects them,
 * so the backpack ends up inside the death chest instead of on the ground.
 * Skipped with keepInventory, in configured worlds, and for players with backpack.keepOnDeath.
 */
final class BackpackToChest implements Listener {
    private final DarkholmMenus plugin;
    BackpackToChest(DarkholmMenus plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.getConfig().getBoolean("backpack-to-deathchest.enabled", true)) return;
        if (e.getKeepInventory()) return;
        Player p = e.getEntity();
        if (p.hasPermission("backpack.keepOnDeath")) return;
        List<String> skip = plugin.getConfig().getStringList("backpack-to-deathchest.skip-worlds");
        if (skip.stream().anyMatch(w -> w.equalsIgnoreCase(p.getWorld().getName()))) return;
        Plugin mp = plugin.getServer().getPluginManager().getPlugin("Minepacks");
        if (!(mp instanceof MinepacksPlugin)) return;
        Backpack bp = ((MinepacksPlugin) mp).getBackpackCachedOnly(p);
        if (bp == null) return;
        int moved = 0;
        for (ItemStack it : bp.getInventory().getContents()) {
            if (it == null || it.getType().isAir()) continue;
            e.getDrops().add(it.clone()); moved++;
        }
        if (moved == 0) return;
        bp.clear(); bp.setChanged();
        plugin.getLogger().info("Moved " + moved + " backpack stack(s) of " + p.getName() + " into their death drops");
    }
}
