package live.darkholm.menus;

import java.io.File;
import java.util.*;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Statistic;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/**
 * Free ranks for time played: e.g. 12 hours = squire, 24 hours = knight.
 * A player who already holds that rank or a better one is left alone. Each tier is given once per player.
 */
final class PlaytimeRanks {
    private final DarkholmMenus plugin;
    private final File file;
    private final Map<String, Set<String>> given = new HashMap<>(); // uuid -> groups already granted for playtime

    PlaytimeRanks(DarkholmMenus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playtime-ranks.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) given.put(k, new HashSet<>(y.getStringList(k)));
        long every = Math.max(1, plugin.getConfig().getInt("playtime-ranks.check-minutes", 5)) * 1200L;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> { for (Player p : Bukkit.getOnlinePlayers()) check(p); }, 600L, every);
    }

    private boolean enabled() { return plugin.getConfig().getBoolean("playtime-ranks.enabled", true); }

    /** Group weights; any group not listed here (other than default) counts as better than every reward (staff). */
    private Map<String, Integer> weights() {
        Map<String, Integer> w = new HashMap<>();
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("playtime-ranks.weights");
        if (s != null) for (String k : s.getKeys(false)) w.put(k.toLowerCase(Locale.ROOT), s.getInt(k));
        if (w.isEmpty()) {
            String[] ladder = {"squire", "knight", "baron", "viscount", "earl", "duke", "archduke", "king"};
            for (int i = 0; i < ladder.length; i++) w.put(ladder[i], (i + 1) * 10);
        }
        return w;
    }

    private int bestWeight(Player p, Map<String, Integer> w) {
        int best = 0;
        for (var a : p.getEffectivePermissions()) {
            String perm = a.getPermission().toLowerCase(Locale.ROOT);
            if (!a.getValue() || !perm.startsWith("group.")) continue;
            String g = perm.substring(6);
            if (g.equals("default")) continue;
            best = Math.max(best, w.getOrDefault(g, Integer.MAX_VALUE));
        }
        return best;
    }

    void join(Player p) { Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) check(p); }, 200L); }

    void check(Player p) {
        if (!enabled()) return;
        ConfigurationSection tiers = plugin.getConfig().getConfigurationSection("playtime-ranks.tiers");
        // Default tiers: hours -> group
        List<Object[]> list = new ArrayList<>();
        if (tiers != null) for (String k : tiers.getKeys(false)) list.add(new Object[]{tiers.getDouble(k + ".hours"), tiers.getString(k + ".group", k)});
        else { list.add(new Object[]{12.0, "squire"}); list.add(new Object[]{24.0, "knight"}); }
        list.sort(Comparator.comparingDouble(o -> -(Double) o[0])); // highest first: only the best earned tier is given
        double hours = p.getStatistic(Statistic.PLAY_ONE_MINUTE) / 20.0 / 3600.0;
        Map<String, Integer> w = weights();
        String id = p.getUniqueId().toString();
        Set<String> had = given.computeIfAbsent(id, k -> new HashSet<>());
        for (Object[] t : list) {
            double need = (Double) t[0];
            String group = ((String) t[1]).toLowerCase(Locale.ROOT);
            if (hours < need) continue;
            if (had.contains(group)) return; // best earned tier already given
            had.add(group);
            save();
            int target = w.getOrDefault(group, 0);
            if (bestWeight(p, w) >= target) {
                plugin.getLogger().info("PlaytimeRanks: " + p.getName() + " reached " + (int) need + "h but already ranked; left alone.");
                return;
            }
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + p.getUniqueId() + " parent add " + group);
            String rank = Character.toUpperCase(group.charAt(0)) + group.substring(1);
            String h = String.valueOf((int) need);
            for (String line : plugin.getConfig().getStringList("playtime-ranks.message"))
                p.sendMessage(color(line, p, rank, h));
            String bc = plugin.getConfig().getString("playtime-ranks.broadcast", "");
            if (!bc.isEmpty()) Bukkit.broadcastMessage(color(bc, p, rank, h));
            plugin.getLogger().info("PlaytimeRanks: " + p.getName() + " reached " + h + "h, given " + group + ".");
            return;
        }
    }

    private static String color(String s, Player p, String rank, String hours) {
        return ChatColor.translateAlternateColorCodes('&', s.replace("%player%", p.getName()).replace("%rank%", rank).replace("%hours%", hours));
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        given.forEach((k, v) -> { if (!v.isEmpty()) y.set(k, new ArrayList<>(v)); });
        try { y.save(file); } catch (Exception ex) { plugin.getLogger().warning("Could not save playtime-ranks.yml: " + ex.getMessage()); }
    }
}
