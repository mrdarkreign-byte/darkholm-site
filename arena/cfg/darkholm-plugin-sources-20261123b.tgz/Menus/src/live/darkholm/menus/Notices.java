package live.darkholm.menus;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * One-time notices: config "notices.<id>" with uuid, worlds (list) and message (list).
 * Shown the first time that player is in one of those worlds; delivery is remembered in notices-delivered.yml.
 */
final class Notices implements Listener {
    private final DarkholmMenus plugin;
    private final File file;
    private final YamlConfiguration done;

    Notices(DarkholmMenus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "notices-delivered.yml");
        this.done = YamlConfiguration.loadConfiguration(file);
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { later(e.getPlayer()); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { later(e.getPlayer()); }

    private void later(Player p) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> check(p), 60L);
    }

    private void check(Player p) {
        if (!p.isOnline()) return;
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("notices");
        if (sec == null) return;
        String uuid = p.getUniqueId().toString();
        String world = p.getWorld().getName();
        for (String id : sec.getKeys(false)) {
            ConfigurationSection n = sec.getConfigurationSection(id);
            if (n == null || !uuid.equalsIgnoreCase(n.getString("uuid", ""))) continue;
            List<String> worlds = n.getStringList("worlds");
            if (!worlds.isEmpty() && worlds.stream().noneMatch(world::equalsIgnoreCase)) continue;
            if (done.getBoolean(id + "." + uuid)) continue;
            for (String line : n.getStringList("message"))
                p.sendMessage(ChatColor.translateAlternateColorCodes('&', line.replace("%player%", p.getName())));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1f);
            done.set(id + "." + uuid, true);
            try { done.save(file); } catch (IOException ex) { plugin.getLogger().warning("Could not save notices-delivered.yml: " + ex.getMessage()); }
            plugin.getLogger().info("Delivered notice '" + id + "' to " + p.getName());
        }
    }
}
