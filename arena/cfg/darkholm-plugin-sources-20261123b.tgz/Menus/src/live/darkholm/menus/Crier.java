package live.darkholm.menus;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

/** The town crier: any entity tagged dh_crier greets a player who right-clicks it. */
final class Crier implements Listener {
    private final DarkholmMenus plugin;
    private final Map<UUID, Long> last = new HashMap<>();

    Crier(DarkholmMenus plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!e.getRightClicked().getScoreboardTags().contains("dh_crier")) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        long now = System.currentTimeMillis();
        Long prev = last.get(p.getUniqueId());
        if (prev != null && now - prev < 3000) return;
        last.put(p.getUniqueId(), now);
        for (String line : plugin.getConfig().getStringList("crier.message"))
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', line.replace("%player%", p.getName())));
        p.playSound(e.getRightClicked().getLocation(), Sound.BLOCK_BELL_USE, 1f, 1f);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteractAt(PlayerInteractAtEntityEvent e) {
        if (e.getRightClicked().getScoreboardTags().contains("dh_crier")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity().getScoreboardTags().contains("dh_crier")) e.setCancelled(true);
    }
}
