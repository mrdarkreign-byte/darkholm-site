package live.darkholm.tab;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.List;
import java.util.ArrayList;
import java.util.OptionalInt;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class Tab extends JavaPlugin implements Listener {
    private ZoneId ZONE = ZoneId.of("America/Los_Angeles");
    private DateTimeFormatter DATE = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH);
    private DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH);
    private String header, footer, nameFormat;
    private int nameEvery;
    private static final List<String[]> REALMS = new ArrayList<>();
    private static final Pattern HEX = Pattern.compile("&#([0-9a-fA-F]{6})");
    private Object lp;
    private int tick;
    private boolean warned;

    @Override public void onEnable() {
        ConfigSync.sync(this, "realm-names");
        try { ZONE = ZoneId.of(getConfig().getString("timezone", "America/Los_Angeles")); } catch (Exception ex) { getLogger().warning("Bad timezone"); }
        try { DATE = DateTimeFormatter.ofPattern(getConfig().getString("date-format", "d MMM yyyy"), Locale.ENGLISH); } catch (Exception ex) { getLogger().warning("Bad date-format"); }
        try { TIME = DateTimeFormatter.ofPattern(getConfig().getString("time-format", "HH:mm"), Locale.ENGLISH); } catch (Exception ex) { getLogger().warning("Bad time-format"); }
        header = color(String.join("\n", getConfig().getStringList("header")));
        footer = color(String.join("\n", getConfig().getStringList("footer")));
        nameFormat = getConfig().getString("rank-tags.format", "{prefix}&f{name}");
        nameEvery = Math.max(1, getConfig().getInt("rank-tags.refresh-seconds", 10));
        REALMS.clear();
        org.bukkit.configuration.ConfigurationSection rs = getConfig().getConfigurationSection("realm-names");
        if (rs != null) for (String k : rs.getKeys(false)) REALMS.add(new String[]{rs.getString(k + ".worlds", ""), rs.getString(k + ".name", k)});
        try {
            Class<?> c = Class.forName("net.luckperms.api.LuckPerms");
            lp = Bukkit.getServicesManager().load(c);
        } catch (Throwable t) { lp = null; }
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::update, 20L, Math.max(1L, getConfig().getLong("update-ticks", 20)));
        getLogger().info("Darkholm tab list ready" + (lp == null ? " (LuckPerms not found, no rank tags)" : ""));
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> { name(e.getPlayer()); update(); }, 10L);
    }

    void update() {
        boolean names = tick++ % nameEvery == 0;
        int n = Bukkit.getOnlinePlayers().size();
        double tps = Math.min(20.0, Bukkit.getTPS()[0]);
        ZonedDateTime now = ZonedDateTime.now(ZONE);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (names) name(p);
            String f = fill(footer, p, n, tps, now);
            p.setPlayerListHeaderFooter(fill(header, p, n, tps, now), f);
        }
    }

    String fill(String t, Player p, int n, double tps, ZonedDateTime now) {
        return t.replace("{realm}", realm(p.getWorld().getName()))
                .replace("{online}", String.valueOf(n))
                .replace("{players-word}", n == 1 ? getConfig().getString("words.player", "adventurer") : getConfig().getString("words.players", "adventurers"))
                .replace("{ping}", String.valueOf(p.getPing()))
                .replace("{tps}", String.format(Locale.ROOT, "%.1f", tps))
                .replace("{date}", DATE.format(now))
                .replace("{time}", TIME.format(now))
                .replace("{player}", p.getName());
    }

    static boolean wild(String pattern, String w) {
        for (String one : pattern.toLowerCase(Locale.ROOT).split(",")) {
            one = one.trim(); if (one.isEmpty()) continue;
            if (one.endsWith("*") ? w.startsWith(one.substring(0, one.length() - 1)) : w.equals(one)) return true;
        }
        return false;
    }

    static String realm(String w) {
        String s = w.toLowerCase(Locale.ROOT);
        if (!REALMS.isEmpty()) { for (String[] r : REALMS) if (wild(r[0], s)) return r[1]; return w; }
        if (s.equals("hub")) return "The Great Hall";
        if (s.equals("darkholm_arena")) return "The Mob Arena";
        if (s.equals("duels")) return "Duels";
        if (s.equals("darkholm_kingdoms") || s.equals("kingdoms_test") || s.equals("kbuilds")) return "Kingdoms";
        if (s.startsWith("em_") || s.startsWith("elitemobs") || s.startsWith("goblinkingdom")) return "The Guild";
        if (s.startsWith("oneblock")) return "OneBlock";
        if (s.startsWith("darkholm")) return "Factions";
        return w;
    }

    void name(Player p) {
        String prefix = "";
        int weight = 0;
        if (lp != null && getConfig().getBoolean("rank-tags.enabled", true)) {
            try {
                ClassLoader cl = lp.getClass().getClassLoader();
                Class<?> api = Class.forName("net.luckperms.api.LuckPerms", false, cl);
                Class<?> pad = Class.forName("net.luckperms.api.platform.PlayerAdapter", false, cl);
                Class<?> cmd = Class.forName("net.luckperms.api.cacheddata.CachedMetaData", false, cl);
                Class<?> gmc = Class.forName("net.luckperms.api.model.group.GroupManager", false, cl);
                Class<?> grc = Class.forName("net.luckperms.api.model.group.Group", false, cl);
                Object adapter = api.getMethod("getPlayerAdapter", Class.class).invoke(lp, Player.class);
                Object meta = pad.getMethod("getMetaData", Object.class).invoke(adapter, p);
                Object pre = cmd.getMethod("getPrefix").invoke(meta);
                if (pre != null) prefix = color(pre.toString());
                Object group = cmd.getMethod("getPrimaryGroup").invoke(meta);
                if (group != null) {
                    Object gman = api.getMethod("getGroupManager").invoke(lp);
                    Object g = gmc.getMethod("getGroup", String.class).invoke(gman, group.toString());
                    if (g != null) {
                        Object w = grc.getMethod("getWeight").invoke(g);
                        if (w instanceof OptionalInt oi && oi.isPresent()) weight = oi.getAsInt();
                    }
                }
            } catch (Throwable t) {
                if (!warned) { warned = true; Throwable c = t.getCause() != null ? t.getCause() : t; getLogger().warning("Rank tag lookup failed: " + c); }
            }
        }
        p.setPlayerListName(color(nameFormat).replace("{prefix}", prefix).replace("{name}", p.getName()));
        if (getConfig().getBoolean("rank-tags.sort-by-rank", true)) p.setPlayerListOrder(Math.max(0, weight));
    }

    static String color(String s) {
        Matcher m = HEX.matcher(s);
        StringBuilder b = new StringBuilder();
        while (m.find()) {
            StringBuilder r = new StringBuilder("§x");
            for (char c : m.group(1).toCharArray()) r.append('§').append(c);
            m.appendReplacement(b, Matcher.quoteReplacement(r.toString()));
        }
        m.appendTail(b);
        return ChatColor.translateAlternateColorCodes('&', b.toString());
    }
}
