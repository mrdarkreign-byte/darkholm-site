package live.darkholm.timevote;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import java.lang.reflect.Method;
import java.util.*;

/**
 * /vote day and /vote night. Intercepts those two subcommands before VotingPlugin sees them;
 * every other /vote command passes through untouched. When at least two thirds of the
 * non-spectator players in the main world vote the same way, the time is set.
 */
public final class TimeVote extends JavaPlugin implements Listener {
    private static String P = "§8[§6⚔§8] ";
    private static long VOTE_WINDOW_MS = 90_000L;
    private static long COOLDOWN_MS = 120_000L;
    private static double SHARE = 2.0 / 3.0;
    private static final Set<String> EXCLUDED = new HashSet<>();
    private String m(String k, String d) { return ConfigSync.c(getConfig().getString("messages." + k, d)); }
    private static boolean excluded(Object p) throws Exception { return EXCLUDED.contains(String.valueOf(call(p, "getName")).toLowerCase(Locale.ROOT)); }

    private final Set<UUID> dayVotes = new HashSet<>();
    private final Set<UUID> nightVotes = new HashSet<>();
    private long dayStarted, nightStarted, lastPassed;

    @Override
    @SuppressWarnings("unchecked")
    public void onEnable() {
        ConfigSync.sync(this);
        P = ConfigSync.c(getConfig().getString("prefix", "&8[&6⚔&8] "));
        VOTE_WINDOW_MS = getConfig().getLong("vote-window-seconds", 90) * 1000L;
        COOLDOWN_MS = getConfig().getLong("cooldown-seconds", 120) * 1000L;
        SHARE = getConfig().getDouble("share-needed", 2.0 / 3.0);
        EXCLUDED.clear();
        for (String n : getConfig().getStringList("not-counted-until-they-vote")) EXCLUDED.add(n.toLowerCase(Locale.ROOT));
        try {
            Class<? extends Event> pre = (Class<? extends Event>) Class.forName("org.bukkit.event.player.PlayerCommandPreprocessEvent");
            Bukkit.getPluginManager().registerEvent(pre, this, EventPriority.LOWEST, (l, e) -> { if (pre.isInstance(e)) onCommand(e); }, this, true);
            Class<? extends Event> quit = (Class<? extends Event>) Class.forName("org.bukkit.event.player.PlayerQuitEvent");
            Bukkit.getPluginManager().registerEvent(quit, this, EventPriority.MONITOR, (l, e) -> { if (quit.isInstance(e)) onQuit(e); }, this, false);
            getLogger().info("Time votes ready: /vote day and /vote night (2/3 of players in the main world).");
        } catch (Throwable t) { getLogger().severe("TimeVote failed to start: " + t); }
    }

    private static Object call(Object o, String m) throws Exception { Method md = o.getClass().getMethod(m); return md.invoke(o); }

    private static void tell(Object player, String msg) {
        try { for (Method md : player.getClass().getMethods()) if (md.getName().equals("sendMessage") && md.getParameterCount() == 1 && md.getParameterTypes()[0] == String.class) { md.invoke(player, msg); return; } } catch (Exception ignore) {}
    }

    private static void broadcast(String msg) {
        try { Bukkit.class.getMethod("broadcastMessage", String.class).invoke(null, msg); } catch (Exception ignore) {}
    }

    private Object mainWorld() { List<?> w = (List<?>) (Object) Bukkit.getWorlds(); return w == null || w.isEmpty() ? null : w.get(0); }

    private List<Object> voters(Object world, Set<UUID> votes) throws Exception {
        List<Object> out = new ArrayList<>();
        for (Object p : (List<?>) call(world, "getPlayers")) {
            if ("SPECTATOR".equals(String.valueOf(call(p, "getGameMode")))) continue;
            // Excluded (Tom's) accounts only count toward the total once they vote
            if (excluded(p) && !votes.contains((UUID) call(p, "getUniqueId"))) continue;
            out.add(p);
        }
        return out;
    }

    private void onCommand(Event e) {
        try {
            String msg = String.valueOf(call(e, "getMessage")).trim().toLowerCase(Locale.ROOT);
            String[] a = msg.split("\\s+");
            if (a.length != 2) return;
            String root = a[0].startsWith("/") ? a[0].substring(1) : a[0];
            if (root.contains(":")) root = root.substring(root.indexOf(':') + 1);
            if (!root.equals("vote") && !root.equals("v")) return;
            boolean day;
            if (a[1].equals("day")) day = true; else if (a[1].equals("night")) day = false; else return;
            e.getClass().getMethod("setCancelled", boolean.class).invoke(e, true);
            Object player = call(e, "getPlayer");
            Bukkit.getScheduler().runTask(this, () -> handle(player, day));
        } catch (Exception ex) { getLogger().warning("timevote: " + ex); }
    }

    private void handle(Object player, boolean day) {
        try {
            Object world = mainWorld();
            if (world == null) return;
            if (!call(player, "getWorld").equals(world)) { tell(player, P + m("wrong-world", "&cTime may only be called in the realm of Darkholm itself.")); return; }
            long now = System.currentTimeMillis();
            if (now - lastPassed < COOLDOWN_MS) {
                tell(player, P + m("cooldown", "&7The heavens have only just turned. Wait &e{seconds}s&7 before calling again.").replace("{seconds}", String.valueOf((COOLDOWN_MS - (now - lastPassed)) / 1000 + 1)));
                return;
            }
            Set<UUID> votes = day ? dayVotes : nightVotes;
            if (now - (day ? dayStarted : nightStarted) > VOTE_WINDOW_MS) { votes.clear(); if (day) dayStarted = now; else nightStarted = now; }
            UUID id = (UUID) call(player, "getUniqueId");
            (day ? nightVotes : dayVotes).remove(id);
            if (!votes.add(id)) { tell(player, P + m("already-voted", "&7Thou hast already cast thy voice for {time}.").replace("{time}", day ? "dawn" : "dusk")); return; }
            tally(world, day, String.valueOf(call(player, "getName")));
        } catch (Exception ex) { getLogger().warning("timevote: " + ex); }
    }

    private void tally(Object world, boolean day, String who) throws Exception {
        Set<UUID> votes = day ? dayVotes : nightVotes;
        List<Object> online = voters(world, votes);
        Set<UUID> present = new HashSet<>();
        for (Object p : online) present.add((UUID) call(p, "getUniqueId"));
        votes.retainAll(present);
        int n = Math.max(1, online.size());
        int needed = (int) Math.ceil(n * SHARE);
        int have = votes.size();
        String word = day ? m("dawn-word", "&edawn") : m("dusk-word", "&9dusk");
        String cmd = day ? "day" : "night";
        if (who != null) broadcast(P + m("called", "&6{player} &7calls for {time}&7! &8(&e{have}&7/&e{needed}&8) &7Type &e/vote {command} &7to agree.").replace("{player}", who).replace("{time}", word).replace("{have}", String.valueOf(have)).replace("{needed}", String.valueOf(needed)).replace("{command}", cmd));
        if (have >= needed) {
            String key = String.valueOf(call(world, "getKey"));
            Method dispatch = Bukkit.class.getMethod("dispatchCommand", Class.forName("org.bukkit.command.CommandSender"), String.class);
            Object console = Bukkit.class.getMethod("getConsoleSender").invoke(null);
            dispatch.invoke(null, console, "execute in " + key + " run minecraft:time set " + cmd);
            broadcast(P + (day ? m("passed-day", "&e☀ The realm has spoken: let there be dawn!") : m("passed-night", "&9☾ The realm has spoken: let night fall!")));
            dayVotes.clear(); nightVotes.clear();
            lastPassed = System.currentTimeMillis();
        }
    }

    private void onQuit(Event e) {
        try {
            Object p = call(e, "getPlayer");
            UUID id = (UUID) call(p, "getUniqueId");
            dayVotes.remove(id); nightVotes.remove(id);
            Bukkit.getScheduler().runTask(this, () -> {
                try {
                    Object w = mainWorld();
                    if (w == null) return;
                    long now = System.currentTimeMillis();
                    if (!dayVotes.isEmpty() && now - dayStarted <= VOTE_WINDOW_MS) tally(w, true, null);
                    if (!nightVotes.isEmpty() && now - nightStarted <= VOTE_WINDOW_MS) tally(w, false, null);
                } catch (Exception ex) { getLogger().warning("timevote: " + ex); }
            });
        } catch (Exception ex) { getLogger().warning("timevote: " + ex); }
    }
}
