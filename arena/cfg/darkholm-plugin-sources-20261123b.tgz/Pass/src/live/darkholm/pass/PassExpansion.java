package live.darkholm.pass;

import java.util.List;
import java.util.Map;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

/** %darkholmpass_...% placeholders, used by the zMenu screens. */
public final class PassExpansion extends PlaceholderExpansion {
    private final DarkholmPass pl;
    PassExpansion(DarkholmPass pl) { this.pl = pl; }

    @Override public String getIdentifier() { return "darkholmpass"; }
    @Override public String getAuthor() { return "Astidonius_"; }
    @Override public String getVersion() { return pl.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    static String bar(long have, long need, int len) {
        int f = need <= 0 ? len : (int) Math.min(len, have * len / need);
        return "§a" + "■".repeat(f) + "§8" + "■".repeat(len - f);
    }

    @Override
    public String onRequest(OfflinePlayer op, String q) {
        // leaderboard and season values work without a player
        if (q.startsWith("top_")) {
            String[] s = q.split("_");
            if (s.length < 3) return "";
            int n = Integer.parseInt(s[1]);
            List<Object[]> t = pl.top();
            if (n < 1 || n > t.size()) return s[2].equals("name") ? "---" : "0";
            Object[] e = t.get(n - 1);
            return switch (s[2]) {
                case "name" -> String.valueOf(e[1]);
                case "xp" -> String.valueOf(e[2]);
                case "tier" -> String.valueOf(Math.min(pl.maxTier, (Long) e[2] / pl.xpPerTier));
                case "present" -> "1";
                default -> "";
            };
        }
        switch (q) {
            case "season": return pl.seasonName(pl.currentSeason());
            case "season_days_left": return String.valueOf(pl.seasonDaysLeft());
            case "daily_reset": return pl.untilNextDay();
            case "weekly_reset": return pl.untilNextWeek();
            case "max_tier": return String.valueOf(pl.maxTier);
            case "xp_per_tier": return String.valueOf(pl.xpPerTier);
            default: break;
        }
        if (op == null) return "";
        PlayerPass p = pl.get(op);
        int tier = pl.tier(p);
        long inTier = tier >= pl.maxTier ? pl.xpPerTier : p.xp % pl.xpPerTier;
        switch (q) {
            case "tier": return String.valueOf(tier);
            case "xp": return String.valueOf(p.xp);
            case "xp_in_tier": return String.valueOf(inTier);
            case "xp_to_next": return tier >= pl.maxTier ? "0" : String.valueOf(pl.xpPerTier - inTier);
            case "bar": return bar(inTier, pl.xpPerTier, 20);
            case "season_bar": return bar(tier, pl.maxTier, 20);
            case "premium": return pl.premium(op) ? "1" : "0";
            case "premium_text": return pl.premium(op) ? "§6Active §7(thank you!)" : "§7Donor ranks unlock it";
            case "rank": { int r = pl.rankOf(p.id); return r == 0 ? "-" : String.valueOf(r); }
            case "claimable": return op.isOnline() ? String.valueOf(pl.claimable(op.getPlayer(), p)) : "0";
            case "title": return p.activeTitle.isEmpty() ? "" : pl.titleDisplay.getOrDefault(p.activeTitle, "").replace("&", "§");
            case "titles_count": return String.valueOf(p.titles.size());
            default: break;
        }
        if (q.startsWith("daily_") || q.startsWith("weekly_")) {
            boolean d = q.startsWith("daily_");
            String[] s = q.split("_", 3);
            if (s.length < 3) return "";
            int i = Integer.parseInt(s[1]) - 1;
            List<String> ids = d ? p.dailyIds : p.weeklyIds;
            List<Integer> prog = d ? p.dailyProgress : p.weeklyProgress;
            Map<String, QuestDef> pool = d ? pl.daily : pl.weekly;
            if (i < 0 || i >= ids.size() || pool.get(ids.get(i)) == null) return s[2].equals("done") ? "0" : "";
            QuestDef qd = pool.get(ids.get(i));
            int have = prog.get(i);
            return switch (s[2]) {
                case "name" -> qd.name;
                case "progress" -> String.valueOf(have);
                case "goal" -> String.valueOf(qd.amount);
                case "xp" -> String.valueOf(qd.xp);
                case "done" -> have >= qd.amount ? "1" : "0";
                case "bar" -> bar(have, qd.amount, 20);
                default -> "";
            };
        }
        if (q.startsWith("reward_")) { // reward_<free|premium>_<n>_<status|name>
            String[] s = q.split("_");
            if (s.length < 4) return "";
            boolean prem = s[1].equals("premium");
            int n = Integer.parseInt(s[2]);
            if (s[3].equals("status")) return String.valueOf(pl.status(op, p, prem, n));
            DarkholmPass.Reward r = (prem ? pl.premiumRewards : pl.freeRewards).get(n);
            return r == null ? "" : r.name();
        }
        if (q.startsWith("has_title_")) {
            return p.titles.contains(q.substring(10)) ? "1" : "0";
        }
        if (q.startsWith("active_title_")) {
            return p.activeTitle.equals(q.substring(13)) ? "1" : "0";
        }
        return null;
    }
}
