package live.darkholm.pass;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.time.temporal.IsoFields;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.FurnaceExtractEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Darkholm Pass: monthly battle pass with daily and weekly quests, a free reward track,
 * a cosmetic premium track for donors, titles and a season leaderboard.
 * Menus are zMenu inventories this plugin writes from its own config.
 */
public final class DarkholmPass extends JavaPlugin implements Listener {

    static final String C = "§";
    ZoneId zone;
    int maxTier, xpPerTier, dailyCount, weeklyCount;
    Set<String> disabledWorlds = new HashSet<>();
    final Map<String, QuestDef> daily = new LinkedHashMap<>();
    final Map<String, QuestDef> weekly = new LinkedHashMap<>();
    final Map<Integer, Reward> freeRewards = new HashMap<>();
    final Map<Integer, Reward> premiumRewards = new HashMap<>();
    final Map<String, String> titleDisplay = new LinkedHashMap<>();
    String premiumPermission;
    String titleSetCmd, titleClearCmd;

    final Map<UUID, PlayerPass> online = new HashMap<>();
    final Set<String> placed = Collections.newSetFromMap(new LinkedHashMap<String, Boolean>() {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Boolean> e) { return size() > 200_000; }
    });
    final Map<UUID, Location> lastLoc = new HashMap<>();
    final Map<UUID, Long> lastMoved = new HashMap<>();

    File playersDir, boardFile, pendingFile;
    String boardSeason = "";
    final Map<UUID, Object[]> board = new HashMap<>(); // uuid -> {name, xp}
    List<Object[]> topCache = new ArrayList<>();
    long topCacheAt;

    record Reward(String name, String icon, List<String> commands, String title) {}

    // ---------------------------------------------------------------- lifecycle
    @Override
    public void onEnable() {
        saveDefaultConfig();
        playersDir = new File(getDataFolder(), "players");
        playersDir.mkdirs();
        boardFile = new File(getDataFolder(), "leaderboard.yml");
        pendingFile = new File(getDataFolder(), "pending-titles.yml");
        loadSettings();
        loadBoard();
        checkSeason();
        Bukkit.getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) get(p);
        Bukkit.getScheduler().runTaskTimer(this, this::minuteTick, 1200L, 1200L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveAll, 6000L, 6000L);
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PassExpansion(this).register();
        }
        writeMenus();
        getLogger().info("Darkholm Pass ready: " + maxTier + " tiers, " + daily.size() + " daily and " + weekly.size() + " weekly quests, season " + currentSeason());
    }

    @Override
    public void onDisable() { saveAll(); saveBoard(); }

    String M(String k, String d) { return getConfig().getString("messages." + k, d); }
    static String f(String t, Object... kv) { for (int i = 0; i + 1 < kv.length; i += 2) t = t.replace("{" + kv[i] + "}", String.valueOf(kv[i + 1])); return t; }

    void loadSettings() {
        ConfigSync.sync(this, "quests", "titles", "season-titles", "rewards");
        var c = getConfig();
        zone = ZoneId.of(c.getString("timezone", "America/Los_Angeles"));
        maxTier = c.getInt("tiers", 30);
        xpPerTier = c.getInt("xp-per-tier", 1000);
        dailyCount = c.getInt("daily-quests-per-day", 3);
        weeklyCount = c.getInt("weekly-quests-per-week", 3);
        disabledWorlds = new HashSet<>();
        for (String w : c.getStringList("disabled-worlds")) disabledWorlds.add(w.toLowerCase(Locale.ROOT));
        premiumPermission = c.getString("premium-permission", "darkholm.pass.premium");
        titleSetCmd = c.getString("title-set-command", "");
        titleClearCmd = c.getString("title-clear-command", "");
        daily.clear(); weekly.clear(); freeRewards.clear(); premiumRewards.clear(); titleDisplay.clear();
        loadQuests(c.getConfigurationSection("quests.daily"), daily);
        loadQuests(c.getConfigurationSection("quests.weekly"), weekly);
        loadRewards(c.getConfigurationSection("rewards.free"), freeRewards);
        loadRewards(c.getConfigurationSection("rewards.premium"), premiumRewards);
        ConfigurationSection t = c.getConfigurationSection("titles");
        if (t != null) for (String k : t.getKeys(false)) titleDisplay.put(k, t.getString(k));
    }

    void loadQuests(ConfigurationSection s, Map<String, QuestDef> into) {
        if (s == null) return;
        for (String k : s.getKeys(false)) into.put(k, new QuestDef(k, s.getConfigurationSection(k)));
    }

    void loadRewards(ConfigurationSection s, Map<Integer, Reward> into) {
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            ConfigurationSection r = s.getConfigurationSection(k);
            into.put(Integer.parseInt(k), new Reward(r.getString("name", "Reward"), r.getString("icon", "CHEST"),
                    r.getStringList("commands"), r.getString("title", "")));
        }
    }

    // ---------------------------------------------------------------- time keys
    String currentSeason() { return YearMonth.now(zone).toString(); }
    String seasonName(String key) {
        YearMonth ym = YearMonth.parse(key);
        return ym.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + ym.getYear();
    }
    String dayKey() { return LocalDate.now(zone).toString(); }
    String weekKey() {
        LocalDate d = LocalDate.now(zone);
        return d.get(IsoFields.WEEK_BASED_YEAR) + "-W" + d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
    }
    String untilNextDay() {
        ZonedDateTime now = ZonedDateTime.now(zone);
        return fmt(Duration.between(now, now.toLocalDate().plusDays(1).atStartOfDay(zone)));
    }
    String untilNextWeek() {
        ZonedDateTime now = ZonedDateTime.now(zone);
        LocalDate next = now.toLocalDate().with(TemporalAdjusters.next(DayOfWeek.MONDAY));
        return fmt(Duration.between(now, next.atStartOfDay(zone)));
    }
    int seasonDaysLeft() {
        LocalDate now = LocalDate.now(zone);
        return (int) (YearMonth.from(now).atEndOfMonth().toEpochDay() - now.toEpochDay()) + 1;
    }
    static String fmt(Duration d) {
        long m = Math.max(0, d.toMinutes());
        long days = m / 1440, h = (m % 1440) / 60, mm = m % 60;
        return days > 0 ? days + "d " + h + "h" : h + "h " + mm + "m";
    }

    // ---------------------------------------------------------------- data
    PlayerPass get(OfflinePlayer op) {
        UUID id = op.getUniqueId();
        PlayerPass p = online.get(id);
        if (p == null) {
            p = PlayerPass.load(new File(playersDir, id + ".yml"), id);
            if (op.isOnline()) online.put(id, p);
            applyPendingTitles(p);
        }
        if (op.getName() != null && !op.getName().equals(p.name)) { p.name = op.getName(); p.dirty = true; }
        String s = currentSeason();
        if (!s.equals(p.season)) p.resetSeason(s);
        refreshQuests(p);
        return p;
    }

    void refreshQuests(PlayerPass p) {
        String dk = dayKey();
        if (!dk.equals(p.dailyKey)) { assign(p, dk, daily, dailyCount, p.dailyIds, p.dailyProgress); p.dailyKey = dk; p.dirty = true; }
        String wk = weekKey();
        if (!wk.equals(p.weeklyKey)) { assign(p, wk, weekly, weeklyCount, p.weeklyIds, p.weeklyProgress); p.weeklyKey = wk; p.dirty = true; }
    }

    void assign(PlayerPass p, String key, Map<String, QuestDef> pool, int n, List<String> ids, List<Integer> prog) {
        ids.clear(); prog.clear();
        List<String> all = new ArrayList<>(pool.keySet());
        Collections.shuffle(all, new Random((key + p.id).hashCode()));
        for (int i = 0; i < Math.min(n, all.size()); i++) { ids.add(all.get(i)); prog.add(0); }
    }

    void save(PlayerPass p) {
        try { p.save(new File(playersDir, p.id + ".yml")); }
        catch (IOException e) { getLogger().warning("Could not save " + p.id + ": " + e.getMessage()); }
    }

    void saveAll() {
        for (PlayerPass p : online.values()) if (p.dirty) save(p);
        saveBoard();
    }

    // ---------------------------------------------------------------- leaderboard and seasons
    void loadBoard() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(boardFile);
        boardSeason = y.getString("season", currentSeason());
        ConfigurationSection e = y.getConfigurationSection("entries");
        if (e != null) for (String k : e.getKeys(false))
            board.put(UUID.fromString(k), new Object[]{e.getString(k + ".name", "?"), e.getLong(k + ".xp", 0)});
    }

    void saveBoard() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("season", boardSeason);
        for (var en : board.entrySet()) {
            y.set("entries." + en.getKey() + ".name", en.getValue()[0]);
            y.set("entries." + en.getKey() + ".xp", en.getValue()[1]);
        }
        try { y.save(boardFile); } catch (IOException ex) { getLogger().warning("leaderboard save failed: " + ex.getMessage()); }
    }

    List<Object[]> top() {
        if (System.currentTimeMillis() - topCacheAt > 5000) {
            List<Object[]> l = new ArrayList<>();
            for (var en : board.entrySet()) l.add(new Object[]{en.getKey(), en.getValue()[0], en.getValue()[1]});
            l.sort((a, b) -> Long.compare((Long) b[2], (Long) a[2]));
            topCache = l; topCacheAt = System.currentTimeMillis();
        }
        return topCache;
    }

    int rankOf(UUID id) {
        List<Object[]> t = top();
        for (int i = 0; i < t.size(); i++) if (t.get(i)[0].equals(id)) return i + 1;
        return 0;
    }

    void checkSeason() {
        String now = currentSeason();
        if (now.equals(boardSeason)) return;
        // Season over: archive the top 10 and hand out season titles to the top 3.
        List<Object[]> t = top();
        topCacheAt = 0;
        YamlConfiguration arch = new YamlConfiguration();
        for (int i = 0; i < Math.min(10, t.size()); i++) {
            arch.set("top." + (i + 1) + ".name", t.get(i)[1]);
            arch.set("top." + (i + 1) + ".xp", t.get(i)[2]);
        }
        File dir = new File(getDataFolder(), "seasons"); dir.mkdirs();
        try { arch.save(new File(dir, boardSeason + ".yml")); } catch (IOException ignored) {}
        String[] place = {"champion", "runner-up", "vanguard"};
        String month = seasonName(boardSeason);
        YamlConfiguration pend = YamlConfiguration.loadConfiguration(pendingFile);
        for (int i = 0; i < Math.min(3, t.size()); i++) {
            String id = "season-" + boardSeason + "-" + place[i];
            String label = getConfig().getString("season-titles." + place[i], "&6[%month% " + place[i] + "]").replace("%month%", month);
            getConfig().set("titles." + id, label);
            titleDisplay.put(id, label);
            List<String> l = pend.getStringList(t.get(i)[0].toString()); l.add(id);
            pend.set(t.get(i)[0].toString(), l);
            Bukkit.broadcastMessage(color(f(M("season-finished", "&6⚔ &e{player} &7finished &6#{place} &7in the {month} Darkholm Pass!"), "player", t.get(i)[1], "place", i + 1, "month", month)));
        }
        try { pend.save(pendingFile); } catch (IOException ignored) {}
        saveConfig();
        board.clear();
        boardSeason = now;
        saveBoard();
        for (Player p : Bukkit.getOnlinePlayers()) { PlayerPass pp = online.remove(p.getUniqueId()); if (pp != null) save(pp); get(p); }
        writeMenus();
    }

    void applyPendingTitles(PlayerPass p) {
        if (!pendingFile.exists()) return;
        YamlConfiguration pend = YamlConfiguration.loadConfiguration(pendingFile);
        List<String> l = pend.getStringList(p.id.toString());
        if (l.isEmpty()) return;
        p.titles.addAll(l); p.dirty = true;
        pend.set(p.id.toString(), null);
        try { pend.save(pendingFile); } catch (IOException ignored) {}
    }

    // ---------------------------------------------------------------- progress
    boolean counts(Player pl) {
        return pl.getGameMode() == GameMode.SURVIVAL || pl.getGameMode() == GameMode.ADVENTURE
                ? !disabledWorlds.contains(pl.getWorld().getName().toLowerCase(Locale.ROOT)) : false;
    }

    void progress(Player pl, String type, String target, boolean hostile, int amount) {
        if (amount <= 0 || !counts(pl)) return;
        progressRaw(pl, type, target, hostile, amount);
    }

    void progressRaw(Player pl, String type, String target, boolean hostile, int amount) {
        PlayerPass p = get(pl);
        bump(pl, p, p.dailyIds, p.dailyProgress, daily, type, target, hostile, amount, M("word-daily", "Daily"));
        bump(pl, p, p.weeklyIds, p.weeklyProgress, weekly, type, target, hostile, amount, M("word-weekly", "Weekly"));
    }

    void bump(Player pl, PlayerPass p, List<String> ids, List<Integer> prog, Map<String, QuestDef> pool,
              String type, String target, boolean hostile, int amount, String label) {
        for (int i = 0; i < ids.size(); i++) {
            QuestDef q = pool.get(ids.get(i));
            if (q == null) continue;
            int cur = prog.get(i);
            if (cur >= q.amount || !q.matches(type, target, hostile)) continue;
            int nv = Math.min(q.amount, cur + amount);
            prog.set(i, nv);
            p.dirty = true;
            if (nv >= q.amount) {
                pl.sendMessage(color(f(M("quest-complete", "&6⚔ &e{type} quest complete: &f{quest} &a+{xp} XP"), "type", label, "quest", q.name, "xp", q.xp)));
                pl.playSound(pl.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
                addXp(pl, p, q.xp);
            } else if (q.amount >= 10 && (nv * 4 / q.amount) != (cur * 4 / q.amount)) {
                pl.sendMessage(color(f(M("quest-progress", "&8[&6Pass&8] &7{quest}: &f{done}&7/{needed}"), "quest", q.name, "done", nv, "needed", q.amount)));
            }
        }
    }

    void addXp(Player pl, PlayerPass p, long amount) {
        int before = tier(p);
        p.xp += amount; p.dirty = true;
        board.put(p.id, new Object[]{p.name, p.xp}); topCacheAt = 0;
        int after = tier(p);
        if (after > before && pl != null) {
            pl.sendMessage(color(f(M("tier-up", "&6&l⚔ Darkholm Pass tier {tier}! &eOpen &f/pass &eto claim your reward."), "tier", after)));
            pl.playSound(pl.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1f);
        }
    }

    int tier(PlayerPass p) { return (int) Math.min(maxTier, p.xp / xpPerTier); }

    boolean premium(OfflinePlayer op) {
        return op.isOnline() && op.getPlayer().hasPermission(premiumPermission);
    }

    /** 2 = claimable, 1 = claimed, 0 = locked. */
    int status(OfflinePlayer op, PlayerPass p, boolean prem, int n) {
        Map<Integer, Reward> m = prem ? premiumRewards : freeRewards;
        if (!m.containsKey(n)) return 0;
        if ((prem ? p.premiumClaimed : p.freeClaimed).contains(n)) return 1;
        if (tier(p) < n) return 0;
        if (prem && !premium(op)) return 0;
        return 2;
    }

    int claimable(Player pl, PlayerPass p) {
        int c = 0;
        for (int n = 1; n <= maxTier; n++) { if (status(pl, p, false, n) == 2) c++; if (status(pl, p, true, n) == 2) c++; }
        return c;
    }

    boolean claim(Player pl, boolean prem, int n, boolean quiet) {
        PlayerPass p = get(pl);
        int st = status(pl, p, prem, n);
        if (st != 2) {
            if (!quiet) pl.sendMessage(color(st == 1 ? M("already-claimed", "&7Already claimed.") : prem && !premium(pl) && tier(p) >= n
                    ? M("donor-only", "&6That's a donor cosmetic. Thanks for supporting Darkholm if you choose to!") : f(M("tier-locked", "&cReach tier {tier} first."), "tier", n)));
            return false;
        }
        Reward r = (prem ? premiumRewards : freeRewards).get(n);
        (prem ? p.premiumClaimed : p.freeClaimed).add(n);
        p.dirty = true;
        for (String cmd : r.commands()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", pl.getName()));
        if (!r.title().isEmpty()) {
            p.titles.add(r.title());
            pl.sendMessage(color(f(M("title-unlocked", "&eNew title unlocked: {title} &7(/pass titles)"), "title", titleDisplay.getOrDefault(r.title(), r.title()))));
        }
        pl.sendMessage(color(f(M(prem ? "claimed-premium" : "claimed", prem ? "&a✔ Claimed tier {tier} premium: &f{reward}" : "&a✔ Claimed tier {tier}: &f{reward}"), "tier", n, "reward", r.name())));
        pl.playSound(pl.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.1f);
        save(p);
        return true;
    }

    void setTitle(Player pl, String id) {
        PlayerPass p = get(pl);
        if (id == null) {
            p.activeTitle = ""; p.dirty = true;
            if (!titleClearCmd.isEmpty()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), titleClearCmd.replace("%player%", pl.getName()));
            pl.sendMessage(color(M("title-removed", "&7Title removed.")));
            return;
        }
        if (!p.titles.contains(id)) { pl.sendMessage(color(M("title-not-unlocked", "&cYou haven't unlocked that title."))); return; }
        String disp = titleDisplay.getOrDefault(id, id);
        p.activeTitle = id; p.dirty = true;
        if (!titleSetCmd.isEmpty()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                titleSetCmd.replace("%player%", pl.getName()).replace("%title%", disp));
        pl.sendMessage(color(f(M("title-set", "&aTitle set: {title}"), "title", disp)));
    }

    static String color(String s) { return s.replace("&", C); }

    // ---------------------------------------------------------------- events
    static String key(Block b) { return b.getWorld().getName() + ":" + b.getX() + ":" + b.getY() + ":" + b.getZ(); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock(); Player pl = e.getPlayer();
        String type = b.getType().name();
        if (b.getBlockData() instanceof Ageable a && a.getAge() >= a.getMaximumAge()) progress(pl, "HARVEST", type, false, 1);
        if (placed.remove(key(b))) return;
        progress(pl, "BREAK", type, false, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        placed.add(key(e.getBlockPlaced()));
        progress(e.getPlayer(), "PLACE", e.getBlockPlaced().getType().name(), false, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onKill(EntityDeathEvent e) {
        LivingEntity v = e.getEntity();
        Player k = v.getKiller();
        if (k == null || v == k) return;
        // Mobs from spawners never count toward quests
        if (v.getEntitySpawnReason() == org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.SPAWNER) return;
        progress(k, "KILL", v.getType().name(), v instanceof Enemy, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent e) {
        if (e.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        String t = e.getCaught() instanceof org.bukkit.entity.Item it ? it.getItemStack().getType().name() : null;
        progress(e.getPlayer(), "FISH", t, false, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent e) {
        if (!(e.getWhoClicked() instanceof Player pl)) return;
        ItemStack res = e.getRecipe().getResult();
        int amount = res.getAmount();
        if (e.isShiftClick()) {
            int min = Integer.MAX_VALUE;
            for (ItemStack s : e.getInventory().getMatrix()) if (s != null && !s.getType().isAir()) min = Math.min(min, s.getAmount());
            if (min != Integer.MAX_VALUE) amount *= min;
        }
        progress(pl, "CRAFT", res.getType().name(), false, amount);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSmelt(FurnaceExtractEvent e) {
        progress(e.getPlayer(), "SMELT", e.getItemType().name(), false, e.getItemAmount());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEat(PlayerItemConsumeEvent e) {
        if (e.getItem().getType().isEdible()) progress(e.getPlayer(), "EAT", e.getItem().getType().name(), false, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreed(EntityBreedEvent e) {
        if (e.getBreeder() instanceof Player pl) progress(pl, "BREED", e.getEntity().getType().name(), false, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnchant(EnchantItemEvent e) {
        progress(e.getEnchanter(), "ENCHANT", e.getItem().getType().name(), false, 1);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        PlayerPass p = get(e.getPlayer());
        board.put(p.id, new Object[]{p.name, p.xp});
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!e.getPlayer().isOnline()) return;
            int c = claimable(e.getPlayer(), p);
            if (c > 0) e.getPlayer().sendMessage(color(f(M(c == 1 ? "rewards-waiting-one" : "rewards-waiting", c == 1 ? "&6⚔ &eYou have &f1 &eDarkholm Pass reward to claim: &f/pass" : "&6⚔ &eYou have &f{count} &eDarkholm Pass rewards to claim: &f/pass"), "count", c)));
        }, 100L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        PlayerPass p = online.remove(e.getPlayer().getUniqueId());
        if (p != null) save(p);
        lastLoc.remove(e.getPlayer().getUniqueId());
        lastMoved.remove(e.getPlayer().getUniqueId());
    }

    void minuteTick() {
        checkSeason();
        long now = System.currentTimeMillis();
        for (Player pl : Bukkit.getOnlinePlayers()) {
            UUID id = pl.getUniqueId();
            Location l = pl.getLocation(), prev = lastLoc.get(id);
            if (prev == null || prev.getWorld() != l.getWorld() || prev.distanceSquared(l) > 4) lastMoved.put(id, now);
            lastLoc.put(id, l);
            if (now - lastMoved.getOrDefault(id, 0L) <= 5 * 60_000L) progress(pl, "PLAYTIME", null, false, 1);
        }
    }

    // ---------------------------------------------------------------- commands
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        boolean admin = s.hasPermission("darkholm.pass.admin");
        switch (sub) {
            case "" -> { if (s instanceof Player pl) openMenu(pl, "darkholmpass_main"); else s.sendMessage("Players only."); }
            case "rewards" -> { if (s instanceof Player pl) openMenu(pl, "darkholmpass_rewards"); }
            case "top" -> {
                if (s instanceof Player pl && a.length == 1) { openMenu(pl, "darkholmpass_top"); return true; }
                List<Object[]> t = top();
                s.sendMessage(color(f(M("leaders-header", "&6⚔ Darkholm Pass · {season} leaders"), "season", seasonName(boardSeason))));
                for (int i = 0; i < Math.min(10, t.size()); i++)
                    s.sendMessage(color(f(M("leaders-line", "&e#{place} &f{player} &7{xp} XP (tier {tier})"), "place", i + 1, "player", t.get(i)[1], "xp", t.get(i)[2], "tier", Math.min(maxTier, (Long) t.get(i)[2] / xpPerTier))));
            }
            case "titles" -> { if (s instanceof Player pl) openMenu(pl, "darkholmpass_titles"); }
            case "quests" -> {
                if (!(s instanceof Player pl)) return true;
                PlayerPass p = get(pl);
                pl.sendMessage(color(f(M("daily-header", "&6⚔ Daily quests &7(reset in {time})"), "time", untilNextDay())));
                listQuests(pl, p.dailyIds, p.dailyProgress, daily);
                pl.sendMessage(color(f(M("weekly-header", "&6⚔ Weekly quests &7(reset in {time})"), "time", untilNextWeek())));
                listQuests(pl, p.weeklyIds, p.weeklyProgress, weekly);
                pl.sendMessage(color(f(M("tier-line", "&7Tier &f{tier}&7/{max} · &f{xp} XP"), "tier", tier(p), "max", maxTier, "xp", p.xp)));
            }
            case "claim" -> {
                if (!(s instanceof Player pl) || a.length < 3) { s.sendMessage("/pass claim <free|premium> <tier>"); return true; }
                try { claim(pl, a[1].equalsIgnoreCase("premium"), Integer.parseInt(a[2]), false); } catch (NumberFormatException ex) { s.sendMessage("Bad tier"); }
            }
            case "claimall" -> {
                if (!(s instanceof Player pl)) return true;
                int c = 0;
                for (int n = 1; n <= maxTier; n++) { if (claim(pl, false, n, true)) c++; if (claim(pl, true, n, true)) c++; }
                if (c == 0) pl.sendMessage(color(M("nothing-to-claim", "&7Nothing to claim yet. Finish quests to rank up: &f/pass")));
            }
            case "title" -> {
                if (!(s instanceof Player pl) || a.length < 2) { s.sendMessage("/pass title <id|off>"); return true; }
                setTitle(pl, a[1].equalsIgnoreCase("off") ? null : a[1]);
            }
            case "progress" -> { // console: pass progress <player> <TYPE> [amount] [target]
                if (!admin || a.length < 3) return true;
                Player pl = Bukkit.getPlayerExact(a[1]);
                if (pl == null) return true;
                int amt = a.length > 3 ? Integer.parseInt(a[3]) : 1;
                progressRaw(pl, a[2].toUpperCase(Locale.ROOT), a.length > 4 ? a[4].toUpperCase(Locale.ROOT) : null, false, amt);
            }
            case "addxp" -> {
                if (!admin || a.length < 3) return true;
                Player pl = Bukkit.getPlayerExact(a[1]);
                if (pl == null) { s.sendMessage("Player not online"); return true; }
                addXp(pl, get(pl), Long.parseLong(a[2]));
                s.sendMessage("Added " + a[2] + " XP to " + pl.getName());
            }
            case "givetitle" -> {
                if (!admin || a.length < 3) return true;
                Player pl = Bukkit.getPlayerExact(a[1]);
                if (pl == null) return true;
                PlayerPass p = get(pl); p.titles.add(a[2]); p.dirty = true; s.sendMessage("Gave title " + a[2]);
            }
            case "info" -> {
                if (!admin || a.length < 2) return true;
                Player pl = Bukkit.getPlayerExact(a[1]);
                if (pl == null) return true;
                PlayerPass p = get(pl);
                s.sendMessage(pl.getName() + ": season " + p.season + ", xp " + p.xp + ", tier " + tier(p) + ", daily " + p.dailyIds + " " + p.dailyProgress
                        + ", weekly " + p.weeklyIds + " " + p.weeklyProgress + ", free " + p.freeClaimed + ", premium " + p.premiumClaimed + ", titles " + p.titles);
            }
            case "reload" -> {
                if (!admin) return true;
                saveAll(); online.clear(); loadSettings();
                for (Player pl : Bukkit.getOnlinePlayers()) get(pl);
                writeMenus();
                s.sendMessage("Darkholm Pass reloaded.");
            }
            default -> s.sendMessage(color("&6/pass &7menu · &6/pass quests &7· &6/pass top &7· &6/pass titles &7· &6/pass claimall"));
        }
        return true;
    }

    void listQuests(Player pl, List<String> ids, List<Integer> prog, Map<String, QuestDef> pool) {
        for (int i = 0; i < ids.size(); i++) {
            QuestDef q = pool.get(ids.get(i));
            if (q == null) continue;
            boolean done = prog.get(i) >= q.amount;
            pl.sendMessage(color((done ? " &a✔ " : " &7• ") + "&f" + q.name + " &7" + prog.get(i) + "/" + q.amount + " &8(+" + q.xp + " XP)"));
        }
    }

    void openMenu(Player pl, String inv) {
        get(pl);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), getConfig().getString("menu-open-command", "zm open %menu% %player%")
                .replace("%menu%", inv).replace("%player%", pl.getName()));
    }

    // ---------------------------------------------------------------- zMenu files
    void writeMenus() {
        File dir = new File(getDataFolder().getParentFile(), "zMenu/inventories");
        if (!dir.isDirectory()) return;
        try {
            Files.writeString(new File(dir, "darkholmpass_main.yml").toPath(), Menus.main(this), StandardCharsets.UTF_8);
            Files.writeString(new File(dir, "darkholmpass_rewards.yml").toPath(), Menus.rewards(this), StandardCharsets.UTF_8);
            Files.writeString(new File(dir, "darkholmpass_top.yml").toPath(), Menus.top(this), StandardCharsets.UTF_8);
            Files.writeString(new File(dir, "darkholmpass_titles.yml").toPath(), Menus.titles(this), StandardCharsets.UTF_8);
            if (Bukkit.getPluginManager().getPlugin("zMenu") != null)
                Bukkit.getScheduler().runTask(this, () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "zm reload"));
        } catch (IOException e) {
            getLogger().warning("Could not write zMenu files: " + e.getMessage());
        }
    }
}
