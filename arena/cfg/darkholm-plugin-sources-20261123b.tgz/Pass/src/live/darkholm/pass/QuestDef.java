package live.darkholm.pass;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.bukkit.configuration.ConfigurationSection;

/** One quest from the daily or weekly pool. */
public final class QuestDef {
    public final String id;
    public final String name;
    public final String type;     // BREAK, PLACE, HARVEST, KILL, FISH, CRAFT, SMELT, EAT, BREED, ENCHANT, PLAYTIME, VOTE
    public final List<String> targets; // material / entity names, "*_ORE" style wildcards, HOSTILE, ANY
    public final int amount;
    public final int xp;
    public final String icon;

    QuestDef(String id, ConfigurationSection s) {
        this.id = id;
        this.name = s.getString("name", id);
        this.type = s.getString("type", "BREAK").toUpperCase(Locale.ROOT);
        List<String> t = new ArrayList<>();
        for (String x : s.getStringList("targets")) t.add(x.toUpperCase(Locale.ROOT));
        if (t.isEmpty()) t.add("ANY");
        this.targets = t;
        this.amount = Math.max(1, s.getInt("amount", 1));
        this.xp = s.getInt("xp", 100);
        this.icon = s.getString("icon", "PAPER");
    }

    public boolean matches(String type, String target, boolean hostile) {
        if (!this.type.equals(type)) return false;
        for (String t : targets) {
            if (t.equals("ANY")) return true;
            if (t.equals("HOSTILE") && hostile) return true;
            if (target == null) continue;
            if (t.equals(target)) return true;
            if (t.startsWith("*") && target.endsWith(t.substring(1))) return true;
            if (t.endsWith("*") && target.startsWith(t.substring(0, t.length() - 1))) return true;
        }
        return false;
    }
}
