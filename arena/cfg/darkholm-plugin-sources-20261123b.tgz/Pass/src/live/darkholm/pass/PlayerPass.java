package live.darkholm.pass;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.bukkit.configuration.file.YamlConfiguration;

/** One player's pass state. Saved to data/players/<uuid>.yml. */
public final class PlayerPass {
    public final UUID id;
    public String name;
    public String season = "";
    public long xp;
    public final Set<Integer> freeClaimed = new LinkedHashSet<>();
    public final Set<Integer> premiumClaimed = new LinkedHashSet<>();
    public String dailyKey = "";
    public final List<String> dailyIds = new ArrayList<>();
    public final List<Integer> dailyProgress = new ArrayList<>();
    public String weeklyKey = "";
    public final List<String> weeklyIds = new ArrayList<>();
    public final List<Integer> weeklyProgress = new ArrayList<>();
    public final Set<String> titles = new LinkedHashSet<>();
    public String activeTitle = "";
    public boolean dirty;

    PlayerPass(UUID id) { this.id = id; }

    static PlayerPass load(File f, UUID id) {
        PlayerPass p = new PlayerPass(id);
        if (!f.exists()) return p;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        p.name = y.getString("name", "");
        p.season = y.getString("season", "");
        p.xp = y.getLong("xp", 0);
        p.freeClaimed.addAll(y.getIntegerList("free-claimed"));
        p.premiumClaimed.addAll(y.getIntegerList("premium-claimed"));
        p.dailyKey = y.getString("daily.key", "");
        p.dailyIds.addAll(y.getStringList("daily.ids"));
        p.dailyProgress.addAll(y.getIntegerList("daily.progress"));
        p.weeklyKey = y.getString("weekly.key", "");
        p.weeklyIds.addAll(y.getStringList("weekly.ids"));
        p.weeklyProgress.addAll(y.getIntegerList("weekly.progress"));
        p.titles.addAll(y.getStringList("titles"));
        p.activeTitle = y.getString("active-title", "");
        return p;
    }

    void save(File f) throws IOException {
        YamlConfiguration y = new YamlConfiguration();
        y.set("name", name);
        y.set("season", season);
        y.set("xp", xp);
        y.set("free-claimed", new ArrayList<>(freeClaimed));
        y.set("premium-claimed", new ArrayList<>(premiumClaimed));
        y.set("daily.key", dailyKey);
        y.set("daily.ids", dailyIds);
        y.set("daily.progress", dailyProgress);
        y.set("weekly.key", weeklyKey);
        y.set("weekly.ids", weeklyIds);
        y.set("weekly.progress", weeklyProgress);
        y.set("titles", new ArrayList<>(titles));
        y.set("active-title", activeTitle);
        y.save(f);
        dirty = false;
    }

    void resetSeason(String newSeason) {
        season = newSeason;
        xp = 0;
        freeClaimed.clear();
        premiumClaimed.clear();
        dirty = true;
    }
}
