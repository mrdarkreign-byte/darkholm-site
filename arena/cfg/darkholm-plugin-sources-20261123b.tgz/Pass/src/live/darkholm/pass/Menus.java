package live.darkholm.pass;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Writes the zMenu inventories for the pass. Regenerated on every start and /pass reload. */
final class Menus {
    private Menus() {}

    static String q(String s) { return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""; }

    static String lore(String ind, String... lines) {
        StringBuilder b = new StringBuilder(ind + "lore:\n");
        for (String l : lines) b.append(ind).append("  - ").append(q(l)).append('\n');
        return b.toString();
    }

    static String header(String name, int size) {
        return "# Written by DarkholmPass. Edits are overwritten on restart; change DarkholmPass/config.yml instead.\n"
                + "name: " + q(name) + "\nsize: " + size + "\nitems:\n"
                + "  border:\n    is-permanent: true\n    item:\n      material: BLACK_STAINED_GLASS_PANE\n      name: \"&r\"\n"
                + "    slots:\n      - 0-3\n      - 5-8\n      - 46\n      - 47\n      - 51\n      - 52\n      - 9\n      - 17\n      - 18\n      - 26\n      - 27\n      - 35\n      - 36\n      - 44\n";
    }

    static String nav(String key, String slot, String inv, String mat, String name) {
        return "  " + key + ":\n    type: INVENTORY\n    inventory: " + inv + "\n    plugin: zMenu\n    is-permanent: true\n    slot: " + slot
                + "\n    item:\n      material: " + mat + "\n      name: " + q(name) + "\n";
    }

    static String close(String slot) {
        return "  close:\n    is-permanent: true\n    slot: " + slot + "\n    item:\n      material: BARRIER\n      name: \"&cClose\"\n    actions:\n      - type: close\n";
    }

    static String quest(String key, int slot, String kind, int i) {
        String p = "%darkholmpass_" + kind + "_" + i + "_";
        return "  " + key + ":\n    slot: " + slot + "\n"
                + "    view-requirement:\n      requirements:\n        - type: placeholder\n          placeholder: \"" + p + "done%\"\n          value: 1\n          action: SUPERIOR_OR_EQUAL\n"
                + "    item:\n      material: LIME_DYE\n      name: " + q("&a✔ " + p + "name%") + "\n"
                + lore("      ", "&7Complete!", "&a+" + p + "xp% XP earned")
                + "    else:\n      item:\n        material: " + (kind.equals("daily") ? "WRITABLE_BOOK" : "ENCHANTED_BOOK") + "\n"
                + "        name: " + q("&f" + p + "name%") + "\n"
                + lore("        ", p + "bar%", "&7" + p + "progress%&8/&7" + p + "goal%", "", "&eReward: &a+" + p + "xp% XP");
    }

    static String main(DarkholmPass pl) {
        StringBuilder b = new StringBuilder(header("&8⚔ &6&lDarkholm Pass &8· &e%darkholmpass_season%", 54));
        b.append("  info:\n    slot: 4\n    item:\n      material: NETHER_STAR\n      glow: true\n      name: \"&6&lTier %darkholmpass_tier% &7/ %darkholmpass_max_tier%\"\n")
         .append(lore("      ", "%darkholmpass_bar%", "&7%darkholmpass_xp_in_tier%&8/&7%darkholmpass_xp_per_tier% XP to the next tier",
                 "&7Season XP: &f%darkholmpass_xp% &8· &7Rank &f#%darkholmpass_rank%", "",
                 "&7Season ends in &f%darkholmpass_season_days_left% days", "&7Premium track: %darkholmpass_premium_text%"));
        b.append("  daily_label:\n    slot: 19\n    item:\n      material: CLOCK\n      name: \"&e&lDaily Quests\"\n")
         .append(lore("      ", "&7New quests in &f%darkholmpass_daily_reset%"));
        for (int i = 1; i <= 3; i++) b.append(quest("daily" + i, 19 + i, "daily", i));
        b.append("  weekly_label:\n    slot: 28\n    item:\n      material: RECOVERY_COMPASS\n      name: \"&d&lWeekly Quests\"\n")
         .append(lore("      ", "&7New quests in &f%darkholmpass_weekly_reset%"));
        for (int i = 1; i <= 3; i++) b.append(quest("weekly" + i, 28 + i, "weekly", i));
        b.append(nav("rewards", "24", "darkholmpass_rewards", "CHEST", "&6&lRewards"))
         .append(lore("    ", "&7Free and premium tiers", "&a%darkholmpass_claimable% &7ready to claim"));
        b.append(nav("leaderboard", "25", "darkholmpass_top", "GOLDEN_HELMET", "&e&lLeaderboard"))
         .append(lore("    ", "&7This season's top players", "&7You are &f#%darkholmpass_rank%"));
        b.append(nav("titles", "33", "darkholmpass_titles", "NAME_TAG", "&b&lTitles"))
         .append(lore("    ", "&7%darkholmpass_titles_count% unlocked", "&7Show one next to your name"));
        b.append("  claimall:\n    slot: 34\n    refreshOnClick: true\n    item:\n      material: HOPPER\n      name: \"&a&lClaim All\"\n")
         .append(lore("      ", "&7%darkholmpass_claimable% rewards ready"))
         .append("    actions:\n      - type: player_command\n        commands:\n          - \"pass claimall\"\n");
        b.append("  help:\n    slot: 40\n    item:\n      material: BOOK\n      name: \"&eHow it works\"\n")
         .append(lore("      ", "&7Finish daily and weekly quests to earn XP.", "&7Every " + pl.xpPerTier + " XP is a new tier.",
                 "&7Claim keys, items and titles as you rank up.", "&7Everything resets on the 1st of the month;", "&7the top 3 earn a season title."));
        b.append(close("49"));
        return b.toString();
    }

    static String tierItem(DarkholmPass pl, String key, String slot, boolean prem, int n) {
        DarkholmPass.Reward r = (prem ? pl.premiumRewards : pl.freeRewards).get(n);
        String track = prem ? "premium" : "free";
        if (r == null) {
            return "  " + key + ":\n    slot: " + slot + "\n    item:\n      material: " + (prem ? "YELLOW_STAINED_GLASS_PANE" : "LIGHT_GRAY_STAINED_GLASS_PANE")
                    + "\n      name: " + q("&8Tier " + n) + "\n";
        }
        String ph = "%darkholmpass_reward_" + track + "_" + n + "_status%";
        String col = prem ? "&6" : "&a";
        return "  " + key + ":\n    slot: " + slot + "\n    refreshOnClick: true\n"
                + "    view-requirement:\n      requirements:\n        - type: placeholder\n          placeholder: \"" + ph + "\"\n          value: 2\n          action: SUPERIOR_OR_EQUAL\n"
                + "    item:\n      material: " + r.icon() + "\n      glow: true\n      name: " + q(col + "&lTier " + n + " &8· &f" + r.name()) + "\n"
                + lore("      ", "&eClick to claim!")
                + "    actions:\n      - type: player_command\n        commands:\n          - \"pass claim " + track + " " + n + "\"\n"
                + "    else:\n      view-requirement:\n        requirements:\n          - type: placeholder\n            placeholder: \"" + ph + "\"\n            value: 1\n            action: SUPERIOR_OR_EQUAL\n"
                + "      item:\n        material: LIME_STAINED_GLASS_PANE\n        name: " + q("&2Tier " + n + " &8· &7" + r.name()) + "\n"
                + lore("        ", "&aClaimed")
                + "      else:\n        item:\n          material: " + (prem ? "ORANGE_STAINED_GLASS_PANE" : "GRAY_STAINED_GLASS_PANE") + "\n"
                + "          name: " + q("&7Tier " + n + " &8· &7" + r.name()) + "\n"
                + lore("          ", prem ? "&6Donor cosmetic &8· &7reach tier " + n : "&8Reach tier " + n);
    }

    static String rewards(DarkholmPass pl) {
        StringBuilder b = new StringBuilder(header("&8⚔ &6Pass Rewards &8· &7%page%/%max-page%", 54));
        b.append("  free_label:\n    is-permanent: true\n    slots:\n      - 10\n      - 19\n    item:\n      material: LIME_BANNER\n      name: \"&a&lFree Track\"\n")
         .append(lore("      ", "&7Everyone earns these"));
        b.append("  premium_label:\n    is-permanent: true\n    slots:\n      - 28\n      - 37\n    item:\n      material: YELLOW_BANNER\n      name: \"&6&lPremium Track\"\n")
         .append(lore("      ", "&7Cosmetic rewards for donors", "&7%darkholmpass_premium_text%"));
        int pages = (pl.maxTier + 9) / 10;
        int[] fs = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
        int[] ps = {29, 30, 31, 32, 33, 38, 39, 40, 41, 42};
        for (int pg = 1; pg <= pages; pg++) {
            for (int i = 0; i < 10; i++) {
                int n = (pg - 1) * 10 + i + 1;
                if (n > pl.maxTier) break;
                b.append(tierItem(pl, "f" + n, pg + "-" + fs[i], false, n));
                b.append(tierItem(pl, "p" + n, pg + "-" + ps[i], true, n));
            }
        }
        b.append("  previous:\n    type: PREVIOUS\n    slot: 48\n    item:\n      material: ARROW\n      name: \"&ePrevious tiers\"\n");
        b.append("  next:\n    type: NEXT\n    slot: 50\n    item:\n      material: ARROW\n      name: \"&eNext tiers\"\n");
        b.append(nav("back", "45", "darkholmpass_main", "SPYGLASS", "&7Back"));
        b.append(close("53"));
        return b.toString();
    }

    static String top(DarkholmPass pl) {
        StringBuilder b = new StringBuilder(header("&8⚔ &eSeason Leaders &8· &7%darkholmpass_season%", 54));
        int[] slots = {13, 21, 23, 29, 30, 31, 32, 33, 39, 41};
        String[] mats = {"GOLDEN_HELMET", "IRON_HELMET", "CHAINMAIL_HELMET"};
        for (int i = 0; i < 10; i++) {
            int n = i + 1;
            String p = "%darkholmpass_top_" + n + "_";
            b.append("  top").append(n).append(":\n    slot: ").append(slots[i]).append("\n    item:\n      material: ")
             .append(i < 3 ? mats[i] : "LEATHER_HELMET").append("\n      name: ").append(q((i < 3 ? "&6&l#" : "&e#") + n + " &f" + p + "name%")).append('\n')
             .append(lore("      ", "&7Tier &f" + p + "tier%", "&7" + p + "xp% XP"));
        }
        b.append("  you:\n    slot: 49\n    item:\n      material: PLAYER_HEAD\n      playerHead: \"%player%\"\n      name: \"&fYou: &e#%darkholmpass_rank%\"\n")
         .append(lore("      ", "&7Tier %darkholmpass_tier% &8· &7%darkholmpass_xp% XP", "", "&7Top 3 at month's end earn a", "&7season title."));
        b.append(nav("back", "45", "darkholmpass_main", "SPYGLASS", "&7Back"));
        b.append(close("53"));
        return b.toString();
    }

    static String titles(DarkholmPass pl) {
        StringBuilder b = new StringBuilder(header("&8⚔ &bTitles", 54));
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
        List<Map.Entry<String, String>> t = new ArrayList<>(pl.titleDisplay.entrySet());
        for (int i = 0; i < Math.min(t.size(), slots.length); i++) {
            String id = t.get(i).getKey(), disp = t.get(i).getValue();
            b.append("  t").append(i).append(":\n    slot: ").append(slots[i]).append("\n    refreshOnClick: true\n")
             .append("    view-requirement:\n      requirements:\n        - type: placeholder\n          placeholder: \"%darkholmpass_has_title_").append(id)
             .append("%\"\n          value: 1\n          action: SUPERIOR_OR_EQUAL\n")
             .append("    item:\n      material: NAME_TAG\n      name: ").append(q(disp)).append('\n')
             .append(lore("      ", "&eClick to wear this title"))
             .append("    actions:\n      - type: player_command\n        commands:\n          - \"pass title ").append(id).append("\"\n")
             .append("    else:\n      item:\n        material: GRAY_DYE\n        name: ").append(q("&8" + disp.replaceAll("&.", ""))).append('\n')
             .append(lore("        ", "&7Locked: earn it from the pass"));
        }
        b.append("  clear:\n    slot: 49\n    item:\n      material: BUCKET\n      name: \"&7Remove title\"\n    actions:\n      - type: player_command\n        commands:\n          - \"pass title off\"\n");
        b.append(nav("back", "45", "darkholmpass_main", "SPYGLASS", "&7Back"));
        b.append(close("53"));
        return b.toString();
    }
}
