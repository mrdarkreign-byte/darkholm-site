package live.darkholm.elitecash;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.*;

public class EliteCash extends JavaPlugin implements Listener {
    final Set<String> worlds = new HashSet<>();
    double rate;
    String msg, payBlocked;
    boolean blockPay;

    Method checkCurrency, tryWithdraw, isReady;
    Object economy; Method deposit;

    /** Elite Coin balance last seen for each player in a cash world. */
    final Map<UUID, Double> baseline = new HashMap<>();
    double dailyCap; String capMsg;
    final Map<UUID, Double> paidToday = new HashMap<>();
    String day = "";
    java.io.File dayFile;

    String today() { return java.time.LocalDate.now(java.time.ZoneId.of(getConfig().getString("timezone", "America/Los_Angeles"))).toString(); }

    void loadDay() {
        org.bukkit.configuration.file.YamlConfiguration y = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(dayFile);
        day = y.getString("day", today());
        paidToday.clear();
        if (day.equals(today()) && y.getConfigurationSection("paid") != null)
            for (String k : y.getConfigurationSection("paid").getKeys(false)) paidToday.put(UUID.fromString(k), y.getDouble("paid." + k));
        else day = today();
    }

    void saveDay() {
        org.bukkit.configuration.file.YamlConfiguration y = new org.bukkit.configuration.file.YamlConfiguration();
        y.set("day", day);
        paidToday.forEach((k, v) -> y.set("paid." + k, v));
        try { y.save(dayFile); } catch (Exception ignored) { }
    }

    @Override public void onDisable() { if (dayFile != null) saveDay(); }
    long converted;

    @Override public void onEnable() {
        ConfigSync.sync(this);
        for (String w : getConfig().getStringList("worlds")) worlds.add(w.toLowerCase(Locale.ROOT));
        rate = getConfig().getDouble("rate", 1.0);
        msg = ChatColor.translateAlternateColorCodes('&', getConfig().getString("message", ""));
        payBlocked = ChatColor.translateAlternateColorCodes('&', getConfig().getString("pay-blocked-message", ""));
        blockPay = getConfig().getBoolean("block-pay-into-worlds", true);
        dailyCap = getConfig().getDouble("daily-cap", 500);
        capMsg = ChatColor.translateAlternateColorCodes('&', getConfig().getString("cap-message", ""));
        dayFile = new java.io.File(getDataFolder(), "paid-today.yml");
        loadDay();
        try {
            ClassLoader cl = getServer().getPluginManager().getPlugin("EliteMobs").getClass().getClassLoader();
            Class<?> eh = Class.forName("com.magmaguy.elitemobs.economy.EconomyHandler", true, cl);
            checkCurrency = eh.getMethod("checkCurrency", UUID.class);
            tryWithdraw = eh.getMethod("tryWithdraw", UUID.class, double.class);
            isReady = eh.getMethod("isReady", UUID.class);
            Class<?> ecoCls = Class.forName("net.milkbowl.vault.economy.Economy", true,
                    getServer().getPluginManager().getPlugin("Vault").getClass().getClassLoader());
            RegisteredServiceProvider<?> rsp = getServer().getServicesManager().getRegistration(ecoCls);
            if (rsp == null) throw new IllegalStateException("No Vault economy provider");
            economy = rsp.getProvider();
            deposit = ecoCls.getMethod("depositPlayer", OfflinePlayer.class, double.class);
        } catch (Throwable t) {
            getLogger().severe("Hook failed, Elite Coins will not be converted: " + t);
            return;
        }
        getServer().getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) reset(p);
        Bukkit.getScheduler().runTaskTimer(this, this::sweep, 40L, Math.max(1L, getConfig().getLong("check-ticks", 10)));
        getLogger().info("Elite Coins become money (x" + rate + ") in " + worlds);
    }

    static String root2(String c) { c = c.toLowerCase(Locale.ROOT); return c.startsWith("/") ? c : "/" + c; }

    boolean cashWorld(World w) { return w != null && worlds.contains(w.getName().toLowerCase(Locale.ROOT)); }

    Double balance(UUID id) {
        try {
            if (!(Boolean) isReady.invoke(null, id)) return null;
            return (Double) checkCurrency.invoke(null, id);
        } catch (Throwable t) { return null; }
    }

    void reset(Player p) {
        if (!cashWorld(p.getWorld())) { baseline.remove(p.getUniqueId()); return; }
        Double b = balance(p.getUniqueId());
        if (b != null) baseline.put(p.getUniqueId(), b); else baseline.remove(p.getUniqueId());
    }

    void sweep() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!cashWorld(p.getWorld())) { baseline.remove(p.getUniqueId()); continue; }
            UUID id = p.getUniqueId();
            Double now = balance(id);
            if (now == null) continue;
            Double base = baseline.get(id);
            if (base == null || now <= base) { baseline.put(id, now); continue; }
            if (!day.equals(today())) { day = today(); paidToday.clear(); }
            double already = paidToday.getOrDefault(id, 0.0);
            double room = dailyCap > 0 ? Math.max(0, dailyCap - already) : Double.MAX_VALUE;
            if (room <= 0) {
                baseline.put(id, now);
                if (!capMsg.isEmpty()) p.sendActionBar(capMsg);
                continue;
            }
            double gainedRaw = Math.round((now - base) * 100.0) / 100.0;
            // Only convert as many coins as fit under today's cap; the rest stay Elite Coins
            double gained = Math.min(gainedRaw, Math.floor(room / rate * 100.0) / 100.0);
            if (gained <= 0) { baseline.put(id, now); continue; }
            try {
                if (!(Boolean) tryWithdraw.invoke(null, id, gained)) { baseline.put(id, now); continue; }
            } catch (Throwable t) { baseline.put(id, now); continue; }
            double money = Math.round(gained * rate * 100.0) / 100.0;
            try {
                deposit.invoke(economy, p, money);
            } catch (Throwable t) {
                getLogger().warning("Deposit of " + money + " to " + p.getName() + " failed, returning Elite Coins: " + t);
                try {
                    ClassLoader cl = checkCurrency.getDeclaringClass().getClassLoader();
                    Class.forName("com.magmaguy.elitemobs.economy.EconomyHandler", true, cl)
                            .getMethod("refundPayment", UUID.class, double.class).invoke(null, id, gained);
                } catch (Throwable ignored) { }
            }
            Double after = balance(id);
            baseline.put(id, after != null ? after : base);
            converted += Math.round(money);
            paidToday.merge(id, money, Double::sum);
            if (converted % 10 == 0) saveDay();
            if (!msg.isEmpty()) p.sendActionBar(msg.replace("$amount", money == Math.rint(money) ? String.valueOf((long) money) : String.valueOf(money)));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorld(PlayerChangedWorldEvent e) { reset(e.getPlayer()); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) { Bukkit.getScheduler().runTaskLater(this, () -> reset(e.getPlayer()), 40L); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) { baseline.remove(e.getPlayer().getUniqueId()); }

    // /em pay <player> <amount> into a cash world would turn Elite Coins into money
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!blockPay) return;
        String[] a = e.getMessage().trim().split("\\s+");
        if (a.length < 3) return;
        String r0 = a[0].toLowerCase(Locale.ROOT);
        if (r0.contains(":")) r0 = "/" + r0.substring(r0.indexOf(':') + 1);
        final String root = r0;
        if (getConfig().getStringList("pay-commands").stream().noneMatch(c -> root2(c).equals(root))) return;
        int i = 1;
        if (a[i].equalsIgnoreCase("money") && a.length > 3) i++;
        if (!a[i].equalsIgnoreCase("pay")) return;
        Player target = Bukkit.getPlayerExact(a[i + 1]);
        if (target != null && (cashWorld(target.getWorld()) || cashWorld(e.getPlayer().getWorld()))) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(payBlocked);
        }
    }
}
