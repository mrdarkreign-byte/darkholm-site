package live.darkholm.sightline;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

/** Bedrock (Geyser) renders text displays as name tags: they draw through walls and turn to face the viewer.
 *  For Bedrock players only, show a text display only when the player stands in front of it, close enough,
 *  with a clear line of sight. */
public final class Sightline extends JavaPlugin {
    private static double RANGE = 20.0;
    private static double MIN_FACING = 0.57; // cos 55 degrees
    private String skipTag = "dh_private";

    @Override public void onEnable() {
        ConfigSync.sync(this);
        RANGE = getConfig().getDouble("range", 20.0);
        MIN_FACING = Math.cos(Math.toRadians(getConfig().getDouble("max-angle", 55)));
        skipTag = getConfig().getString("skip-tag", "dh_private");
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 40L, Math.max(1L, getConfig().getLong("update-ticks", 10)));
        getLogger().info("Sightline active: Bedrock players only see text panels they face, within " + (int) RANGE + " blocks, with a clear view.");
    }

    private static boolean bedrock(Player p) { return p.getUniqueId().getMostSignificantBits() == 0L; }

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!bedrock(p)) continue;
            Location eye = p.getEyeLocation();
            for (Entity e : p.getNearbyEntities(RANGE + 8, RANGE + 8, RANGE + 8)) {
                if (!(e instanceof TextDisplay)) continue;
                if (e.getScoreboardTags().contains(skipTag)) continue;
                boolean show = visible(eye, e.getLocation());
                boolean sees = p.canSee(e);
                if (show && !sees) p.showEntity(this, e);
                else if (!show && sees) p.hideEntity(this, e);
            }
        }
    }

    private static boolean visible(Location eye, Location panel) {
        double dx = eye.getX() - panel.getX(), dz = eye.getZ() - panel.getZ();
        double flat = Math.sqrt(dx * dx + dz * dz);
        Vector d = panel.toVector().subtract(eye.toVector());
        double len = d.length();
        if (len > RANGE) return false;
        if (flat > 1.0) {
            double yaw = Math.toRadians(panel.getYaw());
            double nx = -Math.sin(yaw), nz = Math.cos(yaw);
            if ((dx * nx + dz * nz) / flat < MIN_FACING) return false;
        }
        if (len < 1.5) return true;
        return eye.getWorld().rayTraceBlocks(eye, d.normalize(), len - 0.6, FluidCollisionMode.NEVER, true) == null;
    }
}
