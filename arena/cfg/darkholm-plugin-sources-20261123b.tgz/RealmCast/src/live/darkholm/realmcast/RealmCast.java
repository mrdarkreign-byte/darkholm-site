package live.darkholm.realmcast;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.BroadcastMessageEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class RealmCast extends JavaPlugin implements Listener {
    static final String HANDLER = "darkholm_realmcast";

    static final class Realm {
        final String name; final List<String> worlds; final List<String> packages; final List<Pattern> patterns;
        Realm(String n, List<String> w, List<String> p, List<Pattern> pt) { name = n; worlds = w; packages = p; patterns = pt; }
        boolean hasWorld(String world) {
            String w = world.toLowerCase(Locale.ROOT);
            for (String g : worlds) {
                String s = g.toLowerCase(Locale.ROOT);
                if (s.endsWith("*") ? w.startsWith(s.substring(0, s.length() - 1)) : w.equals(s)) return true;
            }
            return false;
        }
    }

    volatile List<Realm> realms = List.of();
    Set<String> hubWorlds = new HashSet<>();
    String defaultRealm = "factions";
    Map<String, String> hubGroups = new HashMap<>();
    boolean debug;

    /** Effective realm per online player (read from netty threads). */
    final Map<UUID, String> effective = new ConcurrentHashMap<>();
    /** Last realm world each player entered (persisted). */
    final Map<UUID, String> lastRealm = new ConcurrentHashMap<>();
    File dataFile;
    /** Held-back realm messages waiting for the player to enter that realm: uuid -> list of [realm, epochMillis, json]. */
    final Map<UUID, List<String[]>> queue = new ConcurrentHashMap<>();
    List<Pattern> noQueue = List.of();
    int queueMax = 30; long queueTtl = 72L * 3600_000L; String queueHeader = "";
    File queueFile;

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "last-realms.yml");
        loadSettings();
        YamlConfiguration d = YamlConfiguration.loadConfiguration(dataFile);
        for (String k : d.getKeys(false)) try { lastRealm.put(UUID.fromString(k), d.getString(k)); } catch (Exception ignored) {}
        queueFile = new File(getDataFolder(), "queued.yml");
        YamlConfiguration q = YamlConfiguration.loadConfiguration(queueFile);
        for (String k : q.getKeys(false)) try {
            List<String[]> l = new ArrayList<>();
            for (String e : q.getStringList(k)) { String[] parts = e.split("\\|", 3); if (parts.length == 3) l.add(parts); }
            if (!l.isEmpty()) queue.put(UUID.fromString(k), Collections.synchronizedList(l));
        } catch (Exception ignored) {}
        getServer().getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) { update(p); inject(p); }
        getLogger().info("Realm broadcasts active for " + realms.size() + " realms");
    }

    @Override public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) uninject(p);
        save();
        saveQueue();
    }

    void save() {
        YamlConfiguration d = new YamlConfiguration();
        lastRealm.forEach((k, v) -> d.set(k.toString(), v));
        try { d.save(dataFile); } catch (Exception e) { getLogger().warning("Could not save last-realms.yml: " + e); }
    }

    void saveQueue() {
        YamlConfiguration q = new YamlConfiguration();
        long now = System.currentTimeMillis();
        queue.forEach((k, v) -> {
            List<String> out = new ArrayList<>();
            synchronized (v) { for (String[] e : v) if (now - Long.parseLong(e[1]) < queueTtl) out.add(e[0] + "|" + e[1] + "|" + e[2]); }
            if (!out.isEmpty()) q.set(k.toString(), out);
        });
        try { q.save(queueFile); } catch (Exception e) { getLogger().warning("Could not save queued.yml: " + e); }
    }

    void loadSettings() {
        ConfigSync.sync(this, "realms", "hub-inventory-groups");
        List<Realm> list = new ArrayList<>();
        ConfigurationSection rs = getConfig().getConfigurationSection("realms");
        if (rs != null) for (String name : rs.getKeys(false)) {
            ConfigurationSection r = rs.getConfigurationSection(name);
            List<Pattern> pats = new ArrayList<>();
            for (String s : r.getStringList("patterns")) {
                try { pats.add(Pattern.compile(s)); } catch (Exception e) { getLogger().warning("Bad pattern in " + name + ": " + s); }
            }
            list.add(new Realm(name, r.getStringList("worlds"), r.getStringList("packages"), pats));
        }
        realms = List.copyOf(list);
        hubWorlds = new HashSet<>();
        for (String w : getConfig().getStringList("hub-worlds")) hubWorlds.add(w.toLowerCase(Locale.ROOT));
        defaultRealm = getConfig().getString("default-realm", "factions");
        hubGroups = new HashMap<>();
        ConfigurationSection g = getConfig().getConfigurationSection("hub-inventory-groups");
        if (g != null) for (String k : g.getKeys(false)) hubGroups.put(k, g.getString(k));
        debug = getConfig().getBoolean("debug", false);
        List<Pattern> nq = new ArrayList<>();
        for (String x : getConfig().getStringList("queue.skip-patterns")) try { nq.add(Pattern.compile(x)); } catch (Exception ignored) {}
        noQueue = List.copyOf(nq);
        queueMax = getConfig().getInt("queue.max-per-player", 30);
        queueTtl = getConfig().getLong("queue.hours", 72) * 3600_000L;
        queueHeader = org.bukkit.ChatColor.translateAlternateColorCodes('&', getConfig().getString("queue.header", ""));
    }

    String worldRealm(World w) {
        if (w == null) return null;
        for (Realm r : realms) if (r.hasWorld(w.getName())) return r.name;
        return null;
    }

    String seedFromHubInventory(UUID id) {
        try {
            File f = new File(getDataFolder().getParentFile(), "DarkholmHubInventory/last-groups.yml");
            if (!f.exists()) return null;
            String g = YamlConfiguration.loadConfiguration(f).getString(id.toString());
            return g == null ? null : hubGroups.get(g);
        } catch (Exception e) { return null; }
    }

    void update(Player p) {
        String before = effective.get(p.getUniqueId());
        updateRealm(p);
        String now = effective.get(p.getUniqueId());
        if (now != null && !now.equals(before)) Bukkit.getScheduler().runTaskLater(this, () -> deliver(p), 40L);
        if (now != null && !now.equals(before)) resyncBars(p, before, now);
    }

    void deliver(Player p) {
        if (!p.isOnline()) return;
        String realm = effective.get(p.getUniqueId());
        List<String[]> l = queue.get(p.getUniqueId());
        if (realm == null || l == null) return;
        List<String[]> mine = new ArrayList<>();
        long now = System.currentTimeMillis();
        synchronized (l) {
            Iterator<String[]> it = l.iterator();
            while (it.hasNext()) { String[] e = it.next(); if (now - Long.parseLong(e[1]) >= queueTtl) { it.remove(); continue; } if (e[0].equals(realm)) { mine.add(e); it.remove(); } }
        }
        if (l.isEmpty()) queue.remove(p.getUniqueId());
        if (mine.isEmpty()) return;
        if (!queueHeader.isEmpty()) p.sendMessage(queueHeader);
        for (String[] e : mine) {
            try {
                Class<?> gs = Class.forName("net.kyori.adventure.text.serializer.gson.GsonComponentSerializer");
                Object ser = gs.getMethod("gson").invoke(null);
                Object comp = gs.getMethod("deserialize", Object.class).invoke(ser, e[2]);
                p.sendMessage((net.kyori.adventure.text.Component) comp);
            } catch (Throwable t) { getLogger().warning("Could not deliver queued message: " + t); }
        }
        saveQueue();
    }

    void enqueue(UUID id, String realm, Object packet, String text) {
        for (Pattern pt : noQueue) if (pt.matcher(text).find()) return;
        String json = toJson(packet);
        if (json == null) return;
        List<String[]> l = queue.computeIfAbsent(id, k -> Collections.synchronizedList(new ArrayList<>()));
        synchronized (l) { l.add(new String[]{realm, String.valueOf(System.currentTimeMillis()), json}); while (l.size() > queueMax) l.remove(0); }
    }

    static String toJson(Object packet) {
        try {
            Object vanilla = packet.getClass().getMethod("content").invoke(packet);
            Object adv = null;
            if (vanilla != null) {
                Class<?> pa = Class.forName("io.papermc.paper.adventure.PaperAdventure", true, packet.getClass().getClassLoader());
                for (Method m : pa.getMethods()) if (m.getName().equals("asAdventure") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isInstance(vanilla)) { adv = m.invoke(null, vanilla); break; }
            }
            if (adv == null) for (Field f : packet.getClass().getDeclaredFields()) if (f.getType().getName().equals("net.kyori.adventure.text.Component")) { f.setAccessible(true); adv = f.get(packet); if (adv != null) break; }
            if (adv == null) return null;
            Class<?> gs = Class.forName("net.kyori.adventure.text.serializer.gson.GsonComponentSerializer", true, adv.getClass().getClassLoader());
            Object ser = gs.getMethod("gson").invoke(null);
            for (Method m : gs.getMethods()) if (m.getName().equals("serialize") && m.getParameterCount() == 1) return (String) m.invoke(ser, adv);
        } catch (Throwable ignored) { }
        return null;
    }

    void updateRealm(Player p) {
        String wr = worldRealm(p.getWorld());
        if (wr != null) { lastRealm.put(p.getUniqueId(), wr); effective.put(p.getUniqueId(), wr); return; }
        String last = lastRealm.get(p.getUniqueId());
        if (last == null) { last = seedFromHubInventory(p.getUniqueId()); if (last != null) lastRealm.put(p.getUniqueId(), last); }
        effective.put(p.getUniqueId(), last != null ? last : defaultRealm);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) { update(e.getPlayer()); inject(e.getPlayer()); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorld(PlayerChangedWorldEvent e) { update(e.getPlayer()); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) { effective.remove(e.getPlayer().getUniqueId()); saveQueue(); }

    boolean hears(Player p, String realm) {
        String r = effective.get(p.getUniqueId());
        return r == null || r.equals(realm);
    }

    // ---- Layer 1: Bukkit broadcasts, attributed by the plugin that sent them
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBroadcast(BroadcastMessageEvent e) {
        String realm = callerRealm();
        if (realm == null) return;
        int before = e.getRecipients().size();
        e.getRecipients().removeIf(s -> s instanceof Player p && !hears(p, realm));
        if (debug) getLogger().info("Broadcast from realm " + realm + ": " + before + " -> " + e.getRecipients().size() + " recipients");
    }

    String callerRealm() {
        List<Realm> rs = realms;
        return StackWalker.getInstance().walk(st -> st
                .map(f -> f.getClassName())
                .filter(c -> !c.startsWith("live.darkholm.realmcast"))
                .map(c -> { for (Realm r : rs) for (String pk : r.packages) if (c.startsWith(pk)) return r.name; return null; })
                .filter(Objects::nonNull).findFirst().orElse(null));
    }

    // ---- Layer 2: per-player system messages matched by text
    String patternRealm(String text) {
        for (Realm r : realms) for (Pattern pt : r.patterns) if (pt.matcher(text).find()) return r.name;
        return null;
    }

    static volatile Method contentMethod; static volatile Method getStringMethod;

    static String plain(Object packet) {
        try {
            Method cm = contentMethod;
            if (cm == null || cm.getDeclaringClass() != packet.getClass()) { cm = packet.getClass().getMethod("content"); cm.setAccessible(true); contentMethod = cm; }
            Object comp = cm.invoke(packet);
            if (comp == null) return adventurePlain(packet);
            Method gs = getStringMethod;
            if (gs == null || !gs.getDeclaringClass().isInstance(comp)) { gs = findGetString(comp.getClass()); getStringMethod = gs; }
            return gs == null ? null : (String) gs.invoke(comp);
        } catch (Throwable t) { return null; }
    }

    static String adventurePlain(Object packet) {
        try {
            for (Field f : packet.getClass().getDeclaredFields()) {
                if (!f.getType().getName().equals("net.kyori.adventure.text.Component")) continue;
                f.setAccessible(true);
                Object comp = f.get(packet);
                if (comp == null) continue;
                Class<?> ser = Class.forName("net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer", true, f.getType().getClassLoader());
                Object inst = ser.getMethod("plainText").invoke(null);
                return (String) ser.getMethod("serialize", f.getType()).invoke(inst, comp);
            }
        } catch (Throwable ignored) { }
        return null;
    }

    static Method findGetString(Class<?> c) {
        for (Class<?> k = c; k != null; k = k.getSuperclass())
            for (Class<?> i : k.getInterfaces())
                try { return i.getMethod("getString"); } catch (NoSuchMethodException ignored) {}
        try { return c.getMethod("getString"); } catch (NoSuchMethodException e) { return null; }
    }

    final class Filter extends ChannelOutboundHandlerAdapter {
        final UUID id; final String name;
        Filter(UUID id, String name) { this.id = id; this.name = name; }
        @Override public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
            try {
                String sn = msg == null ? "" : msg.getClass().getSimpleName();
                if (sn.equals("ClientboundBossEventPacket")) {
                    String barRealm = barRealm(msg);
                    String mine = effective.get(id);
                    if (barRealm != null && mine != null && !mine.equals(barRealm)) { promise.trySuccess(); return; }
                } else if (sn.equals("ClientboundSetTitleTextPacket") || sn.equals("ClientboundSetSubtitleTextPacket")) {
                    String text = componentText(msg);
                    String realm = text == null ? null : patternRealm(text);
                    String mine = effective.get(id);
                    if (realm != null && mine != null && !mine.equals(realm)) { promise.trySuccess(); return; }
                } else
                if (msg != null && sn.equals("ClientboundSystemChatPacket")) {
                    String text = plain(msg);
                    if (text != null) {
                        String realm = patternRealm(text);
                        if (realm != null) {
                            String mine = effective.get(id);
                            if (mine != null && !mine.equals(realm)) {
                                if (debug) getLogger().info("Held back from " + name + " (" + mine + "): [" + realm + "] " + text);
                                enqueue(id, realm, msg, text);
                                promise.trySuccess();
                                return;
                            }
                        }
                    }
                }
            } catch (Throwable ignored) { }
            ctx.write(msg, promise);
        }
    }

    // ---- Boss bars and titles: keep realm event bars (e.g. Kingdoms MassWar) inside their realm
    /** Boss bar id -> realm, decided from the bar's title when it is added. */
    final Map<UUID, String> bars = new ConcurrentHashMap<>();
    /** Last ADD packet per realm bar, replayed to players who enter that realm. */
    final Map<UUID, Object> barAdds = new ConcurrentHashMap<>();

    String barRealm(Object pkt) {
        try {
            UUID bid = null; Object op = null;
            for (Field f : pkt.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                if (f.getType() == UUID.class) bid = (UUID) f.get(pkt);
                else if (f.getType().getSimpleName().contains("Operation")) op = f.get(pkt);
            }
            if (bid == null || op == null) return null;
            String on = op.getClass().getSimpleName();
            if (on.contains("Add")) {
                String title = componentText(op);
                String realm = title == null ? null : patternRealm(title);
                if (realm != null) { bars.put(bid, realm); barAdds.put(bid, pkt); }
                else { bars.remove(bid); barAdds.remove(bid); }
                return realm;
            }
            String realm = bars.get(bid);
            if (on.contains("Remove") || on.equals("")) { /* REMOVE is a singleton; keep mapping until bar re-added */ }
            return realm;
        } catch (Throwable t) { return null; }
    }

    /** Plain text of the first Component field (vanilla or adventure) of an object. */
    static String componentText(Object o) {
        try {
            for (Class<?> c = o.getClass(); c != null && c != Object.class; c = c.getSuperclass())
                for (Field f : c.getDeclaredFields()) {
                    String tn = f.getType().getName();
                    if (!(tn.endsWith(".Component") || tn.endsWith("network.chat.Component"))) continue;
                    f.setAccessible(true);
                    Object comp = f.get(o);
                    if (comp == null) continue;
                    if (tn.equals("net.kyori.adventure.text.Component")) {
                        Class<?> ser = Class.forName("net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer", true, f.getType().getClassLoader());
                        Object inst = ser.getMethod("plainText").invoke(null);
                        return (String) ser.getMethod("serialize", f.getType()).invoke(inst, comp);
                    }
                    Method gs = findGetString(comp.getClass());
                    if (gs != null) return (String) gs.invoke(comp);
                }
        } catch (Throwable ignored) { }
        return null;
    }

    void resyncBars(Player p, String before, String now) {
        if (bars.isEmpty()) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            for (Map.Entry<UUID, String> e : bars.entrySet()) {
                try {
                    Object add = barAdds.get(e.getKey());
                    if (add == null) continue;
                    if (e.getValue().equals(now)) sendPacket(p, add);
                    else if (e.getValue().equals(before)) {
                        Method rm = add.getClass().getMethod("createRemovePacket", UUID.class);
                        sendPacket(p, rm.invoke(null, e.getKey()));
                    }
                } catch (Throwable t) { if (debug) getLogger().info("Bar resync failed for " + p.getName() + ": " + t); }
            }
        }, 2L);
    }

    void sendPacket(Player p, Object pkt) throws Exception {
        Object ch = channel(p);
        Class<?> chCls = Class.forName("io.netty.channel.Channel", false, ch.getClass().getClassLoader());
        for (Method m : chCls.getMethods()) if (m.getName().equals("writeAndFlush") && m.getParameterCount() == 1) { m.invoke(ch, pkt); return; }
    }

    Object channel(Player p) throws Exception {
        Object handle = p.getClass().getMethod("getHandle").invoke(p);
        Object listener = fieldOfType(handle, "ServerGamePacketListenerImpl");
        Object conn = fieldOfType(listener, "Connection");
        return fieldOfType(conn, "Channel");
    }

    static Object fieldOfType(Object o, String simple) throws Exception {
        for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass())
            for (Field f : c.getDeclaredFields())
                if (f.getType().getSimpleName().equals(simple)) { f.setAccessible(true); Object v = f.get(o); if (v != null) return v; }
        throw new NoSuchFieldException(simple + " in " + o.getClass().getName());
    }

    Object pipeline(Player p) throws Exception {
        Object ch = channel(p);
        ClassLoader cl = ch.getClass().getClassLoader();
        Class<?> chCls = Class.forName("io.netty.channel.Channel", false, cl);
        return chCls.getMethod("pipeline").invoke(ch);
    }

    void inject(Player p) {
        try {
            Object pipe = pipeline(p);
            ClassLoader cl = pipe.getClass().getClassLoader();
            Class<?> pipeCls = Class.forName("io.netty.channel.ChannelPipeline", false, cl);
            Class<?> handlerCls = Class.forName("io.netty.channel.ChannelHandler", false, cl);
            Method get = pipeCls.getMethod("get", String.class);
            if (get.invoke(pipe, HANDLER) != null) pipeCls.getMethod("remove", String.class).invoke(pipe, HANDLER);
            if (get.invoke(pipe, "packet_handler") == null) { getLogger().warning("No packet_handler in pipeline for " + p.getName()); return; }
            pipeCls.getMethod("addBefore", String.class, String.class, handlerCls)
                    .invoke(pipe, "packet_handler", HANDLER, new Filter(p.getUniqueId(), p.getName()));
            if (debug) getLogger().info("Attached realm filter to " + p.getName());
        } catch (Throwable t) {
            getLogger().warning("Could not attach realm filter to " + p.getName() + ": " + t);
        }
    }

    void uninject(Player p) {
        try {
            Object pipe = pipeline(p);
            Class<?> pipeCls = Class.forName("io.netty.channel.ChannelPipeline", false, pipe.getClass().getClassLoader());
            if (pipeCls.getMethod("get", String.class).invoke(pipe, HANDLER) != null)
                pipeCls.getMethod("remove", String.class).invoke(pipe, HANDLER);
        } catch (Throwable ignored) { }
    }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("reload")) {
            loadSettings();
            for (Player p : Bukkit.getOnlinePlayers()) update(p);
            s.sendMessage("§a[RealmCast] Reloaded " + realms.size() + " realms.");
            return true;
        }
        if (a.length > 0 && a[0].equalsIgnoreCase("test") && a.length > 1) {
            String text = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
            s.sendMessage("§7[RealmCast] '" + text + "' -> realm " + patternRealm(text));
            return true;
        }
        StringBuilder sb = new StringBuilder("§6[RealmCast] §7Players: ");
        for (Player p : Bukkit.getOnlinePlayers()) sb.append("§e").append(p.getName()).append("§7=").append(effective.get(p.getUniqueId())).append(' ');
        s.sendMessage(sb.toString());
        return true;
    }
}
