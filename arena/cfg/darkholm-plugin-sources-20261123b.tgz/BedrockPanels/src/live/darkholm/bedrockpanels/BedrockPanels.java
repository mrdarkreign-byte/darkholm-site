package live.darkholm.bedrockpanels;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.nio.file.Files;
import java.util.*;

/** Bedrock (Floodgate) players: text displays only up close (Geyser renders them as name tags),
 *  and a particle sphere at each EliteMobs wormhole, whose display-entity model Geyser cannot show. */
public class BedrockPanels extends JavaPlugin {
    private double SHOW = 10.0, SCAN = 96.0, WH_RANGE = 32.0;
    private final Map<UUID, Set<UUID>> hidden = new HashMap<>();
    private static final class Hole { String world; double x, y, z, r; Particle.DustOptions dust; }
    private final List<Hole> holes = new ArrayList<>();
    private int ticks = 0, secs = 0;

    static boolean bedrock(Player p) { return p.getUniqueId().getMostSignificantBits() == 0L; }

    @Override public void onEnable() {
        ConfigSync.sync(this);
        SHOW = getConfig().getDouble("panels.show-within", 10.0);
        SCAN = getConfig().getDouble("panels.scan-range", 96.0);
        WH_RANGE = getConfig().getDouble("wormholes.visible-within", 32.0);
        loadHoles();
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 40L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::fx, 60L, 10L);
        getLogger().info("Bedrock players see panels within " + (int) SHOW + " blocks; " + holes.size() + " wormhole markers");
    }

    void loadHoles() {
        holes.clear();
        if (!getConfig().getBoolean("wormholes.enabled", true)) return;
        File dir = new File(getDataFolder().getParentFile(), "EliteMobs/wormholes");
        File[] fs = dir.listFiles((d, n) -> n.endsWith(".yml"));
        if (fs == null) return;
        for (File f : fs) {
            try {
                List<String> lines = Files.readAllLines(f.toPath());
                double size = 1.0; int rgb = Integer.parseInt(getConfig().getString("wormholes.default-colour", "9933ff").replace("#", ""), 16); boolean enabled = true;
                List<String> locs = new ArrayList<>();
                for (String l : lines) {
                    String t = l.trim();
                    if (t.startsWith("isEnabled:")) enabled = !t.contains("false");
                    else if (t.startsWith("sizeMultiplier:")) size = Double.parseDouble(t.substring(15).trim());
                    else if (t.startsWith("particleColor:")) { int c = Integer.parseInt(t.substring(14).trim()); if (c != 0) rgb = c; }
                    else if (t.startsWith("location1:") || t.startsWith("location2:")) locs.add(t.substring(10).trim());
                }
                if (!enabled) continue;
                for (String s : locs) {
                    String[] p = s.split(",");
                    if (p.length < 4) continue;
                    try {
                        Hole h = new Hole(); h.world = p[0].trim();
                        h.x = Double.parseDouble(p[1].trim()); h.y = Double.parseDouble(p[2].trim()); h.z = Double.parseDouble(p[3].trim());
                        h.r = getConfig().getDouble("wormholes.radius", 1.1) * size; h.dust = new Particle.DustOptions(Color.fromRGB(rgb & 0xFFFFFF), (float) getConfig().getDouble("wormholes.particle-size", 1.3));
                        holes.add(h);
                    } catch (NumberFormatException ignored) { }
                }
            } catch (Exception e) { getLogger().warning("wormhole " + f.getName() + ": " + e.getMessage()); }
        }
    }

    void fx() {
        if (holes.isEmpty()) return;
        ticks++;
        double rot = ticks * 0.25;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!bedrock(p)) continue;
            Location pl = p.getLocation();
            String w = p.getWorld().getName();
            for (Hole h : holes) {
                if (!h.world.equals(w)) continue;
                double dx = pl.getX() - h.x, dy = pl.getY() - h.y, dz = pl.getZ() - h.z;
                if (dx * dx + dy * dy + dz * dz > WH_RANGE * WH_RANGE) continue;
                int ring = getConfig().getInt("wormholes.particles-per-ring", 14);
                for (int i = 0; i < ring; i++) {
                    double a = rot + i * Math.PI * 2 / ring, c = Math.cos(a) * h.r, s = Math.sin(a) * h.r;
                    p.spawnParticle(Particle.DUST, new Location(p.getWorld(), h.x + c, h.y + s, h.z), 1, 0, 0, 0, 0, h.dust);
                    p.spawnParticle(Particle.DUST, new Location(p.getWorld(), h.x, h.y + s, h.z + c), 1, 0, 0, 0, 0, h.dust);
                    p.spawnParticle(Particle.DUST, new Location(p.getWorld(), h.x + c, h.y, h.z + s), 1, 0, 0, 0, 0, h.dust);
                }
                p.spawnParticle(Particle.PORTAL, new Location(p.getWorld(), h.x, h.y, h.z), 6, h.r * 0.4, h.r * 0.4, h.r * 0.4, 0.4);
            }
        }
    }

    void tick() {
        if (getConfig().getBoolean("panels.enabled", true)) for (Player p : Bukkit.getOnlinePlayers()) {
            if (!bedrock(p)) continue;
            Set<UUID> h = hidden.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>());
            Location pl = p.getLocation();
            for (Entity e : p.getWorld().getNearbyEntities(pl, SCAN, SCAN, SCAN)) {
                if (!(e instanceof TextDisplay) || !e.isVisibleByDefault()) continue;
                boolean near = e.getLocation().distanceSquared(pl) <= SHOW * SHOW;
                UUID id = e.getUniqueId();
                if (near && h.remove(id)) p.showEntity(this, e);
                else if (!near && h.add(id)) p.hideEntity(this, e);
            }
        }
        hidden.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
        if (++secs % Math.max(10, getConfig().getInt("wormholes.reload-seconds", 300)) == 0) loadHoles();
    }
}
