package live.darkholm.herald;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import java.io.File;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Answers common player questions in chat; unknown questions are pointed to Discord. */
final class Sage {
    private final Herald plugin;
    private final Map<UUID, Long> last = new ConcurrentHashMap<>();
    private final List<String[]> faq = new ArrayList<>();

    Sage(Herald plugin) { this.plugin = plugin; build(); }

    private void add(String keys, String answer) { faq.add(new String[]{keys, answer}); }

    private void build() {
        faq.clear();
        for (Map<?, ?> m : plugin.getConfig().getMapList("sage.topics")) {
            Object k = m.get("keys"), a = m.get("answer");
            if (k != null && a != null) add(String.valueOf(k).toLowerCase(Locale.ROOT), ConfigSync.c(String.valueOf(a)));
        }
    }

    void register() throws Exception {
        @SuppressWarnings("unchecked")
        Class<? extends Event> chat = (Class<? extends Event>) Class.forName("org.bukkit.event.player.AsyncPlayerChatEvent");
        Bukkit.getPluginManager().registerEvent(chat, plugin, EventPriority.MONITOR, (l, e) -> { if (chat.isInstance(e)) onChat(e); }, plugin, true);
        plugin.getLogger().info("Herald sage answering player questions (" + faq.size() + " topics). Turn off with sage.enabled: false in config.yml.");
    }

    private static Object call(Object o, String m) throws Exception { Method md = o.getClass().getMethod(m); md.setAccessible(true); return md.invoke(o); }

    private boolean isQuestion(String m) {
        if (m.endsWith("?")) return true;
        return m.matches("^(how|where|what|whats|what's|why|can|could|is|are|does|do i|who|when|which|anyone know)\\b.*");
    }

    private void onChat(Event e) {
        try {
            File off = new File(plugin.getDataFolder(), "sage.off");
            if (off.exists() || !plugin.getConfig().getBoolean("sage.enabled", true)) return;
            String raw = String.valueOf(call(e, "getMessage"));
            String m = raw.toLowerCase(Locale.ROOT).trim();
            if (m.length() < 4 || !isQuestion(m)) return;
            Object player = call(e, "getPlayer");
            try {
                Method hp = player.getClass().getMethod("hasPermission", String.class);
                if ((Boolean) hp.invoke(player, "darkholm.herald.exempt")) return;
            } catch (NoSuchMethodException ignored) { }
            UUID id = (UUID) call(player, "getUniqueId");
            String padded = " " + m + " ";
            String answer = null;
            for (String[] f : faq) {
                for (String k : f[0].split("\\|")) { if (padded.contains(k)) { answer = f[1]; break; } }
                if (answer != null) break;
            }
            long now = System.currentTimeMillis();
            Long prev = last.get(id);
            long cd = (answer == null ? plugin.getConfig().getLong("sage.unknown-cooldown-seconds", 60) : plugin.getConfig().getLong("sage.cooldown-seconds", 8)) * 1000L;
            if (prev != null && now - prev < cd) return;
            last.put(id, now);
            String unknown = plugin.getConfig().getString("sage.unknown-answer", "");
            if (answer == null && (unknown == null || unknown.isEmpty())) return;
            String msg = ConfigSync.c(plugin.getConfig().getString("sage.prefix", "&8[&6⚔&8] &6Herald&7: ")) + (answer != null ? answer : ConfigSync.c(unknown));
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                try {
                    for (Method md : player.getClass().getMethods()) {
                        if (md.getName().equals("sendMessage") && md.getParameterCount() == 1 && md.getParameterTypes()[0] == String.class) { md.invoke(player, msg); break; }
                    }
                } catch (Exception ex) { plugin.getLogger().warning("sage: " + ex); }
            }, Math.max(1L, plugin.getConfig().getLong("sage.reply-delay-ticks", 15)));
        } catch (Exception ex) { plugin.getLogger().warning("sage: " + ex); }
    }
}
