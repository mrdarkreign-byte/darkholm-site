package live.darkholm.herald;

import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;

/** Herald's Tidings: one line from the config list every few minutes, in order, to everyone online. */
final class Tidings {
    private final Herald plugin;
    private BukkitTask task;
    private int next;

    Tidings(Herald plugin) { this.plugin = plugin; }

    void start() {
        if (task != null) task.cancel();
        if (!plugin.getConfig().getBoolean("tidings.enabled", true)) return;
        long every = Math.max(1, plugin.getConfig().getLong("tidings.every-minutes", 30)) * 1200L;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::post, every, every);
        plugin.getLogger().info("Herald's Tidings: " + plugin.getConfig().getStringList("tidings.lines").size() + " lines, one every "
                + plugin.getConfig().getLong("tidings.every-minutes", 30) + " minutes.");
    }

    private void post() {
        List<String> lines = plugin.getConfig().getStringList("tidings.lines");
        if (lines.isEmpty()) return;
        if (Bukkit.getOnlinePlayers().size() < Math.max(1, plugin.getConfig().getInt("tidings.min-players", 1))) return;
        if (next >= lines.size()) next = 0;
        String line = lines.get(next++);
        String msg = (plugin.getConfig().getBoolean("tidings.blank-line-before", true) ? "\n" : "")
                + ConfigSync.c(plugin.getConfig().getString("tidings.prefix", "&6&l⚔ Herald's Tidings: ") + line);
        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(msg));
    }
}
