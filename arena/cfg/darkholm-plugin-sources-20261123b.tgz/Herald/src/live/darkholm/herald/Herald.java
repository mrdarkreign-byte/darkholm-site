package live.darkholm.herald;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import java.lang.reflect.Method;

public final class Herald extends JavaPlugin implements Listener {
    static String P = "§8[§6⚔§8] ";
    String M(String k, String d) { return ConfigSync.c(getConfig().getString("messages." + k, d)); }
    static Herald I;

    @Override
    @SuppressWarnings("unchecked")
    public void onEnable() {
        I = this;
        ConfigSync.sync(this, "sage.topics");
        P = ConfigSync.c(getConfig().getString("prefix", "&8[&6⚔&8] "));
        try { new Tidings(this).start(); } catch (Throwable t) { getLogger().severe("Tidings failed: " + t); }
        try { new Keeper(this).register(); } catch (Throwable t) { getLogger().severe("Keeper failed: " + t); }
        try { new Sage(this).register(); } catch (Throwable t) { getLogger().severe("Sage failed: " + t); }
        try {
            Plugin f = Bukkit.getPluginManager().getPlugin("Factions");
            ClassLoader cl = f.getClass().getClassLoader();
            Class<? extends Event> create = (Class<? extends Event>) Class.forName("com.massivecraft.factions.event.EventFactionsCreate", true, cl);
            Class<? extends Event> rel = (Class<? extends Event>) Class.forName("com.massivecraft.factions.event.EventFactionsRelationChange", true, cl);
            Class<? extends Event> disband = (Class<? extends Event>) Class.forName("com.massivecraft.factions.event.EventFactionsDisband", true, cl);
            Bukkit.getPluginManager().registerEvent(create, this, EventPriority.MONITOR, (l, e) -> { if (create.isInstance(e)) onCreate(e); }, this, true);
            Bukkit.getPluginManager().registerEvent(rel, this, EventPriority.MONITOR, (l, e) -> { if (rel.isInstance(e)) onRelation(e); }, this, true);
            Bukkit.getPluginManager().registerEvent(disband, this, EventPriority.MONITOR, (l, e) -> { if (disband.isInstance(e)) onDisband(e); }, this, true);
            Class<? extends Event> bed = (Class<? extends Event>) Class.forName("org.bukkit.event.player.PlayerBedEnterEvent");
            Bukkit.getPluginManager().registerEvent(bed, this, EventPriority.MONITOR, (l, e) -> { if (bed.isInstance(e)) onBed(e); }, this, true);
            getLogger().info("Herald listening for faction creation, relations, disbands and sleeping.");
        } catch (Throwable t) {
            getLogger().severe("Herald failed to hook Factions: " + t);
        }
    }

    private static Object call(Object o, String m) throws Exception {
        Method md = o.getClass().getMethod(m);
        md.setAccessible(true);
        return md.invoke(o);
    }

    private static String senderName(Object e) {
        try { Object s = call(e, "getSender"); return s == null ? "Someone" : String.valueOf(call(s, "getName")); }
        catch (Exception ex) { return "Someone"; }
    }

    private void onCreate(Event e) {
        try {
            String name = String.valueOf(call(e, "getFactionName"));
            if (getConfig().getBoolean("announce.faction-created", true)) Bukkit.broadcastMessage(P + M("faction-created", "&e{player} &7hath founded a new faction: &6&l{faction}&7!").replace("{player}", senderName(e)).replace("{faction}", name));
        } catch (Exception ex) { getLogger().warning("create: " + ex); }
    }

    private void onDisband(Event e) {
        try {
            Object fac = call(e, "getFaction");
            if (getConfig().getBoolean("announce.faction-disbanded", true)) Bukkit.broadcastMessage(P + M("faction-disbanded", "&7The faction &6{faction} &7hath fallen and is no more.").replace("{faction}", String.valueOf(call(fac, "getName"))));
        } catch (Exception ex) { getLogger().warning("disband: " + ex); }
    }

    private void onRelation(Event e) {
        try {
            Object a = call(e, "getFaction");
            Object b = call(e, "getOtherFaction");
            Object wish = call(e, "getNewRelation");
            String an = String.valueOf(call(a, "getName")), bn = String.valueOf(call(b, "getName"));
            String w = String.valueOf(wish);
            Bukkit.getScheduler().runTask(this, () -> {
                try {
                    Object actual = null;
                    for (Method m : a.getClass().getMethods()) {
                        if (m.getName().equals("getRelationTo") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isInstance(b)) { actual = m.invoke(a, b); break; }
                    }
                    String act = String.valueOf(actual);
                    if (w.equals(act)) {
                        if (getConfig().getBoolean("announce.relations", true)) Bukkit.broadcastMessage(P + now(an, bn, w));
                    } else {
                        if (getConfig().getBoolean("announce.relations", true)) Bukkit.broadcastMessage(P + wishes(an, bn, w));
                    }
                } catch (Exception ex) { getLogger().warning("relation: " + ex); }
            });
        } catch (Exception ex) { getLogger().warning("relation: " + ex); }
    }

    private void onBed(Event e) {
        try {
            Object result = call(e, "getBedEnterResult");
            if (!"OK".equals(String.valueOf(result))) return;
            Object player = call(e, "getPlayer");
            String name = String.valueOf(call(player, "getName"));
            Bukkit.getScheduler().runTask(this, () -> {
                try {
                    Object world = call(player, "getWorld");
                    java.util.List<?> players = (java.util.List<?>) call(world, "getPlayers");
                    int eligible = 0, sleeping = 0;
                    for (Object p : players) {
                        String gm = String.valueOf(call(p, "getGameMode"));
                        if ("SPECTATOR".equals(gm)) continue;
                        Object ignored = call(p, "isSleepingIgnored");
                        if (Boolean.TRUE.equals(ignored)) continue;
                        eligible++;
                        if (Boolean.TRUE.equals(call(p, "isSleeping"))) sleeping++;
                    }
                    int pct = 100;
                    try {
                        Class<?> gr = Class.forName("org.bukkit.GameRule");
                        Object rule = null;
                        for (String fn : new String[]{"PLAYERS_SLEEPING_PERCENTAGE"}) { try { rule = gr.getField(fn).get(null); } catch (Exception ignore) {} }
                        if (rule != null) {
                            for (Method m : world.getClass().getMethods()) {
                                if (m.getName().equals("getGameRuleValue") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isInstance(rule)) { Object v = m.invoke(world, rule); if (v instanceof Integer) pct = (Integer) v; break; }
                            }
                        }
                    } catch (Exception ignore) {}
                    int needed = Math.max(1, (int) Math.ceil(eligible * Math.max(0, pct) / 100.0));
                    if (needed > eligible) needed = eligible;
                    String sub = M("sleep-title-sub", "&e{sleeping}&7/&e{needed} &7sleepers needed to pass the night").replace("{sleeping}", String.valueOf(sleeping)).replace("{needed}", String.valueOf(needed));
                    String title = M("sleep-title", "&6☾");
                    String line = P + M("sleep-chat", "&6{player} &7lies down to rest. &8(&e{sleeping}&7/&e{needed}&8)").replace("{player}", name).replace("{sleeping}", String.valueOf(sleeping)).replace("{needed}", String.valueOf(needed));
                    if (!getConfig().getBoolean("announce.sleeping", true)) return;
                    for (Object p : players) {
                        for (Method m : p.getClass().getMethods()) {
                            if (m.getName().equals("sendTitle") && m.getParameterCount() == 5) { m.invoke(p, title, sub, 5, 50, 15); break; }
                        }
                        for (Method m : p.getClass().getMethods()) {
                            if (m.getName().equals("sendMessage") && m.getParameterCount() == 1 && m.getParameterTypes()[0] == String.class) { m.invoke(p, line); break; }
                        }
                    }
                } catch (Exception ex) { getLogger().warning("bed: " + ex); }
            });
        } catch (Exception ex) { getLogger().warning("bed: " + ex); }
    }

    private static String rel(String k, String d, String a, String b, String r) {
        return I.M(k, d).replace("{a}", a).replace("{b}", b).replace("{relation}", r.toLowerCase());
    }

    private static String now(String a, String b, String r) {
        switch (r) {
            case "ENEMY": return rel("relation-now.enemy", "&c&lWAR! &6{a} &7hath declared &6{b} &7an &cenemy&7!", a, b, r);
            case "ALLY": return rel("relation-now.ally", "&6{a} &7and &6{b} &7are now sworn &dallies&7!", a, b, r);
            case "TRUCE": return rel("relation-now.truce", "&6{a} &7and &6{b} &7have agreed to a &btruce&7.", a, b, r);
            case "NEUTRAL": return rel("relation-now.neutral", "&6{a} &7and &6{b} &7are now &fneutral&7.", a, b, r);
            default: return rel("relation-now.other", "&6{a} &7and &6{b} &7are now {relation}.", a, b, r);
        }
    }

    private static String wishes(String a, String b, String r) {
        switch (r) {
            case "ALLY": return rel("relation-request.ally", "&6{a} &7seeks an &dalliance &7with &6{b}&7.", a, b, r);
            case "TRUCE": return rel("relation-request.truce", "&6{a} &7offers a &btruce &7to &6{b}&7.", a, b, r);
            case "NEUTRAL": return rel("relation-request.neutral", "&6{a} &7seeks &fpeace &7with &6{b}&7.", a, b, r);
            default: return rel("relation-request.other", "&6{a} &7wishes to be {relation} with &6{b}&7.", a, b, r);
        }
    }
}
