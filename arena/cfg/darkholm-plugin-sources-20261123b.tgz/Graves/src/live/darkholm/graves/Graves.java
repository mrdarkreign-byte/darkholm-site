package live.darkholm.graves;
import org.bukkit.*; import org.bukkit.block.Block; import org.bukkit.entity.ArmorStand; import org.bukkit.persistence.*; import org.bukkit.plugin.java.JavaPlugin;
public class Graves extends JavaPlugin {
  NamespacedKey KEY; long grace; String tag; int depth;
  @Override public void onEnable(){
    ConfigSync.sync(this);
    grace=(long)(getConfig().getDouble("grace-hours",12)*3600000L);
    tag=getConfig().getString("hologram-tag","DeathChest_Hologram");
    depth=getConfig().getInt("chest-search-depth",3);
    long every=Math.max(20L,getConfig().getLong("sweep-seconds",300)*20L);
    KEY=new NamespacedKey(this,"orphan_since");
    Bukkit.getScheduler().runTaskTimer(this,this::sweep,200L,every);
    getLogger().info("Graves sweeper on: holograms removed "+getConfig().getDouble("grace-hours",12)+"h after their chest is gone.");
  }
  boolean chestNear(Location l){ World w=l.getWorld(); if(w==null) return false; int x=l.getBlockX(),y=l.getBlockY(),z=l.getBlockZ(); for(int dy=-depth;dy<=0;dy++){ Block b=w.getBlockAt(x,y+dy,z); if(String.valueOf(b.getType()).contains("CHEST")) return true; } return false; }
  void sweep(){ long now=System.currentTimeMillis(); int removed=0;
    for(World w:Bukkit.getWorlds()) for(ArmorStand a:w.getEntitiesByClass(ArmorStand.class)){
      if(!a.getScoreboardTags().contains(tag)) continue;
      PersistentDataContainer pdc=a.getPersistentDataContainer();
      if(chestNear(a.getLocation())){ if(pdc.get(KEY,PersistentDataType.LONG)!=null) pdc.remove(KEY); continue; }
      Long since=pdc.get(KEY,PersistentDataType.LONG);
      if(since==null){ pdc.set(KEY,PersistentDataType.LONG,now); continue; }
      if(now-since>=grace){ a.remove(); removed++; }
    }
    if(removed>0) getLogger().info("Removed "+removed+" expired grave hologram(s).");
  }
}
