package live.darkholm.litter;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class Litter extends JavaPlugin implements Listener {
    private Set<String> worlds = new HashSet<>();
    private Set<Material> blocks = EnumSet.noneOf(Material.class);
    private int layers;
    private NamespacedKey key;
    private long removed;

    @Override public void onEnable() {
        ConfigSync.sync(this);
        for (String w : getConfig().getStringList("worlds")) worlds.add(w.toLowerCase(Locale.ROOT));
        for (String m : getConfig().getStringList("blocks")) {
            Material mat = Material.matchMaterial(m);
            if (mat != null) blocks.add(mat); else getLogger().warning("Unknown block in config: " + m);
        }
        layers = Math.max(1, getConfig().getInt("layers-above-ground", 2));
        // Changing the marker name makes every chunk get scanned again.
        key = new NamespacedKey(this, getConfig().getString("scan-marker", "litter_cleaned").toLowerCase(Locale.ROOT));
        Bukkit.getPluginManager().registerEvents(this, this);
        int n = 0;
        for (World w : Bukkit.getWorlds()) {
            if (!worlds.contains(w.getName().toLowerCase(Locale.ROOT))) continue;
            for (Chunk c : w.getLoadedChunks()) { clean(c); n++; }
        }
        getLogger().info("Leaf litter purge active in " + worlds + ". Scanned " + n + " loaded chunks, removed " + removed + " so far.");
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        Chunk c = e.getChunk();
        if (worlds.contains(c.getWorld().getName().toLowerCase(Locale.ROOT))) clean(c);
    }

    private void clean(Chunk c) {
        PersistentDataContainer pdc = c.getPersistentDataContainer();
        if (pdc.has(key, PersistentDataType.BYTE)) return;
        World w = c.getWorld();
        int bx = c.getX() << 4, bz = c.getZ() << 4;
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            int y = w.getHighestBlockYAt(bx + x, bz + z, HeightMap.MOTION_BLOCKING_NO_LEAVES) + 1;
            for (int dy = 0; dy < layers; dy++) {
                Block b = c.getBlock(x, y + dy, z);
                if (blocks.contains(b.getType())) { b.setType(Material.AIR, false); removed++; }
            }
        }
        pdc.set(key, PersistentDataType.BYTE, (byte) 1);
    }
}
