package live.darkholm.timber;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.*;

public final class Timber extends JavaPlugin implements Listener {
    private int MAX_LOGS = 300, MAX_LEAVES = 2000, LEAF_REACH = 6, MIN_NATURAL_LEAVES = 3;
    private final Set<String> worlds = new HashSet<>();
    private NamespacedKey key;
    private boolean felling;
    private Object mcTracker; private Method mcCheck;
    private Method dmgMethod;

    @Override public void onEnable() {
        ConfigSync.sync(this);
        MAX_LOGS = getConfig().getInt("max-logs", 300);
        MAX_LEAVES = getConfig().getInt("max-leaves", 2000);
        LEAF_REACH = getConfig().getInt("leaf-reach", 6);
        MIN_NATURAL_LEAVES = getConfig().getInt("min-natural-leaves", 3);
        for (String w : getConfig().getStringList("disabled-worlds")) worlds.add(w.toLowerCase(Locale.ROOT));
        key = new NamespacedKey(this, "placed_logs");
        Bukkit.getPluginManager().registerEvents(this, this);
        hookMcmmo();
        try { dmgMethod = findMethod(Class.forName("org.bukkit.entity.LivingEntity"), "damageItemStack", EquipmentSlot.class, int.class); } catch (Throwable ignored) {}
        getLogger().info("DarkholmTimber active. mcMMO placed-block check: " + (mcCheck != null) + ", axe damage: " + (dmgMethod != null));
    }

    private static Method findMethod(Class<?> c, String n, Class<?>... p) { try { return c.getMethod(n, p); } catch (Throwable t) { return null; } }

    private void hookMcmmo() {
        try {
            Class<?> m = Class.forName("com.gmail.nossr50.mcMMO");
            Method g = findMethod(m, "getUserBlockTracker");
            if (g != null) { mcTracker = g.invoke(null); mcCheck = findMethod(mcTracker.getClass(), "isIneligible", Block.class); }
            if (mcCheck == null) { g = findMethod(m, "getPlaceStore"); if (g != null) { mcTracker = g.invoke(null); mcCheck = findMethod(mcTracker.getClass(), "isTrue", Block.class); } }
        } catch (Throwable ignored) { mcCheck = null; }
    }

    // ---- placed-log tracking (chunk PDC) ----
    private static int pack(Block b) { return ((b.getY() + 2048) << 8) | ((b.getX() & 15) << 4) | (b.getZ() & 15); }

    private boolean tracked(Block b) {
        int[] a = b.getChunk().getPersistentDataContainer().get(key, PersistentDataType.INTEGER_ARRAY);
        if (a == null) return false; int p = pack(b);
        for (int v : a) if (v == p) return true; return false;
    }
    private void setTracked(Block b, boolean on) {
        PersistentDataContainer pdc = b.getChunk().getPersistentDataContainer();
        int[] a = pdc.get(key, PersistentDataType.INTEGER_ARRAY); int p = pack(b);
        if (a == null) a = new int[0];
        int idx = -1; for (int i = 0; i < a.length; i++) if (a[i] == p) { idx = i; break; }
        if (on) { if (idx >= 0) return; int[] n = Arrays.copyOf(a, a.length + 1); n[a.length] = p; pdc.set(key, PersistentDataType.INTEGER_ARRAY, n); }
        else { if (idx < 0) return; if (a.length == 1) { pdc.remove(key); return; }
            int[] n = new int[a.length - 1]; System.arraycopy(a, 0, n, 0, idx); System.arraycopy(a, idx + 1, n, idx, a.length - idx - 1); pdc.set(key, PersistentDataType.INTEGER_ARRAY, n); }
    }
    private boolean placed(Block b) {
        if (tracked(b)) return true;
        if (mcCheck != null) { try { return (Boolean) mcCheck.invoke(mcTracker, b); } catch (Throwable ignored) {} }
        return false;
    }
    private static boolean isLog(Block b) { return Tag.LOGS.isTagged(b.getType()); }
    private static boolean naturalLeaf(Block b) {
        if (!Tag.LEAVES.isTagged(b.getType())) return false;
        BlockData d = b.getBlockData(); return d instanceof Leaves && !((Leaves) d).isPersistent();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) { Block b = e.getBlockPlaced(); if (isLog(b)) setTracked(b, true); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (felling) return;
        Block start = e.getBlock();
        if (!isLog(start)) return;
        boolean wasPlaced = placed(start);
        setTracked(start, false);
        if (wasPlaced) return;
        Player p = e.getPlayer();
        if (!getConfig().getBoolean("enabled", true) || worlds.contains(p.getWorld().getName().toLowerCase(Locale.ROOT))) return;
        if ((getConfig().getBoolean("sneak-to-skip", true) && p.isSneaking()) || !p.hasPermission(getConfig().getString("permission", "darkholm.timber"))) return;
        GameMode gm = p.getGameMode(); if (gm != GameMode.SURVIVAL && gm != GameMode.ADVENTURE) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool == null || !Tag.ITEMS_AXES.isTagged(tool.getType())) return;

        // collect connected natural logs, never below the cut
        int baseY = start.getY();
        List<Block> logs = new ArrayList<>(); Set<Long> seen = new HashSet<>();
        Deque<Block> q = new ArrayDeque<>(); q.add(start); seen.add(id(start));
        while (!q.isEmpty()) {
            Block b = q.poll(); logs.add(b);
            if (logs.size() > MAX_LOGS) return;
            for (int dx = -1; dx <= 1; dx++) for (int dy = 0; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                Block n = b.getRelative(dx, dy, dz);
                if (n.getY() < baseY || !seen.add(id(n)) || !isLog(n)) continue;
                if (placed(n)) return; // touches a build: leave it alone
                q.add(n);
            }
        }
        if (logs.size() < 2) return;

        // collect natural leaves within reach of the trunk
        List<Block> leaves = new ArrayList<>(); Set<Long> lseen = new HashSet<>();
        Deque<Block> lq = new ArrayDeque<>(); Map<Long,Integer> dist = new HashMap<>();
        int[][] d6 = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
        for (Block b : logs) for (int[] d : d6) { Block n = b.getRelative(d[0], d[1], d[2]); long k = id(n);
            if (lseen.add(k) && naturalLeaf(n)) { lq.add(n); dist.put(k, 1); } }
        while (!lq.isEmpty() && leaves.size() < MAX_LEAVES) {
            Block b = lq.poll(); leaves.add(b); int dd = dist.get(id(b));
            if (dd >= LEAF_REACH) continue;
            for (int[] d : d6) { Block n = b.getRelative(d[0], d[1], d[2]); long k = id(n);
                if (lseen.add(k) && naturalLeaf(n)) { lq.add(n); dist.put(k, dd + 1); } }
        }
        if (leaves.size() < MIN_NATURAL_LEAVES) return; // not a real tree

        logs.sort(Comparator.comparingInt(Block::getY));
        int broken = 0;
        felling = true;
        try {
            for (Block b : logs) {
                if (b == start) continue;
                if (!isLog(b)) continue;
                BlockBreakEvent fake = new BlockBreakEvent(b, p);
                Bukkit.getPluginManager().callEvent(fake);
                if (fake.isCancelled()) continue;
                b.breakNaturally(tool, true); broken++;
            }
            if (getConfig().getBoolean("clear-leaves", true)) for (Block b : leaves) {
                if (!naturalLeaf(b)) continue;
                BlockBreakEvent fake = new BlockBreakEvent(b, p);
                Bukkit.getPluginManager().callEvent(fake);
                if (fake.isCancelled()) continue;
                b.breakNaturally(tool, false);
            }
        } finally { felling = false; }
        if (broken > 0 && dmgMethod != null && getConfig().getBoolean("damage-axe", true)) { try { dmgMethod.invoke(p, EquipmentSlot.HAND, broken); } catch (Throwable ignored) {} }
    }

    private static long id(Block b) { return (((long) b.getX() & 0x3FFFFFF) << 38) | (((long) b.getZ() & 0x3FFFFFF) << 12) | ((long) b.getY() & 0xFFF); }
}
