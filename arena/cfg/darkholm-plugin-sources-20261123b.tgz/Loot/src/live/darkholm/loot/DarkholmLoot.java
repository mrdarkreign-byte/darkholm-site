package live.darkholm.loot;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.plugin.java.JavaPlugin;

public final class DarkholmLoot extends JavaPlugin implements Listener {
    private record Entry(Material mat, double weight, int min, int max) {}
    private final List<Entry> bonus = new ArrayList<>();
    private double totalWeight;

    @Override public void onEnable() {
        ConfigSync.sync(this, "bonus", "keys");
        load();
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("darkholmloot").setExecutor((s, c, l, a) -> { ConfigSync.sync(this, "bonus", "keys"); load(); s.sendMessage(ConfigSync.c(getConfig().getString("messages.reloaded", "&aDarkholmLoot reloaded: {count} bonus entries.")).replace("{count}", String.valueOf(bonus.size()))); return true; });
    }

    private void load() {
        bonus.clear(); totalWeight = 0;
        ConfigurationSection sec = getConfig().getConfigurationSection("bonus");
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            Material m = Material.matchMaterial(k);
            String[] p = String.valueOf(sec.get(k)).split(",");
            if (m == null || p.length < 3) { getLogger().warning("Bad bonus entry: " + k); continue; }
            Entry e = new Entry(m, Double.parseDouble(p[0].trim()), Integer.parseInt(p[1].trim()), Integer.parseInt(p[2].trim()));
            bonus.add(e); totalWeight += e.weight();
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLoot(LootGenerateEvent e) {
        if (e.getInventoryHolder() == null) return;
        String key = e.getLootTable().getKey().getKey();
        if (getConfig().getStringList("loot-table-prefixes").stream().noneMatch(key::startsWith)) return;
        if (getConfig().getStringList("disabled-worlds").stream().anyMatch(w -> w.equalsIgnoreCase(e.getWorld().getName()))) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        List<ItemStack> loot = new ArrayList<>(e.getLoot());
        if (!loot.isEmpty() && r.nextDouble() < getConfig().getDouble("double-stack-chance", 0.25)) {
            ItemStack s = loot.get(r.nextInt(loot.size()));
            if (s != null && s.getMaxStackSize() > 1) s.setAmount(Math.min(s.getMaxStackSize(), (int) Math.round(s.getAmount() * getConfig().getDouble("double-stack-multiplier", 2.0))));
        }
        int rolls = r.nextInt(getConfig().getInt("extra-rolls.min", 1), getConfig().getInt("extra-rolls.max", 2) + 1);
        if (r.nextDouble() < getConfig().getDouble("extra-rolls.bonus-chance", 0.3)) rolls++;
        for (int i = 0; i < rolls && totalWeight > 0; i++) {
            ItemStack it = roll(r);
            if (it != null) loot.add(it);
        }
        e.setLoot(loot);
        Entity who = e.getEntity();
        if (who instanceof Player p) {
            ConfigurationSection keys = getConfig().getConfigurationSection("keys");
            if (keys != null) for (String k : keys.getKeys(false)) {
                ConfigurationSection ks = keys.getConfigurationSection(k);
                if (ks == null || r.nextDouble() >= ks.getDouble("chance")) continue;
                String name = p.getName();
                Bukkit.getScheduler().runTask(this, () -> {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), ks.getString("command", "").replace("%player%", name));
                    Player pl = Bukkit.getPlayerExact(name);
                    if (pl != null) pl.sendMessage(ChatColor.translateAlternateColorCodes('&', ks.getString("message", "")));
                });
                getLogger().info(name + " found a " + k + " key in " + key);
                break;
            }
        }
    }

    private ItemStack roll(ThreadLocalRandom r) {
        double x = r.nextDouble() * totalWeight;
        Entry pick = bonus.get(bonus.size() - 1);
        for (Entry b : bonus) { x -= b.weight(); if (x <= 0) { pick = b; break; } }
        ItemStack it = new ItemStack(pick.mat(), r.nextInt(pick.min(), pick.max() + 1));
        if (pick.mat() == Material.ENCHANTED_BOOK && it.getItemMeta() instanceof EnchantmentStorageMeta meta) {
            List<Enchantment> pool = new ArrayList<>();
            boolean curses = getConfig().getBoolean("enchanted-books-allow-curses", false);
            for (Enchantment en : Registry.ENCHANTMENT) if (curses || !en.isCursed()) pool.add(en);
            if (pool.isEmpty()) return null;
            Enchantment en = pool.get(r.nextInt(pool.size()));
            meta.addStoredEnchant(en, r.nextInt(1, en.getMaxLevel() + 1), true);
            it.setItemMeta(meta);
        }
        return it;
    }
}
