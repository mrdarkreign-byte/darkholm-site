#!/bin/bash
# push.sh <Project...>  -> copies built jars to xfer/arena/cfg and pushes; prints sha and names
set -e
cd /home/claude/xfer; git fetch -q origin media-xfer; git rebase -q origin/media-xfer >/dev/null 2>&1 || true
mkdir -p arena/cfg; names=""
for n in "$@"; do j=$(ls /home/claude/plugins/$n/Darkholm*.jar); cp $j arena/cfg/; names="$names $(basename $j)"; done
git add arena/cfg >/dev/null; git commit -qm "Config jars:$names

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_016kN2r8LU1U8UfHbTRzPK7B"; git push -q origin HEAD:media-xfer
echo "SHA=$(git rev-parse HEAD)"; echo "JARS=$names"
