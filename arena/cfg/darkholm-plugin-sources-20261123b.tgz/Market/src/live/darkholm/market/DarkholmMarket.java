package live.darkholm.market;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

/** Darkholm market: villager vendors that buy farm goods and mob drops (capped per player per item per day) and sell themed wares. */
public class DarkholmMarket extends JavaPlugin implements Listener, CommandExecutor {
    static String P = "§8[§6⚖§8] §7"; static final String TAG = "dmarket";
    static final class Vendor { String id, name, profession, type; LinkedHashMap<Material, Double> sells = new LinkedHashMap<>(); LinkedHashMap<Material, double[]> buys = new LinkedHashMap<>(); }
    static final class Holder implements InventoryHolder { Vendor v; Inventory inv; final Map<Integer, Material> sale = new HashMap<>(), buy = new HashMap<>(); public Inventory getInventory() { return inv; } }

    final Map<String, Vendor> vendors = new LinkedHashMap<>();
    YamlConfiguration data; File dataFile; boolean dirty; ZoneId zone = ZoneId.of("America/Los_Angeles");
    Object econ; Method mBal, mWith, mDep; Class<?> offline;

    @Override public void onEnable() {
        getDataFolder().mkdirs();
        if (!new File(getDataFolder(), "config.yml").exists()) saveResource("config.yml", false);
        loadVendors();
        dataFile = new File(getDataFolder(), "data.yml"); data = YamlConfiguration.loadConfiguration(dataFile);
        Bukkit.getPluginManager().registerEvents(this, this);
        getCommand("dmarket").setExecutor(this);
        Bukkit.getScheduler().runTaskLater(this, this::hookVault, 20L);
        Bukkit.getScheduler().runTaskTimer(this, () -> { if (dirty) save(); }, 1200L, 1200L);
        getLogger().info("Loaded " + vendors.size() + " vendors");
    }
    @Override public void onDisable() { if (dirty) save(); }

    String c(String s) { return s == null ? "" : s.replace('&', '§'); }

    String M(String k, String d) { return c(getConfig().getString("messages." + k, d)); }
    String G(String k, String d) { return c(getConfig().getString("gui." + k, d)); }
    List<String> GL(String k, List<String> d) { List<String> l = getConfig().isList("gui." + k) ? getConfig().getStringList("gui." + k) : d; List<String> o = new ArrayList<>(); for (String x : l) o.add(c(x)); return o; }

    void loadVendors() {
        vendors.clear();
        ConfigSync.sync(this, "vendors");
        P = c(getConfig().getString("prefix", "&8[&6⚖&8] &7"));
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "config.yml"));
        try { zone = ZoneId.of(cfg.getString("timezone", "America/Los_Angeles")); } catch (Exception ignored) { }
        ConfigurationSection vs = cfg.getConfigurationSection("vendors"); if (vs == null) return;
        for (String id : vs.getKeys(false)) {
            ConfigurationSection s = vs.getConfigurationSection(id); if (s == null) continue;
            Vendor v = new Vendor(); v.id = id; v.name = c(s.getString("name", id)); v.profession = s.getString("profession", "NONE"); v.type = s.getString("type", "PLAINS");
            ConfigurationSection se = s.getConfigurationSection("sells");
            if (se != null) for (String k : se.getKeys(false)) { Material m = Material.matchMaterial(k); if (m == null || !m.isItem()) { getLogger().warning(id + ": unknown item " + k); continue; } v.sells.put(m, se.getDouble(k)); }
            ConfigurationSection bu = s.getConfigurationSection("buys");
            if (bu != null) for (String k : bu.getKeys(false)) { Material m = Material.matchMaterial(k); if (m == null || !m.isItem()) { getLogger().warning(id + ": unknown item " + k); continue; }
                String[] p = bu.getString(k, "0/0").split("/"); try { v.buys.put(m, new double[]{Double.parseDouble(p[0].trim()), Double.parseDouble(p[1].trim())}); } catch (Exception e) { getLogger().warning(id + ": bad price " + k); } }
            vendors.put(id, v);
        }
    }

    void hookVault() {
        try {
            Class<?> ec = Class.forName("net.milkbowl.vault.economy.Economy"); offline = Class.forName("org.bukkit.OfflinePlayer");
            Object sm = Bukkit.class.getMethod("getServicesManager").invoke(null);
            Object reg = sm.getClass().getMethod("getRegistration", Class.class).invoke(sm, ec);
            econ = reg.getClass().getMethod("getProvider").invoke(reg);
            mBal = ec.getMethod("getBalance", offline); mWith = ec.getMethod("withdrawPlayer", offline, double.class); mDep = ec.getMethod("depositPlayer", offline, double.class);
            getLogger().info("Hooked economy");
        } catch (Throwable t) { getLogger().severe("Vault economy not found: " + t); }
    }
    double bal(Player p) { try { return (Double) mBal.invoke(econ, p); } catch (Exception e) { return 0; } }
    boolean ok(Object resp) { try { return (Boolean) resp.getClass().getMethod("transactionSuccess").invoke(resp); } catch (Exception e) { return false; } }
    boolean withdraw(Player p, double a) { try { return ok(mWith.invoke(econ, p, a)); } catch (Exception e) { return false; } }
    boolean deposit(Player p, double a) { try { return ok(mDep.invoke(econ, p, a)); } catch (Exception e) { return false; } }
    static double r2(double d) { return Math.round(d * 100.0) / 100.0; }
    static String money(double d) { return String.format(Locale.US, "$%,.2f", d); }
    static String pretty(Material m) { String[] w = m.name().toLowerCase(Locale.ROOT).split("_"); StringBuilder b = new StringBuilder(); for (String s : w) { if (b.length() > 0) b.append(' '); b.append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)); } return b.toString(); }

    // ---- daily caps ----
    String today() { return LocalDate.now(zone).toString(); }
    int used(Player p, Material m) { roll(); return data.getInt("counts." + p.getUniqueId() + "." + m.name(), 0); }
    void addUsed(Player p, Material m, int n) { roll(); data.set("counts." + p.getUniqueId() + "." + m.name(), used(p, m) + n); dirty = true; }
    void roll() { String t = today(); if (!t.equals(data.getString("day"))) { data.set("counts", null); data.set("day", t); dirty = true; } }
    void save() { try { data.save(dataFile); dirty = false; } catch (Exception e) { getLogger().warning("save: " + e); } }

    // ---- NPCs ----
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEntityEvent e) {
        Entity en = e.getRightClicked(); if (en == null || !en.getScoreboardTags().contains(TAG)) return;
        e.setCancelled(true);
        if (e.getHand() == EquipmentSlot.OFF_HAND) return;
        for (String t : en.getScoreboardTags()) if (t.startsWith(TAG + "_")) { Vendor v = vendors.get(t.substring(TAG.length() + 1)); if (v != null) open(e.getPlayer(), v); return; }
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteractAt(PlayerInteractAtEntityEvent e) { Entity en = e.getRightClicked(); if (en != null && en.getScoreboardTags().contains(TAG)) e.setCancelled(true); }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) { if (e.getEntity() != null && e.getEntity().getScoreboardTags().contains(TAG)) e.setCancelled(true); }

    // ---- GUI ----
    ItemStack icon(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m, 1); ItemMeta im = i.getItemMeta();
        if (im != null) { im.setDisplayName(name); im.setLore(lore); i.setItemMeta(im); }
        return i;
    }
    void open(Player p, Vendor v) { Holder h = new Holder(); h.v = v; h.inv = Bukkit.createInventory(h, 54, G("title", "&8{vendor}").replace("{vendor}", strip(v.name))); fill(p, h); p.openInventory(h.inv); }
    static String strip(String s) { return s.replaceAll("§.", ""); }
    void fill(Player p, Holder h) {
        Vendor v = h.v; h.sale.clear(); h.buy.clear();
        for (int i = 0; i < 54; i++) h.inv.setItem(i, null);
        int s = 0;
        for (Map.Entry<Material, Double> en : v.sells.entrySet()) { if (s > 26) break; Material m = en.getKey();
            List<String> lore = new ArrayList<>(); lore.add(G("sale-price", "&7Price: &e{price} &7each").replace("{price}", money(en.getValue())));
            if (m.getMaxStackSize() > 1) lore.add(G("sale-hint-stack", "&8Left: buy 1 · Right: buy 16 · Shift: buy {max}").replace("{max}", String.valueOf(m.getMaxStackSize()))); else lore.add(G("sale-hint-single", "&8Click to buy"));
            h.inv.setItem(s, icon(m, G("sale-name", "&f{item}").replace("{item}", pretty(m)), lore)); h.sale.put(s, m); s++; }
        Material pane = Material.matchMaterial("BLACK_STAINED_GLASS_PANE");
        for (int i = 27; i < 36; i++) if (pane != null) h.inv.setItem(i, icon(pane, " ", new ArrayList<>()));
        Material book = Material.matchMaterial("BOOK"), hop = Material.matchMaterial("HOPPER"), gold = Material.matchMaterial("GOLD_NUGGET");
        if (book != null) h.inv.setItem(27, icon(book, G("info-name", "&6{vendor}").replace("{vendor}", strip(v.name)), GL("info-lore", Arrays.asList("&7Top: wares for sale.", "&7Bottom: goods I will buy,", "&7up to a daily limit per item.", "&8Limits reset at midnight."))));
        if (gold != null) h.inv.setItem(35, icon(gold, G("purse", "&eThy purse: &f{money}").replace("{money}", money(bal(p))), new ArrayList<>()));
        if (hop != null && !v.buys.isEmpty()) h.inv.setItem(31, icon(hop, G("sell-all-name", "&aSell All"), GL("sell-all-lore", Arrays.asList("&7Sell everything in thy pack", "&7that {vendor} buys.")).stream().map(x -> x.replace("{vendor}", strip(v.name))).collect(java.util.stream.Collectors.toList())));
        int b = 36;
        for (Map.Entry<Material, double[]> en : v.buys.entrySet()) { if (b > 53) break; Material m = en.getKey(); int cap = (int) en.getValue()[1], u = used(p, m);
            List<String> lore = new ArrayList<>(); lore.add(G("buy-pays", "&7Pays: &a{price} &7each").replace("{price}", money(en.getValue()[0])));
            lore.add(G("buy-sold-today", "&7Sold today: &f{sold}&7/&f{cap}").replace("{sold}", String.valueOf(u)).replace("{cap}", String.valueOf(cap))); lore.add(G("buy-in-pack", "&7In thy pack: &f{count}").replace("{count}", String.valueOf(count(p, m))));
            lore.add(G("buy-hint", "&8Left: sell 1 · Right: sell 64 · Shift: sell all"));
            h.inv.setItem(b, icon(m, G("buy-name", "&aSell {item}").replace("{item}", pretty(m)), lore)); h.buy.put(b, m); b++; }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory(); if (top == null || !(top.getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) return; Player p = (Player) e.getWhoClicked(); Holder h = (Holder) top.getHolder();
        int slot = e.getRawSlot(); ClickType ct = e.getClick();
        if (slot < 0 || slot >= 54) return;
        if (h.sale.containsKey(slot)) buyItem(p, h.v, h.sale.get(slot), ct.isShiftClick() ? 64 : ct.isRightClick() ? getConfig().getInt("right-click-buy", 16) : 1);
        else if (h.buy.containsKey(slot)) sell(p, h.v, h.buy.get(slot), ct.isShiftClick() ? Integer.MAX_VALUE : ct.isRightClick() ? getConfig().getInt("right-click-sell", 64) : 1, true);
        else if (slot == 31) { double total = 0; int n = 0; for (Material m : h.v.buys.keySet()) { double[] r = sellRaw(p, h.v, m, Integer.MAX_VALUE); total += r[1]; n += (int) r[0]; }
            if (n == 0) p.sendMessage(P + M("nothing-to-sell", "Thou hast nothing I would buy today.")); else p.sendMessage(P + M("sold-all", "Sold &f{count}&7 items for &a{money}&7.").replace("{count}", String.valueOf(n)).replace("{money}", money(total)));
            if (n > 0) ding(p); }
        else return;
        fill(p, h);
    }
    @EventHandler public void onDrag(InventoryDragEvent e) { Inventory top = e.getView().getTopInventory(); if (top != null && top.getHolder() instanceof Holder) e.setCancelled(true); }

    void ding(Player p) { try { p.playSound(p.getLocation(), getConfig().getString("sound", "minecraft:entity.experience_orb.pickup"), 0.6f, 1.2f); } catch (Throwable ignored) { } }

    void buyItem(Player p, Vendor v, Material m, int want) {
        int amt = Math.max(1, Math.min(want, m.getMaxStackSize())); double price = r2(v.sells.get(m) * amt);
        if (econ == null) { p.sendMessage(P + M("closed", "&cThe market is closed (no economy).")); return; }
        if (bal(p) + 1e-9 < price) { p.sendMessage(P + M("too-poor", "&cThou needest {money} for {amount} {item}.").replace("{money}", money(price)).replace("{amount}", String.valueOf(amt)).replace("{item}", pretty(m))); return; }
        if (!withdraw(p, price)) { p.sendMessage(P + M("purchase-failed", "&cThe purchase failed.")); return; }
        HashMap<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, amt));
        for (ItemStack i : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), i);
        p.sendMessage(P + M("bought", "Bought &f{amount} {item}&7 for &e{money}&7.").replace("{amount}", String.valueOf(amt)).replace("{item}", pretty(m)).replace("{money}", money(price)) + (left.isEmpty() ? "" : " " + M("pack-full", "&8(Thy pack was full; the rest lies at thy feet.)")));
        ding(p);
    }
    int count(Player p, Material m) { int n = 0; ItemStack proto = new ItemStack(m, 1); for (ItemStack i : p.getInventory().getStorageContents()) if (i != null && i.isSimilar(proto)) n += i.getAmount(); return n; }
    /** returns {items sold, money earned} */
    double[] sellRaw(Player p, Vendor v, Material m, int want) {
        double[] pr = v.buys.get(m); if (pr == null || econ == null) return new double[]{0, 0};
        int cap = (int) pr[1], u = used(p, m); int have = count(p, m); int n = Math.min(Math.min(want, have), Math.max(0, cap - u));
        if (n <= 0) return new double[]{0, 0};
        ItemStack proto = new ItemStack(m, 1); ItemStack[] cont = p.getInventory().getStorageContents(); int left = n;
        for (int i = 0; i < cont.length && left > 0; i++) { ItemStack it = cont[i]; if (it == null || !it.isSimilar(proto)) continue;
            int take = Math.min(left, it.getAmount()); left -= take; if (take == it.getAmount()) cont[i] = null; else it.setAmount(it.getAmount() - take); }
        p.getInventory().setStorageContents(cont);
        double money = r2(pr[0] * n);
        if (!deposit(p, money)) { p.getInventory().addItem(new ItemStack(m, n)); return new double[]{0, 0}; }
        addUsed(p, m, n); return new double[]{n, money};
    }
    void sell(Player p, Vendor v, Material m, int want, boolean msg) {
        double[] pr = v.buys.get(m); int cap = (int) pr[1];
        if (used(p, m) >= cap) { p.sendMessage(P + M("cap-reached", "&cI have bought all the {item} I need from thee today. Return tomorrow.").replace("{item}", pretty(m))); return; }
        if (count(p, m) == 0) { p.sendMessage(P + M("none-to-sell", "Thou hast no plain {item} to sell.").replace("{item}", pretty(m))); return; }
        double[] r = sellRaw(p, v, m, want);
        if (r[0] > 0) { p.sendMessage(P + M("sold", "Sold &f{amount} {item}&7 for &a{money}&7.").replace("{amount}", String.valueOf((int) r[0])).replace("{item}", pretty(m)).replace("{money}", money(r[1]))); ding(p); }
    }

    // ---- admin ----
    void setEnum(Object target, String setter, String cls, String val) {
        try { Class<?> k = Class.forName(cls); Object o = k.getField(val.toUpperCase(Locale.ROOT)).get(null);
            for (Method m : target.getClass().getMethods()) if (m.getName().equals(setter) && m.getParameterCount() == 1 && m.getParameterTypes()[0].isAssignableFrom(k)) { m.invoke(target, o); return; }
        } catch (Throwable t) { getLogger().warning(setter + " " + val + ": " + t); }
    }
    void call(Object target, String name, int v) { try { target.getClass().getMethod(name, int.class).invoke(target, v); } catch (Throwable ignored) { } }

    int removeNpcs(String id) { int n = 0; for (World w : worlds()) for (Entity e : w.getEntities()) if (e.getScoreboardTags().contains(TAG) && (id == null || e.getScoreboardTags().contains(TAG + "_" + id))) { e.remove(); n++; } return n; }
    List<World> worlds() { List<World> l = new ArrayList<>(); for (String n : getConfig().getStringList("npc-worlds")) { World w = Bukkit.getWorld(n); if (w != null) l.add(w); } return l; }

    @Override public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.hasPermission("darkholm.market.admin")) { s.sendMessage(P + "§cNo permission."); return true; }
        if (a.length == 0) { s.sendMessage(P + "/dmarket list | reload | spawn <vendor> [world x y z yaw] | remove <vendor|all> | reset <player>"); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "list": for (Vendor v : vendors.values()) s.sendMessage(P + "§f" + v.id + "§7 - " + v.name + "§7: sells " + v.sells.size() + ", buys " + v.buys.size()); return true;
            case "reload": loadVendors(); s.sendMessage(P + "Reloaded " + vendors.size() + " vendors."); return true;
            case "remove": if (a.length < 2) return false; s.sendMessage(P + "Removed " + removeNpcs(a[1].equalsIgnoreCase("all") ? null : a[1]) + " vendor NPC(s)."); return true;
            case "reset": data.set("counts", null); dirty = true; s.sendMessage(P + "Daily limits reset."); return true;
            case "spawn": {
                if (a.length < 2) return false; Vendor v = vendors.get(a[1]); if (v == null) { s.sendMessage(P + "§cUnknown vendor."); return true; }
                Location loc;
                if (a.length >= 7) { World w = Bukkit.getWorld(a[2]); if (w == null) { s.sendMessage(P + "§cUnknown world."); return true; }
                    loc = new Location(w, Double.parseDouble(a[3]), Double.parseDouble(a[4]), Double.parseDouble(a[5]), Float.parseFloat(a[6]), 0f); }
                else if (s instanceof Player) loc = ((Player) s).getLocation(); else { s.sendMessage(P + "Console: spawn <vendor> <world> <x> <y> <z> <yaw>"); return true; }
                removeNpcs(v.id);
                Villager vil = loc.getWorld().spawn(loc, Villager.class, x -> {
                    x.setAI(false); x.setInvulnerable(true); x.setSilent(true); x.setPersistent(true); x.setRemoveWhenFarAway(false); x.setCollidable(false);
                    x.setCustomName(v.name); x.setCustomNameVisible(true); x.addScoreboardTag(TAG); x.addScoreboardTag(TAG + "_" + v.id);
                    setEnum(x, "setProfession", "org.bukkit.entity.Villager$Profession", v.profession);
                    setEnum(x, "setVillagerType", "org.bukkit.entity.Villager$Type", v.type);
                    call(x, "setVillagerLevel", 5);
                });
                s.sendMessage(P + "Spawned " + v.name + "§7 at " + (int) loc.getX() + " " + (int) loc.getY() + " " + (int) loc.getZ() + ".");
                return true; }
        }
        return false;
    }
}
