package com.darkholm.foodguard;

import org.bukkit.Bukkit;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Gates BetterFood auto-eating: paused while combat-tagged, and at most once per cooldown. */
public class DarkholmFoodGuard extends JavaPlugin implements Listener {
    private Object api;
    private Method isInCombat;
    private long cooldownMs;
    private final Map<UUID, PermissionAttachment> blocked = new HashMap<>();
    private final Map<UUID, Integer> pending = new HashMap<>();
    private final Map<UUID, Long> lastEat = new HashMap<>();

    @Override public void onEnable() {
        ConfigSync.sync(this);
        cooldownMs = Math.max(0, getConfig().getInt("cooldown-seconds", 60)) * 1000L;
        try {
            Class<?> c = Class.forName("nl.marido.deluxecombat.api.DeluxeCombatAPI");
            api = c.getConstructor().newInstance();
            isInCombat = c.getMethod("isInCombat", Player.class);
            getLogger().info("Hooked DeluxeCombat: BetterFood pauses while combat-tagged");
        } catch (Throwable t) {
            getLogger().warning("DeluxeCombat API not found; combat pause inactive: " + t);
        }
        getLogger().info("Auto-eat cooldown: " + (cooldownMs / 1000) + "s");
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    boolean inCombat(Player p) {
        if (isInCombat == null) return false;
        try { return (Boolean) isInCombat.invoke(api, p); } catch (Throwable t) { return false; }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void before(FoodLevelChangeEvent e) {
        HumanEntity h = e.getEntity();
        if (!(h instanceof Player)) return;
        Player p = (Player) h;
        int cur = p.getFoodLevel();
        if (e.getFoodLevel() >= cur) return; // only hunger drops trigger BetterFood
        UUID id = p.getUniqueId();
        Long last = lastEat.get(id);
        boolean cooling = last != null && System.currentTimeMillis() - last < cooldownMs;
        if (cooling || (getConfig().getBoolean("pause-in-combat", true) && inCombat(p))) {
            PermissionAttachment a = p.addAttachment(this);
            a.setPermission(getConfig().getString("betterfood-permission", "betterfood.user"), false);
            blocked.put(id, a);
        } else {
            pending.put(id, e.getFoodLevel());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void after(FoodLevelChangeEvent e) {
        HumanEntity h = e.getEntity();
        if (!(h instanceof Player)) return;
        Player p = (Player) h;
        UUID id = p.getUniqueId();
        PermissionAttachment a = blocked.remove(id);
        if (a != null) p.removeAttachment(a);
        Integer req = pending.remove(id);
        if (req != null && !e.isCancelled() && e.getFoodLevel() > req) lastEat.put(id, System.currentTimeMillis());
    }
}
