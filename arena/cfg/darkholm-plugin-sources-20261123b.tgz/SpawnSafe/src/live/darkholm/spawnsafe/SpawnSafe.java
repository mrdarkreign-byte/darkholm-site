package live.darkholm.spawnsafe;
import org.bukkit.*; import org.bukkit.entity.*; import org.bukkit.event.*; import org.bukkit.event.entity.EntityDamageEvent; import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;
public final class SpawnSafe extends JavaPlugin implements Listener {
  private String world; private double x1,x2,z1,z2; private final Set<EntityDamageEvent.DamageCause> causes=EnumSet.noneOf(EntityDamageEvent.DamageCause.class);
  @Override public void onEnable(){
    ConfigSync.sync(this);
    world=getConfig().getString("zone.world","Darkholm");
    x1=getConfig().getDouble("zone.min-x",912); x2=getConfig().getDouble("zone.max-x",1088);
    z1=getConfig().getDouble("zone.min-z",976); z2=getConfig().getDouble("zone.max-z",1152);
    for(String c:getConfig().getStringList("blocked-damage")){ try{ causes.add(EntityDamageEvent.DamageCause.valueOf(c.toUpperCase(Locale.ROOT))); }catch(IllegalArgumentException ex){ getLogger().warning("Unknown damage type: "+c); } }
    Bukkit.getPluginManager().registerEvents(this,this);
  }
  private boolean inSpawn(Location l){ return l.getWorld()!=null && l.getWorld().getName().equals(world) && l.getX()>=x1 && l.getX()<x2 && l.getZ()>=z1 && l.getZ()<z2; }
  @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
  public void onDamage(EntityDamageEvent e){ if(!(e.getEntity() instanceof Player p)) return; if(!causes.contains(e.getCause())) return;
    if(!inSpawn(p.getLocation())) return; e.setCancelled(true); if(e.getCause()==EntityDamageEvent.DamageCause.DROWNING) p.setRemainingAir(p.getMaximumAir()); else if(e.getCause()!=EntityDamageEvent.DamageCause.FALL) p.setFireTicks(0); }
}
