package live.darkholm.spawners;
import org.bukkit.*; import org.bukkit.block.*; import org.bukkit.command.*; import org.bukkit.entity.*; import org.bukkit.event.*; import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack; import org.bukkit.inventory.meta.ItemMeta; import org.bukkit.persistence.PersistentDataType; import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;
public class Spawners extends JavaPlugin implements Listener, CommandExecutor {
  private NamespacedKey key;
  private String m(String k,String d){ return ConfigSync.c(getConfig().getString("messages."+k,d)); }
  @Override public void onEnable(){ ConfigSync.sync(this); key=new NamespacedKey(this,"spawner_type"); Bukkit.getPluginManager().registerEvents(this,this); getCommand("dhspawner").setExecutor(this); }
  static String pretty(String s){ StringBuilder b=new StringBuilder(); for(String w: s.toLowerCase(Locale.ROOT).split("_")){ if(w.isEmpty())continue; if(b.length()>0)b.append(' '); b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)); } return b.toString(); }
  @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a){
    if(!s.hasPermission("darkholm.spawner.give")){ s.sendMessage(m("no-permission","&cNo permission.")); return true; }
    if(a.length<3||!a[0].equalsIgnoreCase("give")){ s.sendMessage(m("usage","&eUsage: /dhspawner give <player> <mob> [amount]")); return true; }
    Player p=Bukkit.getPlayerExact(a[1]); if(p==null){ s.sendMessage(m("not-online","&cPlayer not online: {player}").replace("{player}",a[1])); return true; }
    EntityType t; try{ t=EntityType.valueOf(a[2].toUpperCase(Locale.ROOT)); }catch(IllegalArgumentException e){ s.sendMessage(m("unknown-mob","&cUnknown mob: {mob}").replace("{mob}",a[2])); return true; }
    int amt=1; if(a.length>3){ try{ amt=Math.max(1,Math.min(getConfig().getInt("max-amount",64),Integer.parseInt(a[3]))); }catch(NumberFormatException ignored){} }
    ItemStack it=new ItemStack(Material.SPAWNER,amt); ItemMeta m=it.getItemMeta(); String n=pretty(t.name());
    m.setDisplayName(ConfigSync.c(getConfig().getString("item.name","&6{mob} Spawner")).replace("{mob}",n)); List<String> lore=new ArrayList<>(); for(String x:getConfig().getStringList("item.lore")) lore.add(ConfigSync.c(x).replace("{mob}",n)); m.setLore(lore);
    m.getPersistentDataContainer().set(key,PersistentDataType.STRING,t.name()); it.setItemMeta(m);
    p.getInventory().addItem(it); s.sendMessage(m("given","&aGave {amount}x {mob} Spawner to {player}").replace("{amount}",String.valueOf(amt)).replace("{mob}",n).replace("{player}",a[1])); return true;
  }
  @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
  public void onPlace(BlockPlaceEvent e){
    ItemStack it=e.getItemInHand(); if(it==null||it.getType()!=Material.SPAWNER) return; ItemMeta m=it.getItemMeta(); if(m==null) return;
    String t=m.getPersistentDataContainer().get(key,PersistentDataType.STRING); if(t==null) return;
    final Block b=e.getBlockPlaced(); final EntityType et; try{ et=EntityType.valueOf(t); }catch(IllegalArgumentException x){ return; }
    Bukkit.getScheduler().runTask(this,()->{ if(b.getType()!=Material.SPAWNER) return; BlockState st=b.getState(); if(st instanceof CreatureSpawner cs){ cs.setSpawnedType(et); cs.update(true); } });
  }
}
