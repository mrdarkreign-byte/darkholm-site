package live.darkholm.hubinv;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.mvplugins.multiverse.inventories.MultiverseInventoriesApi;
import org.mvplugins.multiverse.inventories.event.WorldChangeShareHandlingEvent;
import org.mvplugins.multiverse.inventories.event.WriteOnlyShareHandlingEvent;
import org.mvplugins.multiverse.inventories.handleshare.PersistingProfile;
import org.mvplugins.multiverse.inventories.profile.group.WorldGroup;
import org.mvplugins.multiverse.inventories.profile.group.WorldGroupManager;
import org.mvplugins.multiverse.inventories.profile.key.ContainerType;
import org.mvplugins.multiverse.inventories.profile.key.ProfileKey;
import org.mvplugins.multiverse.inventories.profile.key.ProfileType;

/**
 * Makes the hub show the inventory of the last world group a player was in.
 *
 * The hub world sits in its own Multiverse-Inventories group. This plugin rewrites
 * that group's share handling per player:
 *  - entering the hub: the old group is saved as normal, but nothing is loaded,
 *    so the player keeps the inventory they arrived with;
 *  - leaving the hub (or quitting in it): what they have is saved to their last
 *    group instead of the hub group, and if they return to that same group nothing
 *    is reloaded, so changes made in the hub (crate rewards, used keys) stick.
 */
public final class HubInventory extends JavaPlugin implements Listener {

    private String hubWorld;
    private String fallbackGroup;
    private java.util.Set<String> skipGroups = new java.util.HashSet<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        ConfigSync.sync(this);
        hubWorld = getConfig().getString("hub-world", "hub").toLowerCase();
        fallbackGroup = getConfig().getString("fallback-group", "default");
        for (String g : getConfig().getStringList("skip-groups")) skipGroups.add(g.toLowerCase());
        dataFile = new File(getDataFolder(), "last-groups.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("Hub world '" + hubWorld + "' follows each player's last group (fallback '" + fallbackGroup + "').");
    }

    private boolean isHub(String world) {
        return world != null && world.equalsIgnoreCase(hubWorld);
    }

    private WorldGroupManager groups() {
        return MultiverseInventoriesApi.get().getWorldGroupManager();
    }

    private String lastGroup(UUID id) {
        return data.getString(id.toString(), fallbackGroup);
    }

    private void setLastGroup(UUID id, String group) {
        if (group == null || group.equals(data.getString(id.toString()))) return;
        data.set(id.toString(), group);
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().warning("Could not save last-groups.yml: " + e.getMessage());
        }
    }

    private WorldGroup resolveLastGroup(Player p) {
        WorldGroupManager wgm = groups();
        WorldGroup g = wgm.getGroup(lastGroup(p.getUniqueId()));
        if (g == null || g.containsWorld(hubWorld)) g = wgm.getGroup(fallbackGroup);
        if (g == null) g = wgm.getDefaultGroup();
        return g;
    }

    private static boolean isGroupKey(ProfileKey k, String group) {
        return k != null && k.getContainerType() == ContainerType.GROUP && group.equalsIgnoreCase(k.getDataName());
    }

    private boolean isSkip(String group) { return group != null && skipGroups.contains(group.toLowerCase()); }

    /** Swaps reads aimed at the hub's own group over to the given group. */
    private boolean redirectHubReads(List<PersistingProfile> reads, Player p, WorldGroup target) {
        List<WorldGroup> hubGroups = groups().getGroupsForWorld(hubWorld);
        ProfileType type = null;
        boolean removed = false;
        for (Iterator<PersistingProfile> it = reads.iterator(); it.hasNext(); ) {
            ProfileKey k = it.next().getProfileKey();
            for (WorldGroup hg : hubGroups) if (isGroupKey(k, hg.getName())) { type = k.getProfileType(); it.remove(); removed = true; break; }
        }
        if (!removed) return false;
        reads.add(new PersistingProfile(target.getApplicableShares(), target.getGroupProfileContainer().getProfileKey(type, p)));
        return true;
    }

    /** Swaps writes aimed at the hub's own group over to the player's last group. */
    private boolean redirectHubWrites(List<PersistingProfile> writes, Player p, WorldGroup target) {
        List<WorldGroup> hubGroups = groups().getGroupsForWorld(hubWorld);
        ProfileType type = null;
        boolean removed = false;
        for (Iterator<PersistingProfile> it = writes.iterator(); it.hasNext(); ) {
            PersistingProfile pp = it.next();
            ProfileKey k = pp.getProfileKey();
            for (WorldGroup hg : hubGroups) {
                if (isGroupKey(k, hg.getName())) {
                    type = k.getProfileType();
                    it.remove();
                    removed = true;
                    break;
                }
            }
        }
        if (!removed) return false;
        ProfileKey key = target.getGroupProfileContainer().getProfileKey(type, p);
        writes.add(new PersistingProfile(target.getApplicableShares(), key));
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onWorldChange(WorldChangeShareHandlingEvent e) {
        boolean fromHub = isHub(e.getFromWorld());
        boolean toHub = isHub(e.getToWorld());
        if (fromHub == toHub) return;
        Player p = e.getPlayer();
        WorldGroupManager wgm = groups();

        if (toHub) {
            // Entering the hub: save the old group as normal, load nothing.
            List<WorldGroup> from = wgm.getGroupsForWorld(e.getFromWorld());
            String g = from.isEmpty() ? lastGroup(p.getUniqueId()) : from.get(0).getName();
            if (isSkip(g)) {
                // Coming back from a side world (the mob arena): load the realm inventory they had before it.
                WorldGroup back = resolveLastGroup(p);
                if (back != null && !isSkip(back.getName()) && redirectHubReads(e.getReadProfiles(), p, back)) {
                    if (getConfig().getBoolean("log-moves", true)) getLogger().info(p.getName() + " entered hub from " + e.getFromWorld() + " - loaded '" + back.getName() + "' inventory");
                    return;
                }
            }
            e.getReadProfiles().clear();
            setLastGroup(p.getUniqueId(), g);
            if (getConfig().getBoolean("log-moves", true)) getLogger().info(p.getName() + " entered hub from " + e.getFromWorld() + " - keeping '" + g + "' inventory");
            return;
        }

        // Leaving the hub: save to the last group instead of the hub group.
        WorldGroup last = resolveLastGroup(p);
        if (last == null) {
            getLogger().warning("No group found for " + p.getName() + " - leaving Multiverse-Inventories defaults");
            return;
        }
        boolean redirected = redirectHubWrites(e.getWriteProfiles(), p, last);
        List<WorldGroup> to = wgm.getGroupsForWorld(e.getToWorld());
        boolean sameGroup = to.contains(last);
        if (sameGroup) e.getReadProfiles().clear();
        if (!to.isEmpty() && !isSkip(to.get(0).getName())) setLastGroup(p.getUniqueId(), to.get(0).getName());
        if (getConfig().getBoolean("log-moves", true)) getLogger().info(p.getName() + " left hub for " + e.getToWorld() + " - saved to '" + last.getName() + "'"
                + (redirected ? "" : " (no hub write found)") + (sameGroup ? ", kept inventory" : ", loaded '" + (to.isEmpty() ? "?" : to.get(0).getName()) + "'"));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onWriteOnly(WriteOnlyShareHandlingEvent e) {
        Player p = e.getPlayer();
        if (!isHub(p.getWorld().getName())) return;
        WorldGroup last = resolveLastGroup(p);
        if (last == null) return;
        if (redirectHubWrites(e.getWriteProfiles(), p, last)) {
            if (getConfig().getBoolean("log-moves", true)) getLogger().info(p.getName() + " saved in hub - written to '" + last.getName() + "'");
        }
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length != 1) {
            sender.sendMessage("Usage: /hubinv <player>");
            return true;
        }
        @SuppressWarnings("deprecation")
        OfflinePlayer op = Bukkit.getOfflinePlayer(args[0]);
        sender.sendMessage(args[0] + " hub inventory follows group: " + lastGroup(op.getUniqueId())
                + (data.contains(op.getUniqueId().toString()) ? "" : " (fallback)"));
        return true;
    }
}
