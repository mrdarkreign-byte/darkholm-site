package org.mvplugins.multiverse.inventories.commands.bulkedit.playerprofile;

import org.jvnet.hk2.annotations.Service;
import org.mvplugins.multiverse.core.command.MVCommandIssuer;
import org.mvplugins.multiverse.core.command.flag.ParsedCommandFlags;
import org.mvplugins.multiverse.core.command.queue.CommandQueueManager;
import org.mvplugins.multiverse.core.command.queue.CommandQueuePayload;
import org.mvplugins.multiverse.core.locale.message.Message;
import org.mvplugins.multiverse.external.acf.commands.annotation.CommandCompletion;
import org.mvplugins.multiverse.external.acf.commands.annotation.CommandPermission;
import org.mvplugins.multiverse.external.acf.commands.annotation.Subcommand;
import org.mvplugins.multiverse.external.acf.commands.annotation.Syntax;
import org.mvplugins.multiverse.external.jakarta.inject.Inject;
import org.mvplugins.multiverse.external.jetbrains.annotations.NotNull;
import org.mvplugins.multiverse.inventories.commands.bulkedit.BulkEditCommand;
import org.mvplugins.multiverse.inventories.profile.bulkedit.BulkEditAction;
import org.mvplugins.multiverse.inventories.profile.bulkedit.BulkEditCreator;
import org.mvplugins.multiverse.inventories.profile.bulkedit.PlayerProfilesPayload;
import org.mvplugins.multiverse.inventories.profile.key.ContainerKey;
import org.mvplugins.multiverse.inventories.profile.key.GlobalProfileKey;
import org.mvplugins.multiverse.inventories.profile.key.ProfileType;
import org.mvplugins.multiverse.inventories.share.Sharable;
import org.mvplugins.multiverse.inventories.util.MVInvi18n;

import static org.mvplugins.multiverse.core.locale.message.MessageReplacement.replace;

@Service
final class DeleteCommand extends BulkEditCommand {

    private final CommandQueueManager commandQueueManager;
    private final IncludeGroupsWorldsFlag flags;

    @Inject
    DeleteCommand(
            @NotNull BulkEditCreator bulkEditCreator,
            @NotNull CommandQueueManager commandQueueManager,
            @NotNull IncludeGroupsWorldsFlag flags
    ) {
        super(bulkEditCreator);
        this.commandQueueManager = commandQueueManager;
        this.flags = flags;
    }

    @Subcommand("bulkedit playerprofile delete")
    @CommandPermission("multiverse.inventories.bulkedit")
    @CommandCompletion("@shares @mvinvplayernames @mvinvcontainerkeys @mvinvprofiletypes:multiple @flags:groupName=" + IncludeGroupsWorldsFlag.NAME)
    @Syntax("<sharable> <players> <groups/worlds> [profile-type] [--include-groups-worlds]")
    void onCommand(
            MVCommandIssuer issuer,

            @Syntax("<sharable>")
            Sharable<?> sharable,

            @Syntax("<players>")
            GlobalProfileKey[] globalProfileKeys,

            @Syntax("<groups/worlds>")
            ContainerKey[] containerKeys,

            @Syntax("[profile-types]")
            ProfileType[] profileTypes,

            @Syntax("[--include-groups-worlds]")
            String[] flagArray
    ) {
        ParsedCommandFlags parsedFlags = flags.parse(flagArray);

        BulkEditAction<?> bulkEditAction = bulkEditCreator.playerProfileDeleteSharable(
                new PlayerProfilesPayload(
                        globalProfileKeys,
                        containerKeys,
                        profileTypes,
                        parsedFlags.hasFlag(flags.includeGroupsWorlds)
                ),
                sharable
        );

        outputActionSummary(issuer, bulkEditAction);

        commandQueueManager.addToQueue(CommandQueuePayload.issuer(issuer)
                .prompt(Message.of(MVInvi18n.BULKEDIT_PLAYERPROFILE_DELETE_CONFIRMPROMPT,
                        replace("{share}").with(sharable)))
                .action(() -> runBulkEditAction(issuer, bulkEditAction)));
    }
}
