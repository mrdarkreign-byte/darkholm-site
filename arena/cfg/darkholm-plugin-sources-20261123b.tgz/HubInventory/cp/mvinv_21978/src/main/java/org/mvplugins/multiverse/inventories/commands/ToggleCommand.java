package org.mvplugins.multiverse.inventories.commands;

import org.mvplugins.multiverse.core.command.LegacyAliasCommand;
import org.mvplugins.multiverse.core.command.MVCommandIssuer;
import org.mvplugins.multiverse.inventories.config.InventoriesConfig;
import org.mvplugins.multiverse.inventories.share.Sharable;
import org.mvplugins.multiverse.inventories.share.Sharables;
import org.mvplugins.multiverse.inventories.share.Shares;
import org.mvplugins.multiverse.external.acf.commands.annotation.CommandAlias;
import org.mvplugins.multiverse.external.acf.commands.annotation.CommandCompletion;
import org.mvplugins.multiverse.external.acf.commands.annotation.CommandPermission;
import org.mvplugins.multiverse.external.acf.commands.annotation.Description;
import org.mvplugins.multiverse.external.acf.commands.annotation.Single;
import org.mvplugins.multiverse.external.acf.commands.annotation.Subcommand;
import org.mvplugins.multiverse.external.acf.commands.annotation.Syntax;
import org.mvplugins.multiverse.external.jakarta.inject.Inject;
import org.mvplugins.multiverse.external.jetbrains.annotations.NotNull;
import org.jvnet.hk2.annotations.Service;
import org.mvplugins.multiverse.inventories.util.MVInvi18n;

import static org.mvplugins.multiverse.core.locale.message.MessageReplacement.replace;

@Service
class ToggleCommand extends InventoriesCommand {

    private static final String LAST_LOCATION_CONFIG_URL =
            "https://mvplugins.org/inventories/how-to/configure-last-location/";

    private final InventoriesConfig inventoriesConfig;

    @Inject
    ToggleCommand(@NotNull InventoriesConfig inventoriesConfig) {
        this.inventoriesConfig = inventoriesConfig;
    }

    @Subcommand("toggle")
    @CommandPermission("multiverse.inventories.addshares")
    @CommandCompletion("@sharables:scope=optional")
    @Syntax("<share-name>")
    @Description("Toggles the usage of optional sharables")
    void onToggleCommand(
            @NotNull MVCommandIssuer issuer,

            @Single
            @Syntax("<share-name>")
            @Description("Share to toggle")
            @NotNull Sharable<?> sharable
    ) {
        Shares optionalShares = inventoriesConfig.getActiveOptionalShares();
        if (!sharable.isOptional()) {
            issuer.sendError(MVInvi18n.TOGGLE_NOOPTIONALSHARES, replace("{share}").with(sharable));
            return;
        }
        if (optionalShares.contains(sharable)) {
            optionalShares.remove(sharable);
            issuer.sendInfo(MVInvi18n.TOGGLE_NOWNOTUSINGOPTIONAL, replace("{share}").with(sharable));
        } else {
            optionalShares.add(sharable);
            issuer.sendInfo(MVInvi18n.TOGGLE_NOWUSINGOPTIONAL, replace("{share}").with(sharable));

            // special tip to our wiki page, hopefully this reduces the number of people asking the
            // same old questions about last location config options on discord.
            if (sharable == Sharables.LAST_LOCATION) {
                issuer.sendInfo(MVInvi18n.TOGGLE_LASTLOCATIONINFO, replace("{url}").with(LAST_LOCATION_CONFIG_URL));
            }
        }
        inventoriesConfig.setActiveOptionalShares(optionalShares);
        inventoriesConfig.save();
    }

    @Service
    private final static class LegacyAlias extends ToggleCommand implements LegacyAliasCommand {
        @Inject
        LegacyAlias(InventoriesConfig inventoriesConfig) {
            super(inventoriesConfig);
        }

        @Override
        @CommandAlias("mvinvtoggle")
        void onToggleCommand(MVCommandIssuer issuer, Sharable<?> sharable) {
            super.onToggleCommand(issuer, sharable);
        }
    }
}
