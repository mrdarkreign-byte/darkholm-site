package com.darkholm.portals;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Set;

/** Writes config.yml on first start and adds any new settings (with their comments) to an existing one,
 *  without touching values already set. Keys under a "free" section are only added when that whole
 *  section is missing, so entries removed by hand stay removed. */
final class ConfigSync {
    private ConfigSync() { }

    static void sync(JavaPlugin pl, String... freeSections) {
        try {
            pl.saveDefaultConfig();
            File f = new File(pl.getDataFolder(), "config.yml");
            InputStream in = pl.getResource("config.yml");
            if (in == null) { pl.reloadConfig(); return; }
            YamlConfiguration def = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
            YamlConfiguration user = YamlConfiguration.loadConfiguration(f);
            Set<String> free = Set.of(freeSections);
            boolean changed = false;
            outer:
            for (String k : def.getKeys(true)) {
                for (String s : free) if (k.startsWith(s + ".") && user.contains(s, true)) continue outer;
                if (!user.contains(k, true)) {
                    if (def.isConfigurationSection(k)) user.createSection(k);
                    else user.set(k, def.get(k));
                    user.setComments(k, def.getComments(k));
                    user.setInlineComments(k, def.getInlineComments(k));
                    changed = true;
                } else if (user.getComments(k).isEmpty() && !def.getComments(k).isEmpty()) {
                    user.setComments(k, def.getComments(k));
                    changed = true;
                }
            }
            if (user.options().getHeader().isEmpty() && !def.options().getHeader().isEmpty()) {
                user.options().setHeader(def.options().getHeader());
                changed = true;
            }
            if (changed) user.save(f);
        } catch (Exception e) {
            pl.getLogger().warning("Could not update config.yml: " + e);
        }
        pl.reloadConfig();
    }

    /** &-colour codes to section signs. */
    static String c(String s) { return s == null ? "" : s.replace('&', '§'); }
}
