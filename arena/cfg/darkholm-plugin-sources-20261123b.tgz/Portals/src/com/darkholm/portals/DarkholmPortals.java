package com.darkholm.portals;

import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

public class DarkholmPortals extends JavaPlugin implements Listener {
    static final String TAG = "dhportal_label";

    static class Portal {
        String target, title, sub, world; int x0, y, z0, w; boolean axisX; int fx, fz; int rgb;
        TextDisplay label; Particle.DustOptions dust;
        boolean contains(int x, int yy, int z) {
            if (yy < y || yy > y + 2) return false;
            if (axisX) return z == z0 && x >= x0 && x < x0 + w;
            return x == x0 && z >= z0 && z < z0 + w;
        }
        double cx() { return axisX ? x0 + w / 2.0 : x0 + 0.5; }
        double cz() { return axisX ? z0 + 0.5 : z0 + w / 2.0; }
    }

    final List<Portal> portals = new ArrayList<>();
    final Map<UUID, Portal> inside = new HashMap<>();
    final Map<UUID, Long> cooldown = new HashMap<>();
    int tick = 0;

    double D(String k, double d) { return getConfig().getDouble(k, d); }
    String M(String k, String d) { return ConfigSync.c(getConfig().getString("messages." + k, d)); }

    @Override public void onEnable() {
        ConfigSync.sync(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        load();
        Bukkit.getScheduler().runTaskTimer(this, this::fx, 20L, Math.max(1L, getConfig().getLong("particles.every-ticks", 10)));
        Bukkit.getScheduler().runTaskTimer(this, this::labels, 40L, 200L);
    }

    @Override public void onDisable() { clearLabels(); }

    void load() {
        clearLabels();
        portals.clear();
        File f = new File(getDataFolder(), "portals.txt");
        try {
            if (!f.exists()) { getDataFolder().mkdirs(); Files.writeString(f.toPath(), "# target|title|subtitle|world|x0|y|z0|axis(X/Z)|width|facing(N/S/E/W)|rgbhex\n", StandardCharsets.UTF_8); }
            for (String line : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] p = line.split("\\|");
                if (p.length < 11) { getLogger().warning("Bad portal line: " + line); continue; }
                Portal o = new Portal();
                o.target = p[0].trim(); o.title = col(p[1]); o.sub = col(p[2]); o.world = p[3].trim();
                o.x0 = Integer.parseInt(p[4].trim()); o.y = Integer.parseInt(p[5].trim()); o.z0 = Integer.parseInt(p[6].trim());
                o.axisX = p[7].trim().equalsIgnoreCase("X"); o.w = Integer.parseInt(p[8].trim());
                switch (p[9].trim().toUpperCase()) { case "N": o.fz = -1; break; case "S": o.fz = 1; break; case "E": o.fx = 1; break; default: o.fx = -1; }
                o.rgb = Integer.parseInt(p[10].trim().replace("#", ""), 16);
                o.dust = new Particle.DustOptions(Color.fromRGB(o.rgb), (float) D("particles.dust-size", 1.2));
                portals.add(o);
            }
        } catch (Exception e) { getLogger().warning("Failed to load portals.txt: " + e); }
        getLogger().info("Loaded " + portals.size() + " portals");
        labels();
    }

    static String col(String s) { return s.trim().replace('&', '§'); }

    void clearLabels() {
        for (World w : Bukkit.getWorlds())
            for (TextDisplay t : w.getEntitiesByClass(TextDisplay.class))
                if (t.getScoreboardTags().contains(TAG)) t.remove();
        for (Portal p : portals) p.label = null;
    }

    void labels() {
        for (Portal p : portals) {
            if (p.label != null && p.label.isValid()) continue;
            World w = Bukkit.getWorld(p.world);
            if (w == null) continue;
            int bx = (int) Math.floor(p.cx()), bz = (int) Math.floor(p.cz());
            if (!w.isChunkLoaded(bx >> 4, bz >> 4)) continue;
            // Flat against the front of the top frame row, facing out of the portal.
            float yaw = (float) Math.toDegrees(Math.atan2(-p.fx, p.fz));
            Location l = new Location(w, p.cx() + p.fx * D("labels.offset-out", 0.56), p.y + D("labels.height", 3.18), p.cz() + p.fz * D("labels.offset-out", 0.56), yaw, 0f);
            p.label = w.spawn(l, TextDisplay.class, t -> {
                t.setText(p.title + (p.sub.isEmpty() ? "" : "\n" + p.sub));
                t.setBillboard(Display.Billboard.FIXED);
                t.setShadowed(true);
                t.setViewRange((float) D("labels.view-range", 0.5));
                t.setPersistent(false);
                t.addScoreboardTag(TAG);
            });
        }
    }

    void fx() {
        tick++;
        for (Portal p : portals) {
            World w = Bukkit.getWorld(p.world);
            if (w == null) continue;
            Location c = new Location(w, p.cx(), p.y + 1.5, p.cz());
            double sx = p.axisX ? p.w * 0.3 : 0.1, sz = p.axisX ? 0.1 : p.w * 0.3;
            for (Player pl : w.getPlayers()) {
                Location l = pl.getLocation();
                if (Math.abs(l.getY() - c.getY()) > 4) continue;
                double vr = D("particles.visible-within", 14);
                if (l.distanceSquared(c) > vr * vr) continue;
                pl.spawnParticle(Particle.PORTAL, c, getConfig().getInt("particles.portal-count", 3), sx, 0.9, sz, 0.3);
                pl.spawnParticle(Particle.DUST, c, 1, sx, 0.9, sz, 0, p.dust);
            }
        }
    }

    @EventHandler public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null) return;
        Player pl = e.getPlayer();
        int x = to.getBlockX(), y = to.getBlockY(), z = to.getBlockZ();
        Portal hit = null;
        for (Portal p : portals)
            if (p.world.equalsIgnoreCase(to.getWorld().getName()) && p.contains(x, y, z)) { hit = p; break; }
        UUID id = pl.getUniqueId();
        if (hit == null) { inside.remove(id); return; }
        if (inside.get(id) == hit) return;
        inside.put(id, hit);
        long now = System.currentTimeMillis();
        Long last = cooldown.get(id);
        if (last != null && now - last < (long) (D("cooldown-seconds", 2) * 1000)) return;
        cooldown.put(id, now);
        if (hit.target.startsWith("warp:")) {
            String name = hit.target.substring(5);
            if (getConfig().getBoolean("block-in-combat", true) && inCombat(pl)) { pl.sendMessage(M("in-combat", "&6✦ &cThou canst not flee through a gate while in combat!")); return; }
            Location dest = warpLoc(name);
            if (dest == null) { pl.performCommand("warp " + name); return; }
            pl.teleport(dest);
            return;
        }
        if (hit.target.startsWith("cmd:")) {
            if (getConfig().getBoolean("block-in-combat", true) && inCombat(pl)) { pl.sendMessage(M("in-combat", "&6✦ &cThou canst not flee through a gate while in combat!")); return; }
            pl.setVelocity(new Vector(hit.fx * D("push.forward", 0.45), D("push.up", 0.15), hit.fz * D("push.forward", 0.45)));
            pl.performCommand(hit.target.substring(4));
            return;
        }
        pl.setVelocity(new Vector(hit.fx * D("push.forward", 0.45), D("push.up", 0.15), hit.fz * D("push.forward", 0.45)));
        pl.performCommand(getConfig().getString("dungeon-command", "em dungeontp {target}").replace("{target}", hit.target));
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) { inside.remove(e.getPlayer().getUniqueId()); cooldown.remove(e.getPlayer().getUniqueId()); }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        load();
        reloadConfig(); s.sendMessage(M("reloaded", "&a[DarkholmPortals] Reloaded {count} portals.").replace("{count}", String.valueOf(portals.size())));
        return true;
    }

    Object combatApi; java.lang.reflect.Method isInCombat; boolean combatTried;
    boolean inCombat(Player p) {
        if (!combatTried) { combatTried = true;
            try { Class<?> c = Class.forName("nl.marido.deluxecombat.api.DeluxeCombatAPI"); combatApi = c.getConstructor().newInstance(); isInCombat = c.getMethod("isInCombat", Player.class); } catch (Throwable t) { isInCombat = null; } }
        if (isInCombat == null) return false;
        try { return (Boolean) isInCombat.invoke(combatApi, p); } catch (Throwable t) { return false; }
    }

    Location warpLoc(String name) {
        File f = new File(getDataFolder().getParentFile(), "Essentials/warps/" + name.toLowerCase() + ".yml");
        if (!f.exists()) return null;
        try {
            Map<String, String> m = new HashMap<>();
            for (String line : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                int i = line.indexOf(':'); if (i < 0) continue;
                m.put(line.substring(0, i).trim(), line.substring(i + 1).trim().replace("'", ""));
            }
            World w = Bukkit.getWorld(m.get("world-name"));
            if (w == null) return null;
            return new Location(w, Double.parseDouble(m.get("x")), Double.parseDouble(m.get("y")), Double.parseDouble(m.get("z")),
                    Float.parseFloat(m.getOrDefault("yaw", "0")), Float.parseFloat(m.getOrDefault("pitch", "0")));
        } catch (Exception e) { getLogger().warning("warp " + name + ": " + e); return null; }
    }
}
