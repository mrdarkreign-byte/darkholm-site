package live.darkholm.spawnroute;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class SpawnRoute extends JavaPlugin implements Listener {
    record Route(List<String> worlds, String command) {}
    final List<Route> routes = new ArrayList<>();
    final Set<String> aliases = new HashSet<>();

    @Override public void onEnable() {
        ConfigSync.sync(this, "routes");
        for (Map<?, ?> m : getConfig().getMapList("routes")) {
            List<String> w = new ArrayList<>();
            Object ws = m.get("worlds");
            if (ws instanceof List<?> l) for (Object o : l) w.add(String.valueOf(o).toLowerCase(Locale.ROOT));
            routes.add(new Route(w, String.valueOf(m.get("command"))));
        }
        for (String a : getConfig().getStringList("aliases")) aliases.add(a.toLowerCase(Locale.ROOT));
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info(routes.size() + " /spawn routes active");
    }

    static boolean match(String pattern, String world) {
        return pattern.endsWith("*") ? world.startsWith(pattern.substring(0, pattern.length() - 1)) : world.equals(pattern);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String msg = e.getMessage().trim();
        if (!msg.startsWith("/")) return;
        String[] parts = msg.substring(1).split("\\s+");
        if (parts.length != 1 || !aliases.contains(parts[0].toLowerCase(Locale.ROOT))) return;
        Player p = e.getPlayer();
        String world = p.getWorld().getName().toLowerCase(Locale.ROOT);
        for (Route r : routes)
            for (String w : r.worlds())
                if (match(w, world)) { e.setMessage("/" + r.command()); return; }
    }

    // Wilderness guide NPCs: right-click (or hit) an entity tagged dh_wild to run /wild
    final Map<UUID, Long> last = new HashMap<>();
    void wild(Player p) {
        long now = System.currentTimeMillis();
        Long l = last.get(p.getUniqueId());
        if (l != null && now - l < (long) (getConfig().getDouble("npc-click-cooldown-seconds", 1.5) * 1000)) return;
        last.put(p.getUniqueId(), now);
        p.performCommand(getConfig().getString("wild-command", "wild"));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onNpc(PlayerInteractEntityEvent e) {
        if (e.getRightClicked().getScoreboardTags().contains(getConfig().getString("npc-tag", "dh_wild"))) { e.setCancelled(true); wild(e.getPlayer()); }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onNpcHit(EntityDamageByEntityEvent e) {
        if (e.getEntity().getScoreboardTags().contains(getConfig().getString("npc-tag", "dh_wild")) && e.getDamager() instanceof Player p) { e.setCancelled(true); wild(p); }
    }
}
