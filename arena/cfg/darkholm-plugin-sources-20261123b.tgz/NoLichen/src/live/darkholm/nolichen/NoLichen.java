package live.darkholm.nolichen;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;

public final class NoLichen extends JavaPlugin implements Listener {
  private final List<BlockData> lichenStates = new ArrayList<>(); private long removed;
  private final ArrayDeque<long[]> queue = new ArrayDeque<>(); // {worldIdx, x, z}
  private final List<World> worlds = new ArrayList<>(); private final Set<Long> queued = new HashSet<>();

  private final Set<String> skipWorlds = new HashSet<>();
  @Override public void onEnable() {
    ConfigSync.sync(this);
    for (String w : getConfig().getStringList("skip-worlds")) skipWorlds.add(w.toLowerCase(Locale.ROOT));
    String[] f = {"north","south","east","west","up","down"};
    for (int m = 0; m < 128; m++) { StringBuilder sb = new StringBuilder("[");
      for (int i = 0; i < 6; i++) sb.append(f[i]).append('=').append((m >> i & 1) == 1).append(',');
      sb.append("waterlogged=").append((m >> 6 & 1) == 1).append(']');
      try { lichenStates.add(Material.GLOW_LICHEN.createBlockData(sb.toString())); } catch (Exception ignored) {} }
    getLogger().info("Tracking " + lichenStates.size() + " glow lichen states");
    Bukkit.getPluginManager().registerEvents(this, this);
    for (World w : Bukkit.getWorlds()) for (Chunk c : w.getLoadedChunks()) enqueue(c);
    // process a few chunks per tick to avoid lag spikes
    Bukkit.getScheduler().runTaskTimer(this, () -> { for (int i = 0, n = getConfig().getInt("chunks-per-tick", 4); i < n && !queue.isEmpty(); i++) process(queue.poll()); }, 20L, 1L);
    Bukkit.getScheduler().runTaskTimer(this, () -> { if (removed > 0) { getLogger().info("Removed " + removed + " glow lichen"); removed = 0; } }, 6000L, 6000L);
  }

  private void enqueue(Chunk c) {
    if (!getConfig().getBoolean("remove-existing", true)) return;
    World w = c.getWorld(); if (skipWorlds.contains(w.getName().toLowerCase(Locale.ROOT))) return; int wi = worlds.indexOf(w); if (wi < 0) { worlds.add(w); wi = worlds.size() - 1; }
    long key = ((long) wi << 56) ^ (((long) c.getX() & 0xFFFFFFFL) << 28) ^ ((long) c.getZ() & 0xFFFFFFFL);
    if (queued.add(key)) queue.add(new long[]{wi, c.getX(), c.getZ(), key});
  }

  private void process(long[] q) {
    queued.remove(q[3]); World w = worlds.get((int) q[0]);
    if (!w.isChunkLoaded((int) q[1], (int) q[2])) return;
    Chunk c = w.getChunkAt((int) q[1], (int) q[2]);
    boolean has = false; for (BlockData d : lichenStates) if (c.contains(d)) { has = true; break; }
    if (!has) return;
    int minY = w.getMinHeight(), maxY = w.getMaxHeight();
    for (int y = minY; y < maxY; y++) for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
      Block b = c.getBlock(x, y, z);
      if (b.getType() == Material.GLOW_LICHEN) { clear(b); removed++; }
    }
  }

  private static void clear(Block b) {
    BlockData d = b.getBlockData();
    boolean wet = d instanceof Waterlogged wl && wl.isWaterlogged();
    b.setType(wet ? Material.WATER : Material.AIR, false);
  }

  @EventHandler public void onLoad(ChunkLoadEvent e) { enqueue(e.getChunk()); }

  @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
  public void onPlace(BlockPlaceEvent e) {
    if (getConfig().getBoolean("block-placing", true) && e.getBlockPlaced().getType() == Material.GLOW_LICHEN) { e.setCancelled(true); String m = getConfig().getString("messages.no-place", "&7Glow lichen is disabled on Darkholm."); if (!m.isEmpty()) e.getPlayer().sendMessage(ConfigSync.c(m)); }
  }

  @EventHandler(ignoreCancelled = true) public void onSpread(BlockSpreadEvent e) { if (getConfig().getBoolean("block-growth", true) && e.getNewState().getType() == Material.GLOW_LICHEN) e.setCancelled(true); }
  @EventHandler(ignoreCancelled = true) public void onForm(BlockFormEvent e) { if (getConfig().getBoolean("block-growth", true) && e.getNewState().getType() == Material.GLOW_LICHEN) e.setCancelled(true); }
  @EventHandler(ignoreCancelled = true) public void onGrow(BlockGrowEvent e) { if (getConfig().getBoolean("block-growth", true) && e.getNewState().getType() == Material.GLOW_LICHEN) e.setCancelled(true); }
  @EventHandler(ignoreCancelled = true) public void onFert(BlockFertilizeEvent e) { if (getConfig().getBoolean("block-growth", true)) e.getBlocks().removeIf(s -> s.getType() == Material.GLOW_LICHEN); }
}
