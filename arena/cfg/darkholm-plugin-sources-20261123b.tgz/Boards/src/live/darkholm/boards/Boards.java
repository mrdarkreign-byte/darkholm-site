package live.darkholm.boards;

import com.sun.net.httpserver.HttpServer;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.Executors;

/** Leaderboards: mcMMO power level and Factions, shown on text panels in the world and served as JSON for the website. */
public final class Boards extends JavaPlugin {
    static final String TAG = "dh_board";
    private final List<TextDisplay> shown = new ArrayList<>();
    private volatile List<String[]> mcmmo = new ArrayList<>();      // name, power
    private volatile List<String[]> factions = new ArrayList<>();   // name, members, power, max, land
    private volatile String json = "{}";
    private HttpServer http;

    @Override public void onEnable() {
        ConfigSync.sync(this, "boards");
        for (World w : Bukkit.getWorlds()) for (TextDisplay t : w.getEntitiesByClass(TextDisplay.class)) if (t.getScoreboardTags().contains(TAG)) t.remove();
        long every = Math.max(1, getConfig().getLong("update-minutes", 5)) * 1200L;
        Bukkit.getScheduler().runTaskTimer(this, this::refresh, 60L, every);
        startWeb();
    }

    @Override public void onDisable() {
        clear();
        if (http != null) { http.stop(0); http = null; }
    }

    private void clear() {
        for (TextDisplay t : shown) if (t.isValid()) t.remove();
        shown.clear();
        // persistent panels left in loaded chunks (after a crash or chunk reload)
        for (World w : Bukkit.getWorlds()) for (TextDisplay t : w.getEntitiesByClass(TextDisplay.class)) if (t.getScoreboardTags().contains(TAG)) t.remove();
    }

    // ---------- data ----------
    private void refresh() {
        factions = readFactions();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            List<String[]> m = readMcmmo();
            Bukkit.getScheduler().runTask(this, () -> { mcmmo = m; buildJson(); draw(); });
        });
    }

    private List<String[]> readMcmmo() {
        List<String[]> out = new ArrayList<>();
        int n = getConfig().getInt("mcmmo.count", 10);
        try {
            Class<?> mc = Class.forName("com.gmail.nossr50.mcMMO", true, Bukkit.getPluginManager().getPlugin("mcMMO").getClass().getClassLoader());
            Object db = mc.getMethod("getDatabaseManager").invoke(null);
            Class<?> skill = Class.forName("com.gmail.nossr50.datatypes.skills.PrimarySkillType", true, mc.getClassLoader());
            Method read = db.getClass().getMethod("readLeaderboard", skill, int.class, int.class);
            List<?> rows = (List<?>) read.invoke(db, null, 1, n + getConfig().getStringList("hidden-players").size());
            for (Object r : rows) {
                String name = String.valueOf(r.getClass().getMethod("playerName").invoke(r));
                if (hidden(name)) continue;
                out.add(new String[]{name, String.valueOf(r.getClass().getMethod("value").invoke(r))});
                if (out.size() >= n) break;
            }
        } catch (Throwable t) { getLogger().warning("mcMMO leaderboard: " + (t.getCause() != null ? t.getCause() : t)); return mcmmo; }
        return out;
    }

    private boolean hidden(String name) {
        for (String h : getConfig().getStringList("hidden-players")) if (h.equalsIgnoreCase(name)) return true;
        return false;
    }

    private List<String[]> readFactions() {
        List<String[]> out = new ArrayList<>();
        try {
            ClassLoader cl = Bukkit.getPluginManager().getPlugin("Factions").getClass().getClassLoader();
            Class<?> fc = Class.forName("com.massivecraft.factions.entity.FactionColl", true, cl);
            Object coll = fc.getMethod("get").invoke(null);
            Collection<?> all = (Collection<?>) coll.getClass().getMethod("getAll").invoke(coll);
            List<Object[]> rows = new ArrayList<>();
            for (Object f : all) {
                Class<?> c = f.getClass();
                if (!(Boolean) c.getMethod("isNormal").invoke(f)) continue;
                String name = String.valueOf(c.getMethod("getName").invoke(f));
                int members = ((List<?>) c.getMethod("getMPlayers").invoke(f)).size();
                double power = (Double) c.getMethod("getPower").invoke(f);
                double max = (Double) c.getMethod("getPowerMax").invoke(f);
                int land = (Integer) c.getMethod("getLandCount").invoke(f);
                rows.add(new Object[]{name, members, power, max, land});
            }
            String sort = getConfig().getString("factions.sort-by", "power");
            rows.sort((a, b) -> switch (sort) {
                case "members" -> Integer.compare((Integer) b[1], (Integer) a[1]);
                case "land" -> Integer.compare((Integer) b[4], (Integer) a[4]);
                default -> Double.compare((Double) b[2], (Double) a[2]);
            });
            int n = getConfig().getInt("factions.count", 10);
            for (Object[] r : rows.subList(0, Math.min(n, rows.size())))
                out.add(new String[]{(String) r[0], String.valueOf(r[1]), String.valueOf(Math.round((Double) r[2])), String.valueOf(Math.round((Double) r[3])), String.valueOf(r[4])});
        } catch (Throwable t) { getLogger().warning("Factions leaderboard: " + (t.getCause() != null ? t.getCause() : t)); return factions; }
        return out;
    }

    // ---------- in-world panels ----------
    private String text(String type) {
        String k = type.equals("mcmmo") ? "mcmmo" : "factions";
        StringBuilder sb = new StringBuilder();
        for (String h : getConfig().getStringList(k + ".title")) sb.append(ConfigSync.c(h)).append('\n');
        List<String[]> rows = type.equals("mcmmo") ? mcmmo : factions;
        if (rows.isEmpty()) sb.append(ConfigSync.c(getConfig().getString(k + ".empty", "&7No one yet. Be the first!"))).append('\n');
        int i = 0;
        for (String[] r : rows) {
            i++;
            String line = getConfig().getString(k + ".line", "");
            String place = i <= 3 ? getConfig().getString("place-colours." + i, "&e") : getConfig().getString("place-colours.other", "&7");
            line = line.replace("{place}", String.valueOf(i)).replace("{place-colour}", place).replace("{name}", r[0]);
            if (type.equals("mcmmo")) line = line.replace("{power}", r[1]);
            else line = line.replace("{members}", r[1]).replace("{power}", r[2]).replace("{max}", r[3]).replace("{land}", r[4]);
            sb.append(ConfigSync.c(line)).append('\n');
        }
        for (String f : getConfig().getStringList(k + ".footer")) sb.append(ConfigSync.c(f)).append('\n');
        return sb.toString().replaceAll("\n+$", "");
    }

    private void draw() {
        clear();
        ConfigurationSection bs = getConfig().getConfigurationSection("boards");
        if (bs == null) return;
        for (String id : bs.getKeys(false)) {
            ConfigurationSection b = bs.getConfigurationSection(id);
            if (b == null || !b.getBoolean("enabled", true)) continue;
            World w = Bukkit.getWorld(b.getString("world", "Darkholm"));
            if (w == null) continue;
            Location l = new Location(w, b.getDouble("x"), b.getDouble("y"), b.getDouble("z"), (float) b.getDouble("yaw", 0), 0f);
            if (!w.isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4)) w.getChunkAt(l);
            String txt = text(b.getString("type", "mcmmo"));
            float scale = (float) b.getDouble("scale", 1.0);
            TextDisplay t = w.spawn(l, TextDisplay.class, d -> {
                d.setText(txt);
                d.setBillboard(Display.Billboard.FIXED);
                d.setShadowed(b.getBoolean("shadow", true));
                d.setLineWidth(b.getInt("line-width", 260));
                d.setAlignment(TextDisplay.TextAlignment.CENTER);
                String bg = b.getString("background", "88000000");
                try { d.setBackgroundColor(Color.fromARGB((int) Long.parseLong(bg.replace("#", ""), 16))); } catch (Exception ignored) { }
                if (scale != 1f) try {
                    Object tr = d.getClass().getMethod("getTransformation").invoke(d);
                    Object sc = tr.getClass().getMethod("getScale").invoke(tr);
                    sc.getClass().getMethod("set", float.class, float.class, float.class).invoke(sc, scale, scale, scale);
                    d.getClass().getMethod("setTransformation", tr.getClass()).invoke(d, tr);
                } catch (Throwable ignored) { }
                d.setViewRange((float) b.getDouble("view-range", 1.0));
                d.setPersistent(true);
                d.addScoreboardTag(TAG);
            });
            shown.add(t);
        }
    }

    // ---------- website JSON ----------
    private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replaceAll("§.", ""); }

    private void buildJson() {
        StringBuilder sb = new StringBuilder("{\"updated\":\"").append(Instant.now()).append("\",\"mcmmo\":[");
        for (int i = 0; i < mcmmo.size(); i++) { String[] r = mcmmo.get(i); if (i > 0) sb.append(','); sb.append("{\"name\":\"").append(esc(r[0])).append("\",\"power\":").append(r[1]).append('}'); }
        sb.append("],\"factions\":[");
        for (int i = 0; i < factions.size(); i++) { String[] r = factions.get(i); if (i > 0) sb.append(',');
            sb.append("{\"name\":\"").append(esc(r[0])).append("\",\"members\":").append(r[1]).append(",\"power\":").append(r[2]).append(",\"max\":").append(r[3]).append(",\"land\":").append(r[4]).append('}'); }
        sb.append("]}");
        json = sb.toString();
    }

    private void startWeb() {
        if (!getConfig().getBoolean("web.enabled", true)) return;
        int port = getConfig().getInt("web.port", 8004);
        try {
            http = HttpServer.create(new InetSocketAddress(port), 0);
            http.createContext("/tops.json", ex -> {
                byte[] b = json.getBytes(StandardCharsets.UTF_8);
                ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
                ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
                ex.getResponseHeaders().add("Cache-Control", "max-age=60");
                ex.sendResponseHeaders(200, b.length);
                try (OutputStream o = ex.getResponseBody()) { o.write(b); }
            });
            http.setExecutor(Executors.newSingleThreadExecutor());
            http.start();
            getLogger().info("Leaderboard JSON at http://<server>:" + port + "/tops.json");
        } catch (Exception e) { getLogger().warning("Could not start the leaderboard web page on port " + port + ": " + e); http = null; }
    }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("refresh")) { refresh(); s.sendMessage("§aLeaderboards refreshing."); return true; }
        if (a.length > 0 && a[0].equalsIgnoreCase("here") && s instanceof Player p && a.length > 1) {
            ConfigurationSection b = getConfig().getConfigurationSection("boards." + a[1]);
            if (b == null) { s.sendMessage("§cNo board called " + a[1]); return true; }
            Location loc = p.getLocation();
            b.set("world", loc.getWorld().getName()); b.set("x", Math.round(loc.getX() * 10) / 10.0); b.set("y", Math.round(loc.getY() * 10) / 10.0 + 1.5);
            b.set("z", Math.round(loc.getZ() * 10) / 10.0); b.set("yaw", Math.round((loc.getYaw() + 180) / 90f) * 90f % 360);
            saveConfig(); draw(); s.sendMessage("§aMoved board " + a[1] + " here, facing you."); return true;
        }
        s.sendMessage("§7/boards refresh  §8|  §7/boards here <board>  (stand where it should be, facing the wall)");
        return true;
    }
}
