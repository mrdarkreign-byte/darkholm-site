package live.darkholm.daily;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Daily chests. Right-click a daily chest once per day for exactly one spin of the ExcellentCrates "daily" crate
 * (opened by console command, so no key and no batch-amount menu). Left-click previews the rewards.
 * Chest locations live in config.yml and are managed in game with /dailychest add|remove|list.
 * The day rolls over at midnight Pacific, in step with the server's daily restart.
 */
public final class Daily extends JavaPlugin implements Listener {
    private static ZoneId ZONE = ZoneId.of("America/Los_Angeles");
    private static final String TAG = "dh_daily";

    private final List<String> chests = new ArrayList<>();   // "world,x,y,z"
    private final Map<UUID, List<TextDisplay>> shown = new HashMap<>();
    private File dataFile;
    private YamlConfiguration data;
    private String crate;
    private String lastDay;

    @Override public void onEnable() {
        loadSettings();
        dataFile = new File(getDataFolder(), "streaks.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        Bukkit.getPluginManager().registerEvents(this, this);
        // remove labels left behind by an earlier crash or version
        for (World w : Bukkit.getWorlds())
            for (TextDisplay t : w.getEntitiesByClass(TextDisplay.class))
                if (t.getScoreboardTags().contains(TAG) || t.getScoreboardTags().contains("dh_private")) t.remove();
        lastDay = today();
        for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
        // at the day rollover, relabel every chest so "Claimed today" goes away
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            String d = today();
            if (!d.equals(lastDay)) { lastDay = d; for (Player p : Bukkit.getOnlinePlayers()) refresh(p); }
        }, 1200L, 1200L);
        getLogger().info("Daily chests: " + chests.size() + " location(s), crate '" + crate + "'.");
    }

    @Override public void onDisable() {
        for (UUID id : new ArrayList<>(shown.keySet())) clearLabels(id);
        save();
    }

    private void loadSettings() {
        ConfigSync.sync(this);
        crate = getConfig().getString("crate", "daily");
        try { ZONE = ZoneId.of(getConfig().getString("timezone", "America/Los_Angeles")); } catch (Exception ex) { getLogger().warning("Bad timezone, using America/Los_Angeles"); ZONE = ZoneId.of("America/Los_Angeles"); }
        chests.clear();
        chests.addAll(getConfig().getStringList("chests"));
    }

    private String m(String k, String d) { return ConfigSync.c(getConfig().getString(k, d)).replace("\\n", "\n"); }
    private String days(int n) { return n + (n == 1 ? m("words.day", " day") : m("words.days", " days")); }

    static String today() { return LocalDate.now(ZONE).toString(); }
    static String yesterday() { return LocalDate.now(ZONE).minusDays(1).toString(); }

    private static String key(Block b) { return b.getWorld().getName() + "," + b.getX() + "," + b.getY() + "," + b.getZ(); }

    private boolean isChest(Block b) { return b != null && chests.contains(key(b)); }

    private boolean claimed(UUID id) { return today().equals(data.getString(id + ".last")); }

    private int streakNow(UUID id) {
        String last = data.getString(id + ".last");
        if (today().equals(last) || yesterday().equals(last)) return data.getInt(id + ".streak");
        return 0;
    }

    private String text(Player p) {
        int s = streakNow(p.getUniqueId());
        String status = claimed(p.getUniqueId())
                ? m("label.claimed", "&aClaimed today &7- resets at midnight")
                : m("label.unclaimed", "&fRight-click to claim\n&8Left-click to preview");
        return m("label.title", "&6&l✦ Daily Chest ✦\n&7Your streak: &e{streak}").replace("{streak}", days(s)) + "\n" + status;
    }

    private void clearLabels(UUID id) {
        List<TextDisplay> l = shown.remove(id);
        if (l != null) for (TextDisplay t : l) if (t.isValid()) t.remove();
    }

    /** Each player sees their own label (streak and claim state) over every daily chest in their world. */
    private void refresh(Player p) {
        clearLabels(p.getUniqueId());
        if (!p.isOnline()) return;
        List<TextDisplay> list = new ArrayList<>();
        String txt = text(p);
        for (String c : chests) {
            String[] a = c.split(",");
            if (a.length != 4 || !a[0].equals(p.getWorld().getName())) continue;
            World w = p.getWorld();
            Location loc = new Location(w, Integer.parseInt(a[1]) + 0.5, Integer.parseInt(a[2]) + getConfig().getDouble("label.height", 1.35), Integer.parseInt(a[3]) + 0.5);
            if (!w.isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) continue;
            TextDisplay t = w.spawn(loc, TextDisplay.class, d -> {
                d.setText(txt);
                d.setBillboard(Display.Billboard.CENTER);
                d.setShadowed(true);
                d.setLineWidth(200);
                d.setViewRange(0.25f);
                d.setPersistent(false);
                d.setVisibleByDefault(false);
                d.addScoreboardTag(TAG);
            });
            p.showEntity(this, t);
            list.add(t);
        }
        shown.put(p.getUniqueId(), list);
    }

    private void save() {
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("save failed: " + e.getMessage()); }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { Player p = e.getPlayer(); Bukkit.getScheduler().runTaskLater(this, () -> refresh(p), 20L); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { clearLabels(e.getPlayer().getUniqueId()); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { Player p = e.getPlayer(); Bukkit.getScheduler().runTaskLater(this, () -> refresh(p), 10L); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(PlayerInteractEvent e) {
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_BLOCK && a != Action.LEFT_CLICK_BLOCK) return;
        if (!isChest(e.getClickedBlock())) return;
        e.setCancelled(true);                              // never open the chest's own inventory
        if (e.getHand() != EquipmentSlot.HAND) return;     // one action per click
        Player p = e.getPlayer();
        if (a == Action.LEFT_CLICK_BLOCK) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "crate preview " + crate + " " + p.getName());
            return;
        }
        UUID id = p.getUniqueId();
        if (claimed(id)) { p.sendMessage(m("messages.already-claimed", "&6✦ &7Thou hast claimed today's chest. It resets at midnight.")); return; }
        int streak = (yesterday().equals(data.getString(id + ".last")) ? data.getInt(id + ".streak") : 0) + 1;
        data.set(id + ".last", today());
        data.set(id + ".streak", streak);
        data.set(id + ".name", p.getName());
        save();
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "crate open " + crate + " " + p.getName());
        p.sendMessage(m("messages.claimed", "&6✦ &7Daily chest claimed! Streak: &e{streak}&7. Come back tomorrow.").replace("{streak}", days(streak)));
        Bukkit.getScheduler().runTask(this, () -> refresh(p));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (isChest(e.getBlock())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(m("messages.no-break", "&cThat's a daily chest. Use /dailychest remove while looking at it first."));
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        String sub = args.length > 0 ? args[0].toLowerCase() : "list";
        switch (sub) {
            case "reload" -> { loadSettings(); for (Player p : Bukkit.getOnlinePlayers()) refresh(p); s.sendMessage("§aDaily chests reloaded: " + chests.size()); }
            case "list" -> { s.sendMessage("§6Daily chests (" + chests.size() + "):"); for (String c : chests) s.sendMessage("§7- " + c); }
            case "add", "remove" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Run this in game while looking at a chest."); return true; }
                Block b = p.getTargetBlockExact(6);
                if (b == null) { p.sendMessage("§cLook at a chest within 6 blocks."); return true; }
                String k = key(b);
                if (sub.equals("add")) {
                    if (chests.contains(k)) { p.sendMessage("§eAlready a daily chest."); return true; }
                    chests.add(k);
                } else if (!chests.remove(k)) { p.sendMessage("§eNot a daily chest."); return true; }
                getConfig().set("chests", chests);
                saveConfig();
                for (Player o : Bukkit.getOnlinePlayers()) refresh(o);
                p.sendMessage("§a" + (sub.equals("add") ? "Added" : "Removed") + " daily chest at " + k);
            }
            default -> s.sendMessage(ChatColor.GRAY + "/" + label + " <add|remove|list|reload>");
        }
        return true;
    }
}
