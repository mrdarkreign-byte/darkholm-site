package com.darkholm.nowands;

import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.*;

public class DarkholmNoWands extends JavaPlugin implements Listener {
    final Set<String> worlds = new HashSet<>();
    String msg;
    Method isMagic;
    final Map<UUID, Long> lastMsg = new HashMap<>();
    long removed;

    @Override public void onEnable() {
        ConfigSync.sync(this);
        for (String w : getConfig().getStringList("worlds")) worlds.add(w.toLowerCase(Locale.ROOT));
        msg = ChatColor.translateAlternateColorCodes('&', getConfig().getString("message", ""));
        try {
            Class<?> c = Class.forName("com.magmaguy.elitemobs.skills.WeaponIdentityResolver", true,
                    getServer().getPluginManager().getPlugin("EliteMobs").getClass().getClassLoader());
            isMagic = c.getMethod("isMagicWeapon", ItemStack.class);
        } catch (Throwable t) {
            getLogger().severe("Could not hook EliteMobs WeaponIdentityResolver.isMagicWeapon: " + t);
        }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("Blocking wands and staves in " + worlds + (isMagic == null ? " (INACTIVE: no EliteMobs hook)" : ""));
    }

    boolean blocked(World w) { return w != null && worlds.contains(w.getName().toLowerCase(Locale.ROOT)); }

    boolean magic(ItemStack i) {
        if (i == null || isMagic == null || i.getType().isAir()) return false;
        try { return (Boolean) isMagic.invoke(null, i); } catch (Throwable t) { return false; }
    }

    void tell(Player p) {
        long now = System.currentTimeMillis();
        Long l = lastMsg.get(p.getUniqueId());
        if (l == null || now - l > getConfig().getLong("message-cooldown-seconds", 4) * 1000L) { lastMsg.put(p.getUniqueId(), now); p.sendMessage(msg); }
    }

    // Wand/staff loot dropped in the Factions worlds never appears
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpawn(ItemSpawnEvent e) {
        if (getConfig().getBoolean("remove-drops", true) && blocked(e.getLocation().getWorld()) && magic(e.getEntity().getItemStack())) {
            e.setCancelled(true);
            if (++removed % 25 == 1)
                getLogger().info("Removed a wand/staff drop in " + e.getLocation().getWorld().getName() + " (total " + removed + ")");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (getConfig().getBoolean("block-pickup", true) && blocked(e.getEntity().getWorld()) && magic(e.getItem().getItemStack())) { e.setCancelled(true); e.getItem().remove(); }
    }

    // Wands and staves cannot be used in the Factions worlds
    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (getConfig().getBoolean("block-use", true) && blocked(p.getWorld()) && magic(e.getItem())) {
            e.setCancelled(true); e.setUseItemInHand(Event.Result.DENY); e.setUseInteractedBlock(Event.Result.DENY); tell(p);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        Player p = e.getPlayer();
        if (getConfig().getBoolean("block-use", true) && blocked(p.getWorld()) && magic(p.getInventory().getItem(e.getHand()))) { e.setCancelled(true); tell(p); }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (getConfig().getBoolean("block-use", true) && e.getDamager() instanceof Player p && blocked(p.getWorld()) && magic(p.getInventory().getItemInMainHand())) { e.setCancelled(true); tell(p); }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onShoot(EntityShootBowEvent e) {
        if (getConfig().getBoolean("block-use", true) && e.getEntity() instanceof Player p && blocked(p.getWorld()) && magic(e.getBow())) { e.setCancelled(true); tell(p); }
    }
}
