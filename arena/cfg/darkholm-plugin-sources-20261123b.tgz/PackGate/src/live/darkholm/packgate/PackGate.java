package live.darkholm.packgate;

import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredListener;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Sends the merged ResourcePackManager pack once per session: on join (send-on-join) or on entering an EliteMobs world.
 * The pack keeps one id, URL and hash, so clients load it from their cache instead of downloading it again.
 * On enable it unregisters ResourcePackManager's join-time listeners so it no longer prompts on login.
 */
public final class PackGate extends JavaPlugin implements Listener {
    private static final UUID PACK_ID = UUID.nameUUIDFromBytes("darkholm-rspm".getBytes());
    private final List<Pattern> worlds = new ArrayList<>();
    private final Set<UUID> sent = ConcurrentHashMap.newKeySet();
    private volatile byte[] hash;
    private final Set<String> logged = ConcurrentHashMap.newKeySet();
    private String url;

    @Override public void onEnable() {
        ConfigSync.sync(this);
        url = getConfig().getString("pack-url");
        for (String w : getConfig().getStringList("pack-worlds"))
            worlds.add(Pattern.compile(w.toLowerCase(Locale.ROOT).replace(".", "\\.").replace("*", ".*")));
        getServer().getPluginManager().registerEvents(this, this);
        // Wait for every plugin to finish enabling before removing ResourcePackManager's join listeners.
        // ResourcePackManager registers its pack sender once the pack is live, so keep checking.
        Bukkit.getScheduler().runTaskTimer(this, this::muteRspm, 1L, 200L);
        long every = Math.max(1, getConfig().getLong("rehash-minutes", 10)) * 1200L;
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::rehash, 200L, every);
        getLogger().info((getConfig().getBoolean("send-on-join", true) ? "Pack sent once on join" : "Pack only in worlds matching " + getConfig().getStringList("pack-worlds")) + " from " + url);
    }

    private void muteRspm() {
        Plugin rspm = Bukkit.getPluginManager().getPlugin(getConfig().getString("pack-plugin", "ResourcePackManager"));
        if (rspm == null) { getLogger().warning("ResourcePackManager not found; nothing to mute."); return; }
        int removed = 0;
        java.util.Set<String> seenNow = new java.util.HashSet<>();
        for (HandlerList hl : HandlerList.getHandlerLists()) {
            for (RegisteredListener rl : hl.getRegisteredListeners()) {
                if (rl.getPlugin() != rspm) continue;
                String ev = eventName(rl);
                String key = rl.getListener().getClass().getName() + " " + ev;
                if (logged.add(key)) getLogger().info("ResourcePackManager listens to " + ev + " via " + rl.getListener().getClass().getName());
                if (ev.matches("(?i).*(join|login|configur|spawnlocation).*")) {
                    hl.unregister(rl);
                    removed++;
                    getLogger().info("  -> muted (" + ev + ")");
                }
            }
        }
        if (removed > 0) getLogger().info("Muted " + removed + " ResourcePackManager join listener(s).");
    }

    private static String eventName(RegisteredListener rl) {
        for (var m : rl.getListener().getClass().getDeclaredMethods()) {
            EventHandler h = m.getAnnotation(EventHandler.class);
            if (h != null && m.getParameterCount() == 1 && Event.class.isAssignableFrom(m.getParameterTypes()[0])
                    && m.getParameterTypes()[0].getSimpleName().length() > 0) {
                // a listener class can hold several handlers; report all of them
            }
        }
        StringBuilder sb = new StringBuilder();
        for (var m : rl.getListener().getClass().getDeclaredMethods())
            if (m.getAnnotation(EventHandler.class) != null && m.getParameterCount() == 1) sb.append(m.getParameterTypes()[0].getSimpleName()).append(' ');
        return sb.toString().trim();
    }

    private void rehash() {
        try {
            HttpClient c = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).followRedirects(HttpClient.Redirect.NORMAL).build();
            HttpResponse<InputStream> r = c.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(60)).build(), HttpResponse.BodyHandlers.ofInputStream());
            if (r.statusCode() != 200) { getLogger().warning("Pack download returned " + r.statusCode()); return; }
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            try (InputStream in = r.body()) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) > 0) md.update(b, 0, n); }
            byte[] h = md.digest();
            if (hash == null || !java.util.Arrays.equals(h, hash)) {
                hash = h; sent.clear(); getLogger().info("Pack hash " + java.util.HexFormat.of().formatHex(h));
                // players who joined before the hash was ready (or before a pack change) get it now
                Bukkit.getScheduler().runTask(this, () -> { for (Player p : Bukkit.getOnlinePlayers()) check(p); });
            }
        } catch (Exception ex) { getLogger().warning("Could not hash pack: " + ex.getMessage()); }
    }

    private boolean packWorld(World w) {
        String n = w.getName().toLowerCase(Locale.ROOT);
        for (Pattern p : worlds) if (p.matcher(n).matches()) return true;
        return false;
    }

    private void check(Player p) {
        if (hash == null || url == null) return;
        if (getConfig().getBoolean("send-on-join", true) || packWorld(p.getWorld())) {
            if (sent.add(p.getUniqueId()))
                p.setResourcePack(PACK_ID, url, hash, Component.text(getConfig().getString("prompt", "This realm uses the Darkholm resource pack for its creatures and gear.")), getConfig().getBoolean("force", false));
        } else if (getConfig().getBoolean("remove-on-leave", false) && sent.remove(p.getUniqueId())) {
            p.removeResourcePack(PACK_ID);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR) public void onJoin(PlayerJoinEvent e) { Bukkit.getScheduler().runTaskLater(this, () -> check(e.getPlayer()), Math.max(1L, getConfig().getLong("join-delay-ticks", 40))); }
    @EventHandler(priority = EventPriority.MONITOR) public void onWorld(PlayerChangedWorldEvent e) { check(e.getPlayer()); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { sent.remove(e.getPlayer().getUniqueId()); }
}
