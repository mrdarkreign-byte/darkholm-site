#!/bin/bash
# usage: build.sh <Project>  -> builds <Project>/<jarname>-<version>.jar
set -e
J=/tmp/claude-0/-home-claude/1626b650-5842-52ea-a59e-293e6e4fcbea/scratchpad/jdk/jdk-25.0.5+8/bin
P=/home/claude/plugins/$1; cd $P
CP="/home/claude/daily/lib/*:/home/claude/arena/stubout"
if [ -d cp ]; then for x in cp/*; do CP="$CP:$x"; done; CP="$CP:cp/*"; fi
rm -rf build && mkdir build
$J/javac --release 21 -encoding UTF-8 -nowarn -cp "$CP" -d build $(find src -name '*.java') 2>&1 | grep -v -e JAVA_TOOL -e '^Note:' || true
ls build/* >/dev/null
cp res/* build/
N=$(grep '^name:' res/plugin.yml | awk '{print $2}'); V=$(grep '^version:' res/plugin.yml | awk '{print $2}')
rm -f *.jar; (cd build && $J/jar cf ../$N-$V.jar . 2>&1 | grep -v JAVA_TOOL || true)
echo "$P/$N-$V.jar $(stat -c %s $N-$V.jar)"
