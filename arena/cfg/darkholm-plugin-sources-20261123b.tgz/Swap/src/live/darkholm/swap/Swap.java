package live.darkholm.swap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class Swap extends JavaPlugin implements TabExecutor {

    private File swapDir, oldDir;

    @Override
    public void onEnable() {
        ConfigSync.sync(this);
        swapDir = new File(getDataFolder().getParentFile(), getConfig().getString("swap-folder", "swap"));
        oldDir = new File(swapDir, "old");
        swapDir.mkdirs();
        oldDir.mkdirs();
        PluginCommand c = getCommand("dh");
        if (c != null) { c.setExecutor(this); c.setTabCompleter(this); }
    }

    private void msg(CommandSender s, String m) {
        s.sendMessage(ConfigSync.c(getConfig().getString("prefix", "&6[Darkholm] &7")) + m);
        if (s instanceof Player) getLogger().info(ChatColor.stripColor(m));
    }

    private boolean ours(String n) { return n.startsWith(getConfig().getString("plugin-prefix", "Darkholm")) && !n.equals(getName()); }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            msg(s, "/dh reload <plugin|all> - re-read config and restart the plugin");
            msg(s, "/dh swap <plugin> - load the new jar from plugins/swap");
            msg(s, "/dh load <file.jar> - load a new plugin from plugins/swap");
            msg(s, "/dh list - Darkholm plugins and versions");
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        try {
            switch (sub) {
                case "list" -> {
                    List<String> l = new ArrayList<>();
                    for (Plugin p : Bukkit.getPluginManager().getPlugins())
                        if (p.getName().startsWith("Darkholm"))
                            l.add((p.isEnabled() ? ChatColor.GREEN : ChatColor.RED) + p.getName() + " " + p.getPluginMeta().getVersion());
                    Collections.sort(l, Comparator.comparing(ChatColor::stripColor));
                    msg(s, l.size() + " Darkholm plugins: " + String.join(ChatColor.GRAY + ", ", l));
                    File[] js = swapDir.listFiles((d, n) -> n.endsWith(".jar"));
                    if (js != null && js.length > 0) {
                        List<String> w = new ArrayList<>();
                        for (File f : js) w.add(f.getName());
                        msg(s, "Waiting in plugins/swap: " + String.join(", ", w));
                    }
                }
                case "reload" -> {
                    if (a.length < 2) { msg(s, "/dh reload <plugin|all>"); return true; }
                    if (a[1].equalsIgnoreCase("all")) {
                        int n = 0;
                        for (Plugin p : new ArrayList<>(Arrays.asList(Bukkit.getPluginManager().getPlugins())))
                            if (ours(p.getName()) && p.isEnabled()) { reload(p); n++; }
                        msg(s, "Reloaded " + n + " Darkholm plugins.");
                    } else {
                        Plugin p = find(a[1]);
                        if (p == null) { msg(s, "No Darkholm plugin named " + a[1]); return true; }
                        reload(p);
                        msg(s, "Reloaded " + p.getName() + " " + p.getPluginMeta().getVersion());
                    }
                }
                case "swap" -> {
                    if (a.length < 2) { msg(s, "/dh swap <plugin>"); return true; }
                    Plugin p = find(a[1]);
                    if (p == null) { msg(s, "No Darkholm plugin named " + a[1]); return true; }
                    File nj = jarFor(p.getName());
                    if (nj == null) { msg(s, "No jar for " + p.getName() + " in plugins/swap"); return true; }
                    String oldV = p.getPluginMeta().getVersion();
                    Plugin np = swap(p, nj);
                    msg(s, "Swapped " + np.getName() + " " + oldV + " -> " + np.getPluginMeta().getVersion()
                            + (np.isEnabled() ? "" : ChatColor.RED + " (NOT enabled, check console)"));
                }
                case "load" -> {
                    if (a.length < 2) { msg(s, "/dh load <file.jar>"); return true; }
                    File f = new File(swapDir, a[1].endsWith(".jar") ? a[1] : a[1] + ".jar");
                    if (!f.isFile()) { msg(s, "Not found: plugins/swap/" + f.getName()); return true; }
                    String n = metaName(f);
                    if (n == null || !n.startsWith(getConfig().getString("plugin-prefix", "Darkholm"))) { msg(s, "Only Darkholm plugins can be loaded."); return true; }
                    if (Bukkit.getPluginManager().getPlugin(n) != null) { msg(s, n + " is already loaded, use /dh swap " + n); return true; }
                    Plugin np = loadNew(f, null);
                    msg(s, "Loaded " + np.getName() + " " + np.getPluginMeta().getVersion()
                            + (np.isEnabled() ? "" : ChatColor.RED + " (NOT enabled, check console)"));
                }
                default -> msg(s, "Unknown option. /dh for help.");
            }
        } catch (Throwable t) {
            msg(s, ChatColor.RED + "Failed: " + t);
            getLogger().log(java.util.logging.Level.SEVERE, "dh " + String.join(" ", a) + " failed", t);
        }
        return true;
    }

    private Plugin find(String n) {
        for (Plugin p : Bukkit.getPluginManager().getPlugins())
            if (ours(p.getName()) && p.getName().equalsIgnoreCase(n)) return p;
        for (Plugin p : Bukkit.getPluginManager().getPlugins())
            if (ours(p.getName()) && p.getName().equalsIgnoreCase("Darkholm" + n)) return p;
        return null;
    }

    // Paper closes a plugin's classloader on disable, so a plain disable/enable breaks it.
    // Reload = full unload and a fresh load of the same jar.
    private void reload(Plugin p) throws Exception {
        File jar = (File) field(JavaPlugin.class, "file").get(p);
        File tmp = new File(swapDir, jar.getName());
        Files.copy(jar.toPath(), tmp.toPath(), StandardCopyOption.REPLACE_EXISTING);
        swap(p, tmp);
    }

    private static String metaName(File f) {
        try (ZipFile z = new ZipFile(f)) {
            ZipEntry e = z.getEntry("plugin.yml");
            if (e == null) return null;
            try (InputStream in = z.getInputStream(e)) {
                for (String l : new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).split("\n")) {
                    if (l.startsWith("name:")) return l.substring(5).trim().replace("'", "").replace("\"", "");
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private File jarFor(String name) {
        File[] js = swapDir.listFiles((d, n) -> n.endsWith(".jar"));
        if (js == null) return null;
        for (File f : js) if (name.equals(metaName(f))) return f;
        return null;
    }

    private Plugin swap(Plugin p, File newJar) throws Exception {
        File oldJar = (File) field(JavaPlugin.class, "file").get(p);
        unload(p);
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
        Files.move(oldJar.toPath(), new File(oldDir, oldJar.getName() + "." + stamp + ".bak").toPath(), StandardCopyOption.REPLACE_EXISTING);
        return loadNew(newJar, oldJar.getName());
    }

    private Plugin loadNew(File jarInSwap, String keepName) throws Exception {
        File dest = new File(getDataFolder().getParentFile(), keepName != null ? keepName : jarInSwap.getName());
        Files.move(jarInSwap.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        PluginManager pm = Bukkit.getPluginManager();
        Plugin np = pm.loadPlugin(dest);
        if (np == null) throw new IllegalStateException("loadPlugin returned null");
        np.onLoad();
        pm.enablePlugin(np);
        syncCommands();
        return np;
    }

    @SuppressWarnings("unchecked")
    private void unload(Plugin p) throws Exception {
        PluginManager pm = Bukkit.getPluginManager();
        pm.disablePlugin(p);

        // commands
        CommandMap map = Bukkit.getCommandMap();
        Map<String, Command> known = map.getKnownCommands();
        List<String> drop = new ArrayList<>();
        Set<Command> cmds = new HashSet<>();
        for (Map.Entry<String, Command> e : new ArrayList<>(known.entrySet())) {
            if (e.getValue() instanceof PluginCommand pc && pc.getPlugin() == p) { drop.add(e.getKey()); cmds.add(pc); }
        }
        for (String k : drop) {
            try { known.remove(k); } catch (Throwable t) { getLogger().warning("command " + k + ": " + t); }
        }
        for (Command c : cmds) {
            try { c.unregister(map); } catch (Throwable ignored) { }
        }

        // permissions
        for (Permission perm : p.getDescription().getPermissions()) {
            try { pm.removePermission(perm); } catch (Throwable ignored) { }
        }

        // Paper plugin registry
        Class<?> impl = Class.forName("io.papermc.paper.plugin.manager.PaperPluginManagerImpl");
        Object mgr = impl.getMethod("getInstance").invoke(null);
        Object inst = field(impl, "instanceManager").get(mgr);
        Class<?> ic = inst.getClass();
        ((List<Plugin>) field(ic, "plugins").get(inst)).remove(p);
        ((Map<String, Plugin>) field(ic, "lookupNames").get(inst)).values().removeIf(v -> v == p);
        try {
            Object tree = field(ic, "dependencyTree").get(inst);
            Class<?> metaC = Class.forName("io.papermc.paper.plugin.configuration.PluginMeta");
            tree.getClass().getMethod("remove", metaC).invoke(tree, p.getPluginMeta());
        } catch (Throwable t) { getLogger().warning("dependency tree: " + t); }

        // classloader
        ClassLoader cl = p.getClass().getClassLoader();
        try {
            Class<?> st = Class.forName("io.papermc.paper.plugin.provider.classloader.PaperClassLoaderStorage");
            Object storage = st.getMethod("instance").invoke(null);
            Class<?> cfg = Class.forName("io.papermc.paper.plugin.provider.classloader.ConfiguredPluginClassLoader");
            if (cfg.isInstance(cl)) st.getMethod("unregisterClassloader", cfg).invoke(storage, cl);
        } catch (Throwable t) { getLogger().warning("classloader storage: " + t); }
        if (cl instanceof AutoCloseable ac) {
            try { ac.close(); } catch (Throwable t) { getLogger().warning("classloader close: " + t); }
        }
        syncCommands();
    }

    private void syncCommands() {
        try {
            Method m = Bukkit.getServer().getClass().getMethod("syncCommands");
            m.invoke(Bukkit.getServer());
        } catch (Throwable t) { getLogger().warning("syncCommands: " + t); }
        for (Player pl : Bukkit.getOnlinePlayers()) pl.updateCommands();
    }

    private static Field field(Class<?> c, String n) throws NoSuchFieldException {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try { Field f = k.getDeclaredField(n); f.setAccessible(true); return f; } catch (NoSuchFieldException ignored) { }
        }
        throw new NoSuchFieldException(n);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String o : List.of("reload", "swap", "load", "list")) if (o.startsWith(a[0].toLowerCase())) out.add(o);
        } else if (a.length == 2) {
            String sub = a[0].toLowerCase();
            if (sub.equals("load")) {
                File[] js = swapDir.listFiles((d, n) -> n.endsWith(".jar"));
                if (js != null) for (File f : js) out.add(f.getName());
            } else if (sub.equals("reload") || sub.equals("swap")) {
                if (sub.equals("reload")) out.add("all");
                for (Plugin p : Bukkit.getPluginManager().getPlugins())
                    if (ours(p.getName())) out.add(p.getName());
            }
            out.removeIf(x -> !x.toLowerCase().startsWith(a[1].toLowerCase()));
        }
        return out;
    }
}
