package live.darkholm.pearls;
import org.bukkit.*; import org.bukkit.entity.*; import org.bukkit.event.*; import org.bukkit.event.block.Action; import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack; import org.bukkit.plugin.java.JavaPlugin; import java.lang.reflect.Method;
public class Pearls extends JavaPlugin implements Listener {
  private Method psValueOf, boardGet, factionAt, factionId; private boolean ok;
  private String m(String k,String d){ return ConfigSync.c(getConfig().getString("messages."+k,d)); }
  @Override public void onEnable(){
    ConfigSync.sync(this);
    try{ Class<?> ps=Class.forName("com.massivecraft.massivecore.ps.PS"); psValueOf=ps.getMethod("valueOf",Location.class);
      Class<?> bc=Class.forName("com.massivecraft.factions.entity.BoardColl"); boardGet=bc.getMethod("get"); factionAt=bc.getMethod("getFactionAt",ps);
      factionId=Class.forName("com.massivecraft.factions.entity.Faction").getMethod("getId"); ok=true;
    }catch(Throwable t){ getLogger().severe("Factions API not found, pearl block disabled: "+t); }
    Bukkit.getPluginManager().registerEvents(this,this);
  }
  private boolean claimed(Location l){
    if(!ok||l==null||l.getWorld()==null) return false;
    try{ Object board=boardGet.invoke(null); Object f=factionAt.invoke(board,psValueOf.invoke(null,l)); if(f==null) return false; return !"none".equals(factionId.invoke(f)); }
    catch(Throwable t){ return false; }
  }
  @EventHandler(priority=EventPriority.HIGH)
  public void onThrow(PlayerInteractEvent e){
    Action a=e.getAction(); if(a!=Action.RIGHT_CLICK_AIR&&a!=Action.RIGHT_CLICK_BLOCK) return;
    ItemStack it=e.getItem(); if(it==null||it.getType()!=Material.ENDER_PEARL) return;
    Player p=e.getPlayer(); if(p.getGameMode()==GameMode.CREATIVE&&getConfig().getBoolean("creative-bypass",true)) return;
    if(!getConfig().getBoolean("block-throw-in-claims",true)) return;
    if(claimed(p.getLocation())){ e.setCancelled(true); p.sendMessage(m("no-throw","&cEnder pearls can't be thrown inside claimed land.")); }
  }
  @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
  public void onPearl(PlayerTeleportEvent e){
    if(e.getCause()!=PlayerTeleportEvent.TeleportCause.ENDER_PEARL) return;
    Player p=e.getPlayer(); if(p.getGameMode()==GameMode.CREATIVE&&getConfig().getBoolean("creative-bypass",true)) return;
    boolean from=getConfig().getBoolean("block-pearl-out-of-claims",true)&&claimed(e.getFrom()), to=getConfig().getBoolean("block-pearl-into-claims",true)&&claimed(e.getTo());
    if(from||to){ e.setCancelled(true); if(getConfig().getBoolean("return-pearl",true)) p.getInventory().addItem(new ItemStack(Material.ENDER_PEARL,1));
      p.sendMessage(to?m("no-land","&cYour pearl can't land inside claimed land. It was returned."):m("no-leave","&cYou can't pearl out of claimed land. It was returned.")); }
  }
}
