package com.darkholm.warden;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * DarkholmWarden — detection-only staff alerts.
 *
 * This plugin NEVER cancels an event, never sets velocity or position, never
 * kicks, mutes, or freezes a player, and never alters anything about a
 * player's connection. Every check below only reads state and, if a pattern
 * repeats enough to pass its threshold, sends a chat line to staff and a log
 * line. A human decides what happens next, every time.
 */
public class DarkholmWarden extends JavaPlugin implements Listener, CommandExecutor {

    // ---- config cache ----
    long alertCooldownMs;
    String alertFormat;
    boolean logToConsole;

    boolean speedEnabled; double speedTolerance; int speedViolationsToAlert; long speedWindowMs; boolean ignoreSlick;
    boolean flightEnabled; int flightAirborneThreshold; int flightViolationsToAlert; long flightWindowMs;
    boolean reachEnabled; double reachMax; int reachViolationsToAlert; long reachWindowMs;
    boolean acEnabled; int acCpsThreshold; int acSustainedSeconds;

    // ---- per-player tracking (alert-only state; nothing here ever touches a player) ----
    final Map<UUID, Deque<Long>> speedViol = new ConcurrentHashMap<>();
    final Map<UUID, Deque<Long>> flightViol = new ConcurrentHashMap<>();
    final Map<UUID, Integer> flightStreak = new ConcurrentHashMap<>();
    final Map<UUID, Deque<Long>> reachViol = new ConcurrentHashMap<>();
    final Map<UUID, Deque<Long>> hitTimes = new ConcurrentHashMap<>();
    final Map<UUID, Integer> acStreak = new ConcurrentHashMap<>();
    final Map<UUID, Map<String, Long>> lastAlert = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        ConfigSync.sync(this);
        loadValues();
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("warden");
        if (cmd != null) cmd.setExecutor(this);
        getServer().getScheduler().runTaskTimer(this, this::sampleAutoclicker, 20L, 20L);
        getLogger().info("Warden watching (alert-only, no enforcement): speed=" + speedEnabled
                + " flight=" + flightEnabled + " reach=" + reachEnabled + " autoclicker=" + acEnabled);
    }

    void loadValues() {
        alertCooldownMs = getConfig().getLong("alert-cooldown-seconds", 45) * 1000L;
        alertFormat = getConfig().getString("alert-format", "&8[&cWarden&8] &7{player} &cflagged&7: &f{check} &8({detail})");
        logToConsole = getConfig().getBoolean("log-to-console", true);

        speedEnabled = getConfig().getBoolean("speed.enabled", true);
        speedTolerance = getConfig().getDouble("speed.tolerance-multiplier", 1.6);
        speedViolationsToAlert = getConfig().getInt("speed.violations-to-alert", 6);
        speedWindowMs = getConfig().getLong("speed.window-seconds", 4) * 1000L;
        ignoreSlick = getConfig().getBoolean("speed.ignore-on-ice-slime-soulsand", true);

        flightEnabled = getConfig().getBoolean("flight.enabled", true);
        flightAirborneThreshold = getConfig().getInt("flight.airborne-ticks-threshold", 40);
        flightViolationsToAlert = getConfig().getInt("flight.violations-to-alert", 2);
        flightWindowMs = getConfig().getLong("flight.window-seconds", 10) * 1000L;

        reachEnabled = getConfig().getBoolean("reach.enabled", true);
        reachMax = getConfig().getDouble("reach.max-distance", 3.6);
        reachViolationsToAlert = getConfig().getInt("reach.violations-to-alert", 4);
        reachWindowMs = getConfig().getLong("reach.window-seconds", 5) * 1000L;

        acEnabled = getConfig().getBoolean("autoclicker.enabled", true);
        acCpsThreshold = getConfig().getInt("autoclicker.cps-threshold", 20);
        acSustainedSeconds = getConfig().getInt("autoclicker.sustained-seconds", 3);
    }

    static String c(String s) { return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s); }

    boolean exempt(Player p) { return p.hasPermission("darkholm.warden.bypass"); }

    // ---- alerting ----
    void alert(Player p, String check, String detail) {
        long now = System.currentTimeMillis();
        Map<String, Long> m = lastAlert.computeIfAbsent(p.getUniqueId(), k -> new ConcurrentHashMap<>());
        Long last = m.get(check);
        if (last != null && now - last < alertCooldownMs) return;
        m.put(check, now);

        String msg = c(alertFormat.replace("{player}", p.getName()).replace("{check}", check).replace("{detail}", detail));
        for (Player staff : getServer().getOnlinePlayers()) {
            if (staff.hasPermission("darkholm.warden.alerts")) staff.sendMessage(msg);
        }
        if (logToConsole) getLogger().info(ChatColor.stripColor(msg));
    }

    void recordViolation(Map<UUID, Deque<Long>> store, Player p, long windowMs, int threshold, String check, String detail) {
        Deque<Long> dq = store.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        long now = System.currentTimeMillis();
        dq.addLast(now);
        while (!dq.isEmpty() && now - dq.peekFirst() > windowMs) dq.pollFirst();
        if (dq.size() >= threshold) {
            dq.clear();
            alert(p, check, detail);
        }
    }

    static boolean isSlick(Material m) {
        return m == Material.ICE || m == Material.PACKED_ICE || m == Material.BLUE_ICE
                || m == Material.FROSTED_ICE || m == Material.SLIME_BLOCK || m == Material.SOUL_SAND
                || m == Material.SOUL_SOIL || m == Material.HONEY_BLOCK;
    }

    // ---- movement: speed + flight ----
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (exempt(p)) return;
        Location from = e.getFrom(), to = e.getTo();
        if (to == null) return;

        double dx = to.getX() - from.getX(), dz = to.getZ() - from.getZ(), dy = to.getY() - from.getY();
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz > 10 || dy < -10 || dy > 10) return; // teleport, plugin-driven move, or world change artifact — not a pattern to judge

        checkSpeed(p, from, horiz);
        checkFlight(p, to, dy);
    }

    void checkSpeed(Player p, Location from, double horiz) {
        if (!speedEnabled) return;
        if (p.isInsideVehicle() || p.isGliding() || p.isSwimming() || p.isRiptiding() || p.isFlying()) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (ignoreSlick && isSlick(from.getBlock().getRelative(0, -1, 0).getType())) return;

        double base = p.isSprinting() ? 0.29 : 0.22;
        PotionEffect speedEff = p.getPotionEffect(PotionEffectType.SPEED);
        if (speedEff != null) base *= (1 + 0.2 * (speedEff.getAmplifier() + 1));
        double maxAllowed = base * speedTolerance;

        if (horiz > maxAllowed) {
            recordViolation(speedViol, p, speedWindowMs, speedViolationsToAlert, "Speed",
                    String.format("%.2f blocks/tick, limit ~%.2f", horiz, maxAllowed));
        }
    }

    void checkFlight(Player p, Location to, double dy) {
        if (!flightEnabled) return;
        UUID id = p.getUniqueId();
        if (p.isInsideVehicle() || p.isGliding() || p.isSwimming() || p.isClimbing() || p.isFlying()
                || p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR
                || p.hasPotionEffect(PotionEffectType.LEVITATION) || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
            flightStreak.remove(id);
            return;
        }
        if (p.isOnGround()) { flightStreak.remove(id); return; }

        if (dy >= -0.08) {
            int streak = flightStreak.merge(id, 1, Integer::sum);
            if (streak >= flightAirborneThreshold) {
                flightStreak.put(id, 0);
                recordViolation(flightViol, p, flightWindowMs, flightViolationsToAlert, "Flight",
                        streak + " airborne ticks without falling");
            }
        } else {
            flightStreak.remove(id); // falling normally
        }
    }

    // ---- combat: reach + autoclicker ----
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        Entity dmgr = e.getDamager();
        if (!(dmgr instanceof Player p) || exempt(p)) return;
        if (!(e.getEntity() instanceof LivingEntity target)) return;

        checkReach(p, target);
        hitTimes.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>()).addLast(System.currentTimeMillis());
    }

    void checkReach(Player p, LivingEntity target) {
        if (!reachEnabled) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        Vector eye = p.getEyeLocation().toVector();
        BoundingBox box = target.getBoundingBox();
        double cx = clamp(eye.getX(), box.getMinX(), box.getMaxX());
        double cy = clamp(eye.getY(), box.getMinY(), box.getMaxY());
        double cz = clamp(eye.getZ(), box.getMinZ(), box.getMaxZ());
        double dist = eye.distance(new Vector(cx, cy, cz));
        if (dist > reachMax) {
            recordViolation(reachViol, p, reachWindowMs, reachViolationsToAlert, "Reach",
                    String.format("%.2f blocks on %s, limit %.1f", dist, target.getType(), reachMax));
        }
    }

    static double clamp(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

    // Sampled once a second — tells us sustained CPS without touching the player at all.
    void sampleAutoclicker() {
        if (!acEnabled) return;
        long now = System.currentTimeMillis();
        for (UUID id : hitTimes.keySet()) {
            Deque<Long> dq = hitTimes.get(id);
            if (dq == null) continue;
            while (!dq.isEmpty() && now - dq.peekFirst() > 1000) dq.pollFirst();
            int cps = dq.size();
            Player p = getServer().getPlayer(id);
            if (p == null) { acStreak.remove(id); continue; }
            if (cps >= acCpsThreshold) {
                int streak = acStreak.merge(id, 1, Integer::sum);
                if (streak >= acSustainedSeconds) {
                    acStreak.put(id, 0);
                    alert(p, "Autoclicker/CPS", cps + " clicks/sec sustained " + streak + "s");
                }
            } else {
                acStreak.put(id, 0);
            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("darkholm.warden.admin")) {
            sender.sendMessage(c("&cYou don't have permission for that."));
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            ConfigSync.sync(this);
            loadValues();
            sender.sendMessage(c("&aWarden config reloaded."));
            return true;
        }
        sender.sendMessage(c("&7&m                                        "));
        sender.sendMessage(c("&6Warden &7— alert-only, never kicks/freezes/cancels"));
        sender.sendMessage(c("&7Speed: " + onOff(speedEnabled) + " &7| Flight: " + onOff(flightEnabled)
                + " &7| Reach: " + onOff(reachEnabled) + " &7| Autoclicker: " + onOff(acEnabled)));
        sender.sendMessage(c("&7Alert cooldown: &f" + (alertCooldownMs / 1000) + "s&7 per player per check"));
        sender.sendMessage(c("&7Use &f/warden reload &7after editing config.yml"));
        sender.sendMessage(c("&7&m                                        "));
        return true;
    }

    String onOff(boolean b) { return b ? "&aon" : "&coff"; }
}
